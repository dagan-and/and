package com.daquv.sdk.stt.itl.api;


import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.text.TextUtils;


import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.stt.itl.ITLModel;
import com.daquv.sdk.utils.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class ItlController {
    private final ItlSocketIoClient stt;
    private final MicInputHandler mic;
    private Boolean started = false;
    private List<byte[]> micq = null;
    private static final int MAX_MICQ = 200;
    private ItlController.OnResultListener mListener;
    private Thread startWakeUpWithSTTThread = null;
    private static final long MILLIS_IN_FUTURE = 5500L;
    private Disposable backgroundTask;
    private ExecutorService executorService;
    private ByteArrayOutputStream totalBuffer;
    private Context mContext;
    private String partialData;
    private long lastActiveTime = Long.MAX_VALUE;

    private final Handler mHandler = new Handler(Looper.myLooper()) {
        public void handleMessage(Message msg) {
            if (ItlController.this.mListener != null) {
                ItlController.this.mListener.onResult(msg);
            }

        }
    };
    private final Handler sttResultHandler = new Handler(Looper.myLooper()) {
        public void handleMessage(Message inputMessage) {
            String msg = (String) inputMessage.obj;
            switch (inputMessage.what) {
                case ItlSocketIoClient.JSON_RESULT:
                    try {
                        String result;
                        String status;

                        JSONObject jObj = new JSONObject(msg);
                        result = jObj.getJSONArray("results")
                                .getJSONObject(0)
                                .getString("sentence").trim();
                        status = jObj.getString("status");

                        JSONObject resultObject = new JSONObject();
                        resultObject.put("sentence", result);
                        resultObject.put("return", "SUCCESS");
                        resultObject.put("status", status);

                        ItlController.this.sendSentence(resultObject.toString());
                        if (status.equals(ITLModel.STATUS.PARTIAL.name())) {
                            partialData = result;
                            lastActiveTime = System.currentTimeMillis();
                        }
                    } catch (JSONException e) {
                        Logger.error(e);
                    }
                    break;
                case ItlSocketIoClient.ALERT:
                    ItlController.this.sendAlertToMainActivity(msg);
                    break;
                case ItlSocketIoClient.READY:
                    ItlController.this.sendReady();
                    lastActiveTime = System.currentTimeMillis();
                    break;
                case ItlSocketIoClient.DISCONNECT:
                    lastActiveTime = Long.MAX_VALUE;
                    break;
                default:
                    break;
            }

        }
    };

    private void sendAlertToMainActivity(String alert) {
        Message msg = this.mHandler.obtainMessage();
        msg.what = ItlSocketIoClient.ALERT;
        msg.obj = alert;
        this.mHandler.sendMessage(msg);
    }

    private void sendSentence(String sentence) {
        Message msg = this.mHandler.obtainMessage();
        msg.what = ItlSocketIoClient.JSON_RESULT;
        msg.obj = sentence;
        this.mHandler.sendMessage(msg);
    }

    private void sendReady() {
        Message msg = this.mHandler.obtainMessage();
        msg.what = ItlSocketIoClient.READY;
        this.mHandler.sendMessage(msg);
    }

    private void sendTimeOut() {
        Message msg = this.mHandler.obtainMessage();
        msg.what = ItlSocketIoClient.TIMEOUT;
        this.mHandler.sendMessage(msg);
    }

    private void sendSavePcmFile(String path) {
        Message msg = this.mHandler.obtainMessage();
        msg.what = ItlSocketIoClient.SAVE_PCM;
        msg.obj = path;
        this.mHandler.sendMessage(msg);
    }

    public ItlController(Context context) {
        this.mContext = context;
        this.executorService = Executors.newSingleThreadExecutor();
        this.micq = Collections.synchronizedList(new LinkedList());
        this.mic = new MicInputHandler();
        this.mic.setOnProcessMicData(new MicInputHandler.OnProcessMicData() {
            public void onProcessMicData(byte[] audio) {
                if (ItlController.this.micq.size() == MAX_MICQ) {
                    Logger.info("micq full");
                    ItlController.this.micq.clear();
                } else {
                    ItlController.this.micq.add(audio);
                }

                /* 현재 시간에서 최근 동작한 시간을 뺀게 5.5초 이상이면 타임아웃 */
                /* 발화한 내역이 있으면 그거를 파이날 처리 , 없으면 그냥 종료 */
                if(System.currentTimeMillis() - lastActiveTime > MILLIS_IN_FUTURE) {
                    if (!TextUtils.isEmpty(partialData)) {
                        try {
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("sentence", partialData);
                            jsonObject.put("return", "SUCCESS");
                            jsonObject.put("status", "FINAL");

                            String jsonString = jsonObject.toString();

                            lastActiveTime = Long.MAX_VALUE;
                            ItlController.this.sendSentence(jsonString);
                        } catch (JSONException e) {
                            Logger.error(e);
                            lastActiveTime = Long.MAX_VALUE;
                            ItlController.this.sendTimeOut();
                        }
                    } else {
                        lastActiveTime = Long.MAX_VALUE;
                        ItlController.this.sendTimeOut();
                    }
                }
            }
        });
        String mHost = DaquvConfig.sttUrl;
        int mPort = DaquvConfig.sttPort;
        this.stt = new ItlSocketIoClient(mHost, mPort, this.sttResultHandler);
    }

    public void setListener(ItlController.OnResultListener listener) {
        this.mListener = listener;
    }

    public void pauseMic() {
        this.mic.pause();
    }

    public void resumeMic() {
        this.mic.resume();
    }

    public void startWakeUpWithSTT() {
        if (!this.started) {
            totalBuffer = new ByteArrayOutputStream();
            partialData = null;

            this.mic.start();
            this.started = true;
            this.startWakeUpWithSTTThread = new Thread(new Runnable() {
                public void run() {
                    ItlController.this.wakeUpWithSTT();
                }
            });
            if (this.startWakeUpWithSTTThread != null) {
                try {
                    this.startWakeUpWithSTTThread.start();
                } catch (Exception var2) {
                    Logger.error(var2);
                }
            }

        }
    }


    public void stopWakeupWithSTT() {
        if (this.started) {
            this.started = false;

            try {
                if (this.startWakeUpWithSTTThread != null) {
                    this.startWakeUpWithSTTThread.join();
                    this.startWakeUpWithSTTThread = null;
                }
            } catch (InterruptedException var2) {
                Logger.error(var2);
            }
            this.mic.stop();
            if (this.stt.isConnected()) {
                this.stt.disconnect();
            }
        }
    }

    private void wakeUpWithSTT() {
        while (this.started) {
            int mSleepTimeInMs = 10;
            if (this.micq.size() <= 0) {
                SystemClock.sleep(mSleepTimeInMs);
            } else {
                byte[] audio = this.micq.remove(0);
                if (audio != null && audio.length != 0) {
                    if (this.stt.isConnected()) {
                        this.stt.send(audio);
                    }
                } else {
                    SystemClock.sleep(mSleepTimeInMs);
                }
            }
        }

    }

    public void startDoNetworkJob() {
        backgroundTask();
    }

    private void backgroundTask() {
        backgroundTask = Observable.fromCallable(() -> {
                    stt.connect();
                    return false;
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((result) -> {
                    backgroundTask.dispose();

                });
    }

    public interface OnResultListener {
        void onResult(Message var1);
    }


    /**
     * PCM 파일 저장
     */
    public void savePcmFile() {
        executorService.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    String fileName = "and_"+System.currentTimeMillis() + ".pcm";
                    FileOutputStream os = mContext.openFileOutput(fileName, Context.MODE_PRIVATE);
                    os.write(totalBuffer.toByteArray());
                    os.close();
                    sendSavePcmFile(mContext.getFileStreamPath(fileName).getAbsolutePath());
                } catch (Exception e) {
                    Logger.error(e);
                }
            }
        });
    }
}
