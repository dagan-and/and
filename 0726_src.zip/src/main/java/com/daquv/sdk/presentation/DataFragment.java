package com.daquv.sdk.presentation;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.Entities;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.data.response.LocationItemResponse;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.secure.PreventRecordUtils;
import com.daquv.sdk.webview.ComWebView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class DataFragment extends Fragment {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    DaquvEngine.Callback engineCallback;
    ComWebView webView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        PreventRecordUtils.getInstance().setSecureFlag(requireActivity());
        return inflater.inflate(R.layout.fragment_daquv_data , container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.btn_top).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                webView.pageUp(true);
                webView.loadUrl("javascript:toTopFunction()");
                //webView. loadUrl("javascript:document.getElementsByClassName('wrap')[0].scrollTo({top:0,behavior:'smooth'});");
            }
        });

        webView = view.findViewById(R.id.data_view);
        webView.addListener(new ComWebView.OnWebActionListener() {
            @Override
            public void onShortCut(String utterance) {
                listener.showLoading();
                DaquvConfig.inputType = DaquvConfig.INPUT_TYPE.TOUCH;
                DaquvSDK.getInstance().getEngine().cleanState();
                DaquvSDK.getInstance().getAPI().getNLUData(utterance);
            }

            @Override
            public void onClose() {
                listener.hideLoading();
                listener.onBackPress(DataFragment.this);
            }

            @Override
            public void onSTT(boolean start) {
                if(start) {
                    listener.addVoiceView();
                } else {
                    listener.removeVoiceView();
                }
            }

            @Override
            public void onHome() {
                listener.hideLoading();
                listener.addMainView(false);
            }

            @Override
            public void onSetting() {
                listener.addSettingView();
            }

            @Override
            public void onConsult(String companyId, String companyNm) {
                DaquvSDK.getInstance().stopTTS();
                if(TextUtils.isEmpty(companyId) || TextUtils.isEmpty(companyNm)) {
                    listener.addVoiceView("상담내용 등록", null);
                } else {
                    listener.addConsultView(companyId, companyNm);
                }
            }

            @Override
            public void onMap(String name, String lat , String lon) {
                DaquvSDK.getInstance().stopTTS();
                listener.showLoading();
                if(lat != null && lon != null) {
                    DaquvSDK.getInstance().getAPI().getMapData(name, lat, lon ,
                            DaquvConfig.defaultRadius,
                            DaquvConfig.mapFilterList.getFilter());
                } else {
                    DaquvSDK.getInstance().getAPI().getMapData("내 위치",String.valueOf(DaquvSDK.getInstance().getLocation().getLatitude()),
                            String.valueOf(DaquvSDK.getInstance().getLocation().getLongitude()),
                            DaquvConfig.defaultRadius,
                            DaquvConfig.mapFilterList.getFilter());
                }
            }

            @Override
            public void onNavi(ArrayList<LocationItem> items) {
                DaquvSDK.getInstance().stopTTS();
                if(items.size() == 1) {
                    if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_tmap))) {
                        DaquvUtil.runTMap(requireContext(), items);
                    } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_kakao))) {
                        DaquvUtil.runKakaoMap(requireContext(), items);
                    } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_naver))) {
                        DaquvUtil.runNaverMap(requireContext(), items);
                    }
                } else {
                    if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(getString(R.string.map_tmap))) {
                        DaquvUtil.runTMap(requireContext(), items);
                    } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(getString(R.string.map_naver))) {
                        DaquvUtil.runNaverMap(requireContext(), items);
                    }
                }
            }

            @Override
            public void onCall(String number) {
                Intent tt = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
                startActivity(tt);
            }

            @Override
            public void onBrowser(String url) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
            }

            @Override
            public void onDataPage(String json) {
                try {
                    JSONObject jsonObject = new JSONObject(json);
                    NLUResultResponse nluResultResponse = new NLUResultResponse();
                    nluResultResponse.setUrl(jsonObject.optString("url"));
                    nluResultResponse.setIntent(jsonObject.optString("intent_code"));

                    ArrayList<Entities> entities = new ArrayList<>();
                    if(!TextUtils.isEmpty(jsonObject.optString("COUNTERPARTNAME"))) {
                        entities.add(new Entities("COUNTERPARTNAME", jsonObject.optString("COUNTERPARTNAME"),null,null));
                    }
                    if(!TextUtils.isEmpty(jsonObject.optString("COMPANYID"))) {
                        entities.add(new Entities("COMPANYID", jsonObject.optString("COMPANYID"),null,null));
                    }
                    nluResultResponse.setEntities(entities);
                    listener.showLoading();
                    DaquvConfig.inputType = DaquvConfig.INPUT_TYPE.TOUCH;
                    DaquvSDK.getInstance().getAPI().getResultPage(nluResultResponse);
                } catch (NullPointerException | JSONException e) {
                    Logger.error(e);
                }
            }

            @Override
            public void onCapture() {
                //지원하지 않음
            }

            @Override
            public void onBottomView(boolean isVisible) {
                listener.bottomSTTView(isVisible);
            }

            @Override
            public void onPageLoad(boolean loading) {
                if(loading) {
                    DaquvSDK.getInstance().getEngine().stopEngine();
                    DaquvSDK.getInstance().stopTTS();
                    listener.bottomSTTView(true);
                    listener.showLoading();
                } else {
                    listener.hideLoading();
                }
            }

            @Override
            public void onReload(long delay) {
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        DaquvSDK.getInstance().getAPI().resultPageReload();
                    }
                }, delay);
                listener.showLoading();
            }
        });
        webView.loadDataPage();
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                webView.onBackPress();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);

                if (code == DaquvConfig.CODE.ENGINE_FINISH_TTS) {
                    if(result instanceof TTSResponse) {
                        String callBack = ((TTSResponse) result).getCallBack();
                        if (!TextUtils.isEmpty(callBack) && ("startSTT".equalsIgnoreCase(callBack) || "Y".equalsIgnoreCase(callBack))) {
                            listener.startTurnSTT(true);
                        }
                    }
                }
                if (code == DaquvConfig.CODE.API_NLU_TURN) {
                    listener.hideLoading();
                    String value = (String) result;
                    String count = value.substring(0, value.indexOf("번"));
                    webView.loadUrl("javascript:callCompanyInfo(" + count + ")");
                }
                if (code == DaquvConfig.CODE.API_ERROR) {
                    listener.hideLoading();
                    if(result instanceof ErrorData) {
                        if(((ErrorData) result).getCode() == DaquvConfig.CODE.API_NLU_TURN) {
                            if(!TextUtils.isEmpty(((ErrorData) result).getMsg())) {
                                DaquvSDK.getInstance().getAPI().getTTSBinary(((ErrorData) result).getMsg());
                            }
                        }
                    }
                }
            }
        };
        DaquvSDK.getInstance().addCallBack(engineCallback);
    }

    @Override
    public void onStop() {
        DaquvSDK.getInstance().stopTTS();
        DaquvSDK.getInstance().getEngine().stopEngine();
        super.onStop();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        webView.onDestroy();
        onBackPressedCallback.remove();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
