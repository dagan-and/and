package com.daquv.sdk.data.response;

import android.text.TextUtils;

import com.daquv.sdk.network.ETagCache;
import com.daquv.sdk.utils.Logger;
import com.google.gson.annotations.SerializedName;

import java.io.IOException;

import okhttp3.Response;

public class ConsultResponse {
    @SerializedName("status")
    private int status;

    @SerializedName("success")
    private Boolean success;

    @SerializedName("retCd")
    private String retCd;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getRetCd() {
        return retCd;
    }

    public void setRetCd(String retCd) {
        this.retCd = retCd;
    }
}
