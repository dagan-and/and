package com.daquv.sdk.ui.component;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.ViewGroup;

import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.ViewCompat;

import com.daquv.sdk.R;
import com.daquv.sdk.utils.DaquvUtil;


public class BasicButtonView extends AppCompatTextView {

    public enum ViewType {
        FILLED,
        TINTED,
        CANCEL,
        DELETE,
        LOGOUT
    }

    public enum ShapeType {
        RECT
    }

    private int viewType = 0;
    private int shapeType = 0;
    private float tSize = 20f;
    private float cornerRadii = 0f;
    private int radius = 10;

    public BasicButtonView(Context context) {
        super(context);
        init();
    }

    public BasicButtonView(Context context, AttributeSet attrs) {
        super(context, attrs);
        viewType = context.obtainStyledAttributes(attrs, R.styleable.BasicButtonView)
                .getInt(R.styleable.BasicButtonView_bvType, 0);
        shapeType = context.obtainStyledAttributes(attrs, R.styleable.BasicButtonView)
                .getInt(R.styleable.BasicButtonView_bvShape, 0);
        tSize = context.obtainStyledAttributes(attrs, R.styleable.BasicButtonView)
                .getFloat(R.styleable.BasicButtonView_bvTextSize, 18f);
        radius = context.obtainStyledAttributes(attrs, R.styleable.BasicButtonView)
                .getInt(R.styleable.BasicButtonView_bvRadius, 10);
        init();
    }

    public BasicButtonView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        viewType = context.obtainStyledAttributes(attrs, R.styleable.BasicButtonView)
                .getInt(R.styleable.BasicButtonView_bvType, 0);
        shapeType = context.obtainStyledAttributes(attrs, R.styleable.BasicButtonView)
                .getInt(R.styleable.BasicButtonView_bvShape, 0);
        tSize = context.obtainStyledAttributes(attrs, R.styleable.BasicButtonView)
                .getFloat(R.styleable.BasicButtonView_bvTextSize, 18f);
        radius = context.obtainStyledAttributes(attrs, R.styleable.BasicButtonView)
                .getInt(R.styleable.BasicButtonView_bvRadius, 10);
        init();
    }

    public void setType(int type) {
        this.viewType = type;
    }

    public void setShape(int type) {
        this.shapeType = type;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public void setTypefaceReqular() {
        setTypeface(ResourcesCompat.getFont(getContext(), R.font.suitregular), Typeface.NORMAL);
    }

    private void init() {
        setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_white));
        setTypeface(ResourcesCompat.getFont(getContext(), R.font.suitbold), Typeface.NORMAL);
        setTextSize(tSize);
        setClickable(true);
        setGravity(Gravity.CENTER);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if (getLayoutParams().height == ViewGroup.LayoutParams.WRAP_CONTENT) {
            getLayoutParams().height = DaquvUtil.convertDPtoPX(getContext(), 52);
        }

        cornerRadii = DaquvUtil.convertDPtoPX(getContext(), radius);

        switch (viewType) {
            case 0:
                filledState(false);
                break;
            case 1:
                tintedState(false);
                break;
            case 2:
                cancelState(false);
                break;
            case 3:
                deleteState(false);
                break;
            case 4:
                logoutState(false);
                break;
            default:
                filledState(false);
                break;
        }
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
    }

    private void setRoundRectSolid(int color) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadii(new float[]{cornerRadii, cornerRadii, cornerRadii, cornerRadii,
                cornerRadii, cornerRadii, cornerRadii, cornerRadii});
        shape.setColor(ContextCompat.getColor(getContext(), color));
        ViewCompat.setBackground(this, shape);
    }

    private void setRoundRectStroke(int color, int stroke) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadii(new float[]{cornerRadii, cornerRadii, cornerRadii, cornerRadii,
                cornerRadii, cornerRadii, cornerRadii, cornerRadii});
        shape.setColor(ContextCompat.getColor(getContext(), color));
        shape.setStroke(DaquvUtil.convertDPtoPX(getContext(), 1), ContextCompat.getColor(getContext(), stroke));
        ViewCompat.setBackground(this, shape);
    }

    private void filledState(boolean isPressed) {
        if (shapeType == ShapeType.RECT.ordinal()) {
            if (isEnabled()) {
                if (isPressed) {
                    setRoundRectSolid(R.color.button_filled_press);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_white));
                } else {
                    setRoundRectSolid(R.color.button_filled_idle);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_white));
                }
            } else {
                setRoundRectSolid(R.color.button_filled_disable);
                setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_white_opacity));
            }
        }
    }

    private void tintedState(boolean isPressed) {
        if (shapeType == ShapeType.RECT.ordinal()) {
            if (isEnabled()) {
                if (isPressed) {
                    setRoundRectStroke(R.color.button_tinted_press, R.color.button_tinted_press_stroke);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.button_tinted_press_text));
                } else {
                    setRoundRectStroke(R.color.button_tinted_idle, R.color.button_tinted_idle_stroke);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.button_tinted_idle_text));
                }
            } else {
                setRoundRectStroke(R.color.button_tinted_disable, R.color.button_tinted_disable_stroke);
                setTextColor(ContextCompat.getColor(getContext(), R.color.button_tinted_disable_text));
            }
            setTypeface(null, Typeface.NORMAL);
        }
    }

    private void cancelState(boolean isPressed) {
        if (shapeType == ShapeType.RECT.ordinal()) {
            if (isEnabled()) {
                if (isPressed) {
                    setRoundRectSolid(R.color.button_cancel_press);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.button_cancel_press_text));
                } else {
                    setRoundRectSolid(R.color.button_cancel_idle);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.button_cancel_idle_text));
                }
            } else {
                setRoundRectSolid(R.color.button_cancel_disable);
                setTextColor(ContextCompat.getColor(getContext(), R.color.button_cancel_disable_text));
            }
        }
    }

    private void deleteState(boolean isPressed) {
        if (shapeType == ShapeType.RECT.ordinal()) {
            if (isEnabled()) {
                if (isPressed) {
                    setRoundRectSolid(R.color.button_delete_press);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_white));
                } else {
                    setRoundRectSolid(R.color.button_delete_idle);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_white));
                }
            } else {
                setRoundRectSolid(R.color.button_delete_disable);
                setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_white));
            }
        }
    }

    private void logoutState(boolean isPressed) {
        if (shapeType == ShapeType.RECT.ordinal()) {
            if (isEnabled()) {
                if (isPressed) {
                    setRoundRectSolid(R.color.button_logout_press);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_text_base));
                } else {
                    setRoundRectSolid(R.color.button_logout_idle);
                    setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_text_base));
                }
            } else {
                setRoundRectSolid(R.color.button_logout_disable);
                setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_text_base));
            }
        }
    }

    @Override
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        switch (viewType) {
            case 0:
                filledState(isPressed());
                break;
            case 1:
                tintedState(isPressed());
                break;
            case 2:
                cancelState(isPressed());
                break;
            case 3:
                deleteState(isPressed());
                break;
            case 4:
                logoutState(isPressed());
                break;
            default:
                filledState(isPressed());
                break;
        }
    }
}
