package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class CusInfoResponse implements Serializable {

    @SerializedName("cmunNm")
    private String cmunNm;

    @SerializedName("url")
    private String url;

    @SerializedName("companyId")
    private String companyId;

    public String getCmunNm() {
        return cmunNm;
    }

    public void setCmunNm(String cmunNm) {
        this.cmunNm = cmunNm;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }
}
