package com.daquv.sdk.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.SharedPref;

public class SpeakerView extends AppCompatImageView {
    private long mLastClickTime = 0L;

    public SpeakerView(Context context) {
        super(context);
        init();
    }

    public SpeakerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        updateView();
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SystemClock.elapsedRealtime() - mLastClickTime > 500) {
                    toggle();
                }
                mLastClickTime = SystemClock.elapsedRealtime();
            }
        });

        setOnLongClickListener(new OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                String message = getContext().getString(R.string.tts_on_stop);
                updateView();
                Toast.makeText(v.getContext(), message, Toast.LENGTH_SHORT).show();
                DaquvSDK.getInstance().stopTTS();
                return true;
            }
        });
    }

    public void toggle() {
        boolean isSpeaker = SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, true);
        String message = isSpeaker ? getContext().getString(R.string.tts_on_voice) : getContext().getString(R.string.tts_on_speaker);

        SharedPref.getInstance().put(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, !isSpeaker);
        DaquvSDK.getInstance().setSpeakerMode(!isSpeaker);
        updateView();
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }

    public void updateView() {
        boolean isSpeaker = SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, true);
        if (isSpeaker) {
            setImageResource(R.drawable.btn_main_speaker_on);
        } else {
            setImageResource(R.drawable.btn_main_speaker_off);
        }
    }
}
