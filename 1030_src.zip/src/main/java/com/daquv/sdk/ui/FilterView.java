package com.daquv.sdk.ui;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.R;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.data.response.MapFilterResponse;
import com.daquv.sdk.data.response.MapFilterValue;
import com.daquv.sdk.ui.adapter.FilterAdapter;
import com.daquv.sdk.ui.component.BasicButtonView;
import com.daquv.sdk.utils.SharedPref;

import java.util.ArrayList;

public class FilterView extends FrameLayout {

    private final ImageView filterLine;
    private final RecyclerView recyclerView;
    private final ImageView btnPre;
    private final BasicButtonView btnClear;
    private final BasicButtonView btnSearch;
    private FilterAdapter adapter;

    public FilterView(@NonNull Context context) {
        super(context);
        View view = LayoutInflater.from(context).inflate(R.layout.view_filter, null);
        this.recyclerView = view.findViewById(R.id.filter_recyclerview);
        this.btnPre = view.findViewById(R.id.btn_pre);
        this.btnClear = view.findViewById(R.id.btn_clear);
        this.btnSearch = view.findViewById(R.id.btn_search);
        this.filterLine = view.findViewById(R.id.filter_line);
        addView(view);
    }

    public void init(ArrayList<MapFilterResponse> listItem, OnStateListener listener) {

        btnPre.setOnClickListener(view -> {
            if (listener != null) {
                listener.onBackPress();
            }
        });
        btnClear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        btnSearch.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    listener.onSearch(adapter.getFilters());
                    listener.onBackPress();
                }
            }
        });
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstVisibleItemPosition() == 0
                        && ((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition() == 0) {
                    filterLine.setVisibility(View.INVISIBLE);
                } else {
                    filterLine.setVisibility(View.VISIBLE);
                }
            }
        });

        MapFilterResponse navi = new MapFilterResponse();
        navi.setCategory("navi");
        navi.setSearch("N");
        navi.setType("select");
        navi.setName("길찾기/경로 설정");
        if (TextUtils.isEmpty(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI))) {
            SharedPref.getInstance().put(DaquvConfig.Preference.KEY_NAVI, DaquvConfig.appConfig.mapInfo.navi);
        }
        if (TextUtils.isEmpty(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI))) {
            SharedPref.getInstance().put(DaquvConfig.Preference.KEY_MULTI_NAVI, DaquvConfig.appConfig.mapInfo.multiNavi);
        }
        ArrayList<MapFilterValue> naviValue = new ArrayList<>();
        naviValue.add(new MapFilterValue("default",SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI) + "/" +
                SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI)));
        navi.setValue(naviValue);
        listItem.add(0, navi);

        for (MapFilterResponse data : listItem) {
            if(!TextUtils.isEmpty(data.getAllYn()) && data.getAllYn().equalsIgnoreCase("Y")) {
                boolean isContain = false;
                for(MapFilterValue value : data.getValue()) {
                    if(value.getName().equalsIgnoreCase("전체")) {
                        isContain = true;
                    }
                }
                if(!isContain) {
                    data.getValue().add(0 , new MapFilterValue("","전체"));
                }
            }
            data.selected.add(data.getValue().get(0));
        }

        adapter = new FilterAdapter(listItem);
        adapter.setOnItemClickListener((v, data) -> {
            if (listener != null) {
                listener.onItemClick(v.getTag().toString(), data);
            }
        });
        recyclerView.setAdapter(adapter);
    }

    public void update(String category, ArrayList<MapFilterValue> data) {
        ArrayList<MapFilterResponse> filters = adapter.getFilters();

        for (MapFilterResponse items : filters) {
            if (items.getCategory().equals(category)) {
                items.selected = data;
            }
        }
        adapter.setFilters(filters);
    }

    public interface OnStateListener {
        void onItemClick(String tag, MapFilterResponse data);
        void onSearch(ArrayList<MapFilterResponse> filters);
        void onBackPress();
    }
}
