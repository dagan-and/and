package com.daquv.sdk.presentation;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.ui.comm.ComDialogBuilder;
import com.daquv.sdk.ui.component.BasicButtonView;

import java.util.List;
import java.util.Locale;

public class ConsultFragment extends Fragment  {

    private static final long MAX_RECORD_MINUTE = 10;
    private static final long TIMER_DELAY_MILLIS = 1000L;

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    DaquvEngine.Callback engineCallback;

    private Handler timerHandler;
    private Runnable timerRunnable;
    private int totalSeconds = 0;
    private ScrollView scrollView;
    private TextView secondView;
    private TextView minuteView;
    private TextView endView;
    private TextView sttContents;
    private BasicButtonView btnComplete;
    private StringBuilder finalString;
    private String companyId;
    private String companyName;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_consult, container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        TextView address = view.findViewById(R.id.address);
        address.setText(getAddress(DaquvSDK.getInstance().getLocation()));

        timerHandler = new Handler();
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                totalSeconds++;
                if(totalSeconds == MAX_RECORD_MINUTE * 60) {
                    endView.setText("1");
                    endView.setTextColor(ContextCompat.getColor(requireContext(),R.color.dqv_text_base));
                    timerHandler.removeCallbacks(timerRunnable);
                    btnComplete.callOnClick();
                    return;
                }
                updateTimerDisplay();
                timerHandler.postDelayed(this, TIMER_DELAY_MILLIS);
            }
        };

        scrollView = view.findViewById(R.id.scroll_view);
        sttContents = view.findViewById(R.id.stt_contents);
        secondView = view.findViewById(R.id.time_second);
        minuteView = view.findViewById(R.id.time_minute);
        endView = view.findViewById(R.id.time_end);
        btnComplete = view.findViewById(R.id.btn_complete);

        view.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressedCallback.handleOnBackPressed();
            }
        });

        btnComplete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ComDialogBuilder dialogBuilder = new ComDialogBuilder(requireContext());
                dialogBuilder.showAlert(new ComDialogBuilder.OnCommDlgClickListener() {
                    @Override
                    public void onLeftButton() {

                    }

                    @Override
                    public void onRightButton() {
                        timerHandler.removeCallbacks(timerRunnable);
                        DaquvSDK.getInstance().getEngine().stopEngine();
                        listener.addConsultEditView(companyId, companyName, sttContents.getText().toString());
                    }

                    @Override
                    public void onDismiss() {}
                }, getString(R.string.record_save), getString(R.string.dqv_no), getString(R.string.dqv_yes));
            }
        });

        finalString = new StringBuilder();

        ComDialogBuilder builder = new ComDialogBuilder(getContext());
        builder.showConfirm(new ComDialogBuilder.OnCommDlgClickListener() {
            @Override
            public void onLeftButton() {

            }

            @Override
            public void onRightButton() {

            }

            @Override
            public void onDismiss() {
                DaquvSDK.getInstance().stopTTS();
                DaquvSDK.getInstance().getEngine().startEngineContinue();
                timerHandler.postDelayed(timerRunnable, TIMER_DELAY_MILLIS);
            }
        } , getString(R.string.consult_warning_msg) , getString(R.string.dqv_confirm));
        DaquvSDK.getInstance().getAPI().getTTSBinary(getString(R.string.consult_warning_msg));
    }


    private void updateTimerDisplay() {
        int second = totalSeconds;
        int remainingSeconds = second % 3600;
        int minutes = remainingSeconds / 60;
        int seconds = remainingSeconds % 60;

        secondView.setText(String.format("%02d", seconds));
        minuteView.setText(String.format("%d", minutes));
    }


    private String getAddress(Location location) {
        try {
            List<Address> addresses = new Geocoder(getContext(), Locale.KOREA)
                    .getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            if (!addresses.isEmpty()) {
                Address address = addresses.get(0);
                String adminArea = address.getAdminArea(); // 행정 구역 (서울특별시)
                String locality = address.getLocality(); // 관할 구역 (중구)
                String thoroughfare = address.getSubLocality(); // 상세 구역 (봉래동2가)
                String featureName = address.getSubThoroughfare(); // 상세 주소 (122-21)
                if(featureName != null) {
                    return thoroughfare + featureName;
                } else {
                    return locality + locality;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return getAddress(location);
        }
        return null;
    }

    public void setCompanyInfo(String companyId, String companyName) {
        this.companyId = companyId;
        this.companyName = companyName;
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                ComDialogBuilder dialogBuilder = new ComDialogBuilder(requireContext());
                dialogBuilder.showAlert(new ComDialogBuilder.OnCommDlgClickListener() {
                    @Override
                    public void onLeftButton() {

                    }
                    @Override
                    public void onRightButton() {
                        timerHandler.removeCallbacks(timerRunnable);
                        DaquvSDK.getInstance().getEngine().stopEngine();
                        listener.onBackPress(ConsultFragment.this);
                    }

                    @Override
                    public void onDismiss() {}
                }, getString(R.string.consult_cancel_title),getString(R.string.consult_cancel_message), getString(R.string.dqv_no), getString(R.string.dqv_yes));
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);


        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);

                if(code == DaquvConfig.CODE.ENGINE_RUNNING_DATA) {
                    sttContents.setText(finalString.toString() + result);
                    scrollView.fullScroll(ScrollView.FOCUS_DOWN);
                }

                if(code == DaquvConfig.CODE.ENGINE_CONTINUE_DATA) {
                    finalString.append((String) result);
                    sttContents.setText(finalString);
                    scrollView.fullScroll(ScrollView.FOCUS_DOWN);
                }
            }
        };
        DaquvSDK.getInstance().addCallBack(engineCallback);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        DaquvSDK.getInstance().getEngine().stopEngine();
        timerHandler.removeCallbacks(timerRunnable);
        onBackPressedCallback.remove();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
    }

}
