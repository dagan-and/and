package com.daquv.sdk.ui.adapter;

import android.animation.LayoutTransition;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.LocationItem;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class MapMarkerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int MARKER = 0;
    public static final int NAVI = 1;

    private int type = MARKER;
    private final ArrayList<LocationItem> naviItems = new ArrayList<>();
    private ArrayList<LocationItem> makerItems = new ArrayList<>();
    private final Context context;

    public interface OnItemClickListener {
        void onItemClick(View v, LocationItem data);
    }

    private OnItemClickListener listener = null;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public MapMarkerAdapter(Context ctx) {
        context = ctx;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflateView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_map, parent, false);
        return new DataHolder(inflateView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        LocationItem items = makerItems.get(position);
        if (holder instanceof DataHolder) {
            DataHolder dataHolder = (DataHolder) holder;
            dataHolder.name.setText(items.getCompanyNm().trim());

            if (!TextUtils.isEmpty(items.getIbtrYN()) && "Y".equalsIgnoreCase(items.getIbtrYN())) {
                dataHolder.trade.setText(context.getString(R.string.map_trade));
                dataHolder.trade.setBackgroundResource(R.drawable.map_textbox_on);
            } else {
                dataHolder.trade.setText(context.getString(R.string.map_no_trade));
                dataHolder.trade.setBackgroundResource(R.drawable.map_textbox_off);
            }

            String total = "IBK(총여신) " +
                    getCurrencyForm((items.getIbkKcisEninBal() + items.getAnoKcisEninBal()))
                    + "백만원";
            dataHolder.totalCredit.setText(total);

            String ibkKcis = "";
            if(items.getIbkKcisEninBal() > 0) {
                ibkKcis += ("(IBK) " + getCurrencyForm(items.getIbkKcisEninBal()) + "백만원");
            } else {
                ibkKcis += ("(IBK) 0원");
            }
            dataHolder.ibkCredit.setText(ibkKcis);
            String anoKcis = "";
            if(items.getIbkKcisEninBal() > 0) {
                anoKcis += ("(타행) " + getCurrencyForm(items.getIbkKcisEninBal()) + "백만원");
            } else {
                anoKcis += ("(타행) 0원");
            }
            dataHolder.anoCredit.setText(anoKcis);

            String distance;
            if (items.getDistance() < 1000.0) {
                distance = (int) items.getDistance() + "m";
            } else {
                distance = String.format("%.2f", items.getDistance() / 1000.0) + "km";
            }

            dataHolder.distance.setText(distance + " " + items.getAddress());
            setNaviImage(dataHolder.navi , items);

            if(type == MARKER) {
                dataHolder.search.setVisibility(View.VISIBLE);
                dataHolder.navi.setVisibility(View.GONE);
            } else if(type == NAVI) {
                dataHolder.search.setVisibility(View.GONE);
                dataHolder.navi.setVisibility(View.VISIBLE);
            }

            dataHolder.search.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setTag("Navi");
                    if (listener != null) {
                        listener.onItemClick(v, items);
                    }
                }
            });
            dataHolder.container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setTag("Container");

                    if(type == NAVI) {
                        if(isContainNaviItems(items)) {
                            naviItems.remove(items);
                            setNaviImage(dataHolder.navi, items);
                        } else if(naviItems.size() < 6){
                            naviItems.add(items);
                            setNaviImage(dataHolder.navi, items);
                        } else if(naviItems.size() == 6) {
                            Toast.makeText(context, context.getString(R.string.map_route_max), Toast.LENGTH_SHORT).show();
                        }
                        notifyDataSetChanged();
                        return;
                    }

                    if (listener != null) {
                        listener.onItemClick(v, items);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return makerItems.size();
    }


    public void setMakerItems(ArrayList<LocationItem> makerItems) {
        if (makerItems != null && !makerItems.isEmpty()) {
            this.makerItems = makerItems;
        }
    }

    public void setType(int type) {
        this.type = type;
        if(type == MARKER) {
            this.naviItems.clear();
        }
        notifyChanged();
    }

    public int getType() {
       return type;
    }

    public void clearNaviItems() {
        this.naviItems.clear();
        notifyChanged();
    }

    public void notifyChanged() {
        notifyItemRangeChanged(0, getItemCount(), true);
    }

    public ArrayList<LocationItem> getNaviItems() {
        return this.naviItems;
    }


    private boolean isContainNaviItems(LocationItem items) {
        return naviItems.contains(items);
    }

    private void setNaviImage(ImageView naviImage , LocationItem item) {
        if(isContainNaviItems(item)) {
            int index = naviItems.indexOf(item);
            if(index == naviItems.size() - 1) {
                naviImage.setImageResource(R.drawable.btn_map_checked_06);
            } else {
                if(index == 0) {
                    naviImage.setImageResource(R.drawable.btn_map_checked_01);
                } else if(index == 1) {
                    naviImage.setImageResource(R.drawable.btn_map_checked_02);
                } else if(index == 2) {
                    naviImage.setImageResource(R.drawable.btn_map_checked_03);
                } else if(index == 3) {
                    naviImage.setImageResource(R.drawable.btn_map_checked_04);
                } else if(index == 4) {
                    naviImage.setImageResource(R.drawable.btn_map_checked_05);
                }
            }
        } else {
            naviImage.setImageResource(R.drawable.btn_map_plus);
        }
    }

    private String getCurrencyForm(int number) {
        //숫자 천 단위 콤마
        DecimalFormat decimal = new DecimalFormat("#,###");
        return decimal.format(number);
    }

    static class DataHolder extends RecyclerView.ViewHolder {
        ConstraintLayout container;
        TextView name;
        LinearLayoutCompat search;
        ImageView navi;
        TextView trade;
        TextView totalCredit;
        TextView ibkCredit;
        TextView anoCredit;
        TextView distance;

        DataHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.container);
            name = itemView.findViewById(R.id.name);
            search = itemView.findViewById(R.id.btn_search);
            navi = itemView.findViewById(R.id.btn_navi);
            trade = itemView.findViewById(R.id.type_trade);
            totalCredit = itemView.findViewById(R.id.total_credit);
            ibkCredit = itemView.findViewById(R.id.ibk_credit);
            anoCredit = itemView.findViewById(R.id.ano_credit);
            distance = itemView.findViewById(R.id.distance);

            LayoutTransition lt = new LayoutTransition();
            lt.disableTransitionType(LayoutTransition.DISAPPEARING);
            container.setLayoutTransition(lt);
        }
    }
}
