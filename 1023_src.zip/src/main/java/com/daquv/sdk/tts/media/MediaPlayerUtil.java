package com.daquv.sdk.tts.media;

import static android.media.AudioAttributes.ALLOW_CAPTURE_BY_NONE;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;

import android.media.MediaPlayer;
import android.os.Build;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.secure.PreventRecordUtils;

import java.io.FileOutputStream;

public class MediaPlayerUtil {
    private static final String TAG = MediaPlayerUtil.class.getSimpleName();

    private final Context context;
    private MediaPlayer mediaPlayer;
    private boolean isPrepared;
    private int currentPosition = 0;
    private String mediaData;
    private MediaPlayerHelper.OnMediaCallbackListener mediaCallback;

    public MediaPlayerUtil(Context context) {
        this.context = context;
    }

    /**
     * 미디어를 재생시킬 PLAYER 를 init 한다. PCM_STREAM 제외
     **/
    private MediaPlayer initPlayer() {
        try {

            if (mediaData.equals("null") || mediaData == null || mediaData.isEmpty()) {
                if (mediaCallback != null) mediaCallback.onFinish();
                return null;
            }

            MediaPlayer mediaPlayer = new MediaPlayer();


            mediaPlayer.setDataSource(base64StringToFile(mediaData));

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                if (SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, true)) {
                    AudioAttributes aa = (new AudioAttributes.Builder())
                            .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_SYSTEM)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build();
                    mediaPlayer.setAudioAttributes(aa);
                } else {
                    AudioAttributes aa = (new AudioAttributes.Builder())
                            .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_SYSTEM)
                            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                            .build();
                    mediaPlayer.setAudioAttributes(aa);
                }
            } else {
                if (SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, true)) {
                    mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                } else {
                    mediaPlayer.setAudioStreamType(AudioManager.STREAM_VOICE_CALL);
                }
            }

            mediaPlayer.setVolume(1, 1);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mediaPlayer.setPlaybackParams( mediaPlayer.getPlaybackParams().setSpeed(1f));
            }
            mediaPlayer.setOnPreparedListener(mp -> {

                if (PreventRecordUtils.getInstance().isAudioRecording()) {
                    Logger.dev("PreventRecordUtils isAudioRecording");
                    Toast.makeText(context, context.getString(R.string.secure_tts), Toast.LENGTH_SHORT).show();
                    return;
                }
                if (SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_USE_TTS, true) &&
                        !DaquvSDK.getInstance().getEngine().isRunning() &&
                        DaquvConfig.ttsSession != 0) {
                    Logger.dev("playMedia onPrepared");
                    isPrepared = true;
                    start(true);
                }
            });
            mediaPlayer.setOnCompletionListener(mp -> {
                if (!isPrepared) return;
                isPrepared = false;

                Logger.dev("playMedia onCompletion");
                if (mediaCallback != null) mediaCallback.onFinish();
            });
            mediaPlayer.setOnErrorListener((mp, i, i1) -> {
                Logger.dev("playMedia onError : " + i + ", " + i1);
                // 에러 났을 때도 stopAndRunActOnOther 실행
                return false;
            });
            mediaPlayer.setOnBufferingUpdateListener((mp, i) -> {
                Logger.dev("playMedia onBufferingUpdate : " + i);
            });
            return mediaPlayer;


        } catch (Exception e) {
            Log.i(TAG, "initPlayer Exception : " + e);
        }
        return null;
    }

    private void initAndPrepareAsync() {
        mediaPlayer = initPlayer();
        if (mediaPlayer != null) {
            mediaPlayer.prepareAsync();
        } else {
            Logger.error("미디어 생성 실패");
        }
    }

    void playWav(String audioData, MediaPlayerHelper.OnMediaCallbackListener callback) {
        mediaCallback = callback;
        mediaData = audioData;
        release();
        // voice 처리
        initAndPrepareAsync();
    }


    /**
     * 미디어 플레이어를 play 시킨다.
     * isFirstStart true : started, false : resumed
     **/
    void start(boolean isFirstStart) {
        Logger.dev("start!!!!!!!!!: ");
        try {
            if (mediaPlayer != null && isPrepared) {
                if (currentPosition > 0) {
                    mediaPlayer.seekTo(currentPosition);
                }
                mediaPlayer.start();
            }
        } catch (Exception e) {
            Log.i(TAG, "start Exception : " + e);
        }
    }

    /**
     * 미디어 플레이어를 pause 시킨다.
     **/
    void pause() {
        try {
            if (mediaPlayer != null && isPrepared) {
                mediaPlayer.pause();
            }
        } catch (Exception e) {
            Log.i(TAG, "pause Exception : " + e);
        }
    }

    /**
     * 미디어 플레이어를 mute 시키거나 해제한다.
     **/
    void mute(boolean mute) {
        try {
            if (mediaPlayer != null && isPrepared)
                mediaPlayer.setVolume(mute ? 0 : 1, mute ? 0 : 1);
        } catch (Exception e) {
            Log.i(TAG, "mute Exception : " + e);
        }
    }

    /**
     * 미디어 플레이어의 재생중 여부를 리턴한다.
     **/
    boolean isPlaying() {
        try {
            if (mediaPlayer != null) return mediaPlayer.isPlaying();
        } catch (Exception e) {
            Log.i(TAG, "isPlaying Exception : " + e);
        }
        return false;
    }

    /**
     * 미디어 플레이어를 전화/외장 스피커로 송출한다
     */
    void updateStreamMode() {
        if (mediaPlayer != null) {
            currentPosition = mediaPlayer.getCurrentPosition();
            if (mediaPlayer.getCurrentPosition() - 500 > 0) {
                currentPosition = mediaPlayer.getCurrentPosition() - 500;
            } else {
                currentPosition = mediaPlayer.getCurrentPosition();
            }
            release();
            initAndPrepareAsync();
        }
    }

    /**
     * currentPosition 초기화
     */
    void iniCurrentPosition() {
        currentPosition = 0;
    }

    /**
     * 재생중인 미디어를 stop 하고 미디어 플레이어를 Release 시킨다.
     **/
    void stop() {
        release();
    }

    /**
     * 미디어 플레이어와 오디오트랙을 release 시킨다.
     **/
    private void release() {
        releaseMediaPlayer();
    }

    private void releaseMediaPlayer() {
        Log.i(TAG, "releaseMediaPlayer()");
        try {
            if (mediaPlayer != null) {
                mediaPlayer.release();
                mediaPlayer = null;
            }
        } catch (Exception e) {
            Log.i(TAG, "releaseMediaPlayer Exception : " + e);
        }
        isPrepared = false;
    }

    void reset() {
        release();
    }


    //임시 wav file write
    public String base64StringToFile(String base64AudioData) {
        try {
            byte[] decoded = Base64.decode(base64AudioData, 1);
            FileOutputStream os = context.openFileOutput("temp.mp3", Context.MODE_PRIVATE);
            os.write(decoded);
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return context.getFileStreamPath("temp.mp3").getAbsolutePath();
    }
}