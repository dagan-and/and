package com.daquv.sdk.data.crm.request;

import android.content.Context;

import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.network.TranJson;


/**
 * 인증번호 검증 통신 데이터
 */
public class REQ_SVC_C028 extends TranJson {

    /** 통신 요청 구분 코드 */
    public static final String TRAN_ID = "APP_SVC_C028";

    /*
        CLPH_NO		휴대폰번호
        TRSC_UNQ_NO		거래고유번호
        SMS_CERT_NO		SMS인증번호
        USER_INFO		연계사용자정보		C	500	○
        APP_ID		앱ID
     */
    public static final String  CLPH_NO         = "CLPH_NO";
    public static final String  TRSC_UNQ_NO     = "TRSC_UNQ_NO";
    public static final String  SMS_CERT_NO     = "SMS_CERT_NO";
    public static final String  USER_INFO       = "USER_INFO";
    public static final String  APP_ID          = "APP_ID";


    /**
     * 생성자
     */
    public REQ_SVC_C028(String appId, String clphNo, String trscUnqNo, String smsCertNo) {
        super(TRAN_ID);
        put(CLPH_NO, clphNo);
        put(TRSC_UNQ_NO, trscUnqNo);
        put(SMS_CERT_NO, smsCertNo);
        put(APP_ID, appId);
    }
}
