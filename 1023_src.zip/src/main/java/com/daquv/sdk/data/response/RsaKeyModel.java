package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class RsaKeyModel implements Serializable {
    @SerializedName("timestamp")
    private String timestamp;

    @SerializedName("status")
    private int status;

    @SerializedName("retCd")
    private String retCd;

    @SerializedName("body")
    private RsaKeyResponse body;

    public RsaKeyModel() {
    }

    public RsaKeyModel(String timestamp, int status, String retCd, RsaKeyResponse body) {
        this.timestamp = timestamp;
        this.status = status;
        this.retCd = retCd;
        this.body = body;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getRetCd() {
        return retCd;
    }

    public void setRetCd(String retCd) {
        this.retCd = retCd;
    }

    public RsaKeyResponse getBody() {
        return body;
    }

    public void setBody(RsaKeyResponse body) {
        this.body = body;
    }
}