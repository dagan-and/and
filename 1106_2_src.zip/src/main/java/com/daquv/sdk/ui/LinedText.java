package com.daquv.sdk.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;

import androidx.appcompat.widget.AppCompatTextView;

public class LinedText extends AppCompatTextView {
    private final Paint mPaint = new Paint();

    public LinedText(Context context) {
        super(context);
        initPaint();
    }

    public LinedText(Context context, AttributeSet attrs) {
        super(context, attrs);
        initPaint();
    }

    public LinedText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initPaint();
    }

    private void initPaint() {
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setColor(0x80000000);
    }

    @Override protected void onDraw(Canvas canvas) {
        int left = getLeft();
        int right = getRight();
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int paddingLeft = getPaddingLeft();
        int paddingRight = getPaddingRight();
        int height = getHeight();
        int lineHeight = getLineHeight();
        int count = (height-paddingTop-paddingBottom) / lineHeight;

        //IOS 와 개발 싱크 맞추기 위한 임의 주석처리
//        for (int i = 0; i < count; i++) {
//            int baseline = lineHeight * (i+1) + convertDPtoPX(getContext() , 32);
//            canvas.drawLine(left+paddingLeft, baseline, right-paddingRight, baseline, mPaint);
//        }

        super.onDraw(canvas);
    }

    public static int convertDPtoPX(Context context, int dp) {
        float density = context.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
