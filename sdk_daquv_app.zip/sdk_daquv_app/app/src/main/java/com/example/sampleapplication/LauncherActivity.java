package com.example.sampleapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.presentation.DaquvView;


public class LauncherActivity extends AppCompatActivity {
    private static final int REQUEST_PERMISSION = 999;
    private DaquvView daquvView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);
        daquvView = findViewById(R.id.daquv_view);


//        String scheme = "nmap://route/car?slat=37.3595953&slng=127.1053971&sname=%EA%B7%B8%EB%A6%B0%ED%8C%A9%ED%86%A0%EB%A6%AC" +
//                "&dlng=127.1267772&dlat=37.4200267&dname=%EC%84%B1%EB%82%A8%EC%8B%9C%EC%B2%AD" +
//                "&v1lng=126.9522394&v1lat=37.464007&v1name=%20%EC%84%9C%EC%9A%B8%EB%8C%80%ED%95%99%EA%B5%90" +
//                "&v2lng=127.137682&v2lat=37.433074&v2name=%EC%84%B1%EB%82%A8%EC%A2%85%ED%95%A9%EC%9A%B4%EB%8F%99%EC%9E%A5" +
//                "&v3lng=127.139009&v3lat=37.445158&v3name=%EC%84%B1%EB%82%A8%EC%8B%9C%EC%9D%98%EB%A3%8C%EC%9B%90" +
//                "&v4lng=127.159736&v4lat=37.403898&v4name=%ED%95%9C%EA%B5%AD%EC%A0%84%EC%9E%90%EA%B8%B0%EC%88%A0%EC%97%B0%EA%B5%AC%EC%9B%90" +
//                "&v5lng=127.121663&v5lat=37.388305&v5name=%EB%B6%84%EB%8B%B9%EC%A0%9C%EC%83%9D%EB%B3%91%EC%9B%90" +
//                "&appname=com.example.myapp";
//        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
//        startActivity(intent);

//        String scheme = "tmap://route?startx=127.1053971&starty=37.3595953&startname=그린팩토리" +
//                "&goalx=127.1267772&goaly=37.4200267&goalname=성남시청" +
//                "&vialist=[{\"poiName\":\"서울대학교\",\"navX\":\"126.9522394\",\"navY\":\"37.464007\"}," +
//                "{\"poiName\":\"성남종합운동장\",\"navX\":\"127.137682\",\"navY\":\"37.433074\"}," +
//                "{\"poiName\":\"성남시의료원\",\"navX\":\"127.139009\",\"navY\":\"37.445158\"}," +
//                "{\"poiName\":\"한국전자기술연구원\",\"navX\":\"127.159736\",\"navY\":\"37.403898\"}," +
//                "{\"poiName\":\"분당제생병원\",\"navX\":\"127.121663\",\"navY\":\"37.388305\"}]";
//
//        try {
//            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
//            startActivity(intent);
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }

        //오디오 , 위치 권한 체크
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            android.Manifest.permission.RECORD_AUDIO,
                            android.Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    }, REQUEST_PERMISSION);
            return;
        }
        init();
    }

    private void init() {
        daquvView.setFragmentManager(getSupportFragmentManager());
        daquvView.setLoginInfo("CRM", "017268", "ibkCrm", "test@istn.co.kr","12345","istnT1");
        daquvView.setViewListener(new DaquvView.ViewListener() {
            @Override
            public void onAttached() {
                //다큐브 뷰 추가 완료
            }

            @Override
            public void onDetached() {
                //다큐브 뷰 제거시
                finish();
            }
        });
        daquvView.launch();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                init();
            } else {
                Toast.makeText(this, "오디오 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        DaquvSDK.getInstance().onDestroy();
        super.onDestroy();
    }
}