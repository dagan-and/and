package com.daquv.sdk.presentation;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.Entities;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.webview.ComWebView;

import org.json.JSONObject;

import java.util.ArrayList;

public class MainFragment extends Fragment  {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_main , container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onBackPress(null);
            }
        });

        ComWebView webView = view.findViewById(R.id.main_web);
        webView.loadMainPage();
        webView.addListener(new ComWebView.OnWebActionListener() {
            @Override
            public void onShortCut(String utterance) {
                listener.showLoading();
                DaquvConfig.inputType = DaquvConfig.INPUT_TYPE.TOUCH;
                DaquvSDK.getInstance().getAPI().getNLUData(utterance);
            }

            @Override
            public void onClose() {
                listener.onBackPress(null);
            }

            @Override
            public void onSTT(boolean start) {
                if(start) {
                    listener.addVoiceView();
                } else {
                    listener.removeVoiceView();
                }
            }

            @Override
            public void onHome() {
                listener.addMainView(false);
            }

            @Override
            public void onSetting() {
                listener.addSettingView();
            }

            @Override
            public void onConsult(String companyId, String companyNm) {
                if(TextUtils.isEmpty(companyId) || TextUtils.isEmpty(companyNm)) {
                    listener.addVoiceView("상담내용 등록", null);
                } else {
                    listener.addConsultView(companyId, companyNm);
                }
            }

            @Override
            public void onMap(String name, String lat , String lon) {
                if(lat != null && lon != null) {
                    DaquvSDK.getInstance().getAPI().getMapData(name, lat, lon ,
                            DaquvConfig.defaultRadius);
                } else {
                    DaquvSDK.getInstance().getAPI().getMapData("내 위치",String.valueOf(DaquvSDK.getInstance().getLocation().getLatitude()),
                            String.valueOf(DaquvSDK.getInstance().getLocation().getLongitude()),
                            DaquvConfig.defaultRadius);
                }
            }

            @Override
            public void onNavi(ArrayList<LocationItem> items) {
                if(items.size() == 2) {
                    if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_tmap))) {
                        DaquvUtil.runTMap(requireContext(), items);
                    } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_kakao))) {
                        DaquvUtil.runKakaoMap(requireContext(), items);
                    } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_naver))) {
                        DaquvUtil.runNaverMap(requireContext(), items);
                    }
                } else {
                    if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(getString(R.string.map_tmap))) {
                        DaquvUtil.runTMap(requireContext(), items);
                    } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(getString(R.string.map_naver))) {
                        DaquvUtil.runNaverMap(requireContext(), items);
                    }
                }
            }

            @Override
            public void onCall(String number) {
                Intent tt = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
                startActivity(tt);
            }

            @Override
            public void onCapture() {
                //지원하지 않음
            }

            @Override
            public void onBottomView(boolean isVisible) {/*NONE*/}

            @Override
            public void onPageLoad(boolean loading) {/*NONE*/}

            @Override
            public void onReload() {

            }

            @Override
            public void onBrowser(String url) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
            }

            @Override
            public void onDataPage(String json) {
                Logger.info(json);
                try {
                    JSONObject jsonObject = new JSONObject(json);
                    NLUResultResponse nluResultResponse = new NLUResultResponse();
                    nluResultResponse.setUrl(jsonObject.optString("url"));
                    nluResultResponse.setIntent(jsonObject.optString("intent_code"));

                    ArrayList<Entities> entities = new ArrayList<>();
                    if(!TextUtils.isEmpty(jsonObject.optString("COUNTERPARTNAME"))) {
                        entities.add(new Entities("COUNTERPARTNAME", jsonObject.optString("COUNTERPARTNAME"),null,null));
                    }
                    if(!TextUtils.isEmpty(jsonObject.optString("COMPANYID"))) {
                        entities.add(new Entities("COMPANYID", jsonObject.optString("COMPANYID"),null,null));
                    }
                    nluResultResponse.setEntities(entities);
                    listener.showLoading();
                    DaquvConfig.inputType = DaquvConfig.INPUT_TYPE.TOUCH;
                    DaquvSDK.getInstance().getAPI().getResultPage(nluResultResponse);
                } catch (Exception e) {
                    Logger.error(e);
                }
            }
        });
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress(null);
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        onBackPressedCallback.remove();
    }
}
