package com.daquv.sdk.presentation;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.airbnb.lottie.LottieAnimationView;
import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.CusInfoResponse;
import com.daquv.sdk.data.response.Entities;
import com.daquv.sdk.data.response.LocationItemResponse;
import com.daquv.sdk.data.response.LoginTokenResponse;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.ui.SpeakerView;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;

import java.util.ArrayList;
import java.util.List;

public class DaquvView extends ConstraintLayout implements View.OnClickListener {

    public DaquvView(@NonNull Context context) {
        super(context);
        init();
    }

    public DaquvView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public DaquvView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }


    public interface ViewListener {
        void onAttached();

        void onDetached();
    }

    public interface FragmentListener {
        void onBackPress(Fragment fragment);

        void addArgumentView();

        void addHTMLView(String title, String url, HTMLFragment.Listener htmlListener);

        void addMainView(boolean sttStart);

        void addDataView();

        void removeDataView();

        void addMapView(LocationItemResponse items);

        void addConsultView(String companyId, String companyNm);

        void addConsultEditView(String companyId, String companyNm, String contents);

        void addVoiceView();

        void addVoiceView(String directMove, String reask);

        void removeVoiceView();

        void addKeypadView(boolean isCompnaySearch, boolean isAddressSearch);

        void addSettingView();

        void showLoading();

        void hideLoading();

        void bottomSTTView(boolean isVisible);

        void startTurnSTT(boolean isStart);

        void startSTT();

        void login(Boolean agreeArgument);

        void splash();

        void updateSpeaker();
    }

    String[] loginInfo;
    RelativeLayout loadingView;
    FrameLayout bottomContainer;
    FrameLayout mainView;
    FragmentManager fragmentManager;
    FragmentListener listener;
    DaquvEngine.Callback sdkCallback;
    LottieAnimationView micView;
    LottieAnimationView sttView;
    SpeakerView speakerView;
    LottieAnimationView loadingImage;
    ViewListener viewListener;
    LoginTokenResponse loginTokenResponse;

    private void init() {
        initView();
        setWhiteStatusBarMode((Activity) getContext(), false);
        setVisibility(View.VISIBLE);
    }

    public void launch() {
        if (!DaquvSDK.getInstance().checkPermission(getContext())) {
            return;
        }

        setBackgroundColor(ContextCompat.getColor(getContext(), R.color.dqv_white));

        sdkCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);
                if (code == DaquvConfig.CODE.API_MAIN_DATA) {
                    listener.addMainView(true);
                    if (viewListener != null) {
                        viewListener.onAttached();
                    }
                    DaquvSDK.getInstance().getAppConfig(getContext());
                    DaquvSDK.getInstance().getAPI().getMapFilter();
                    DaquvSDK.getInstance().getAPI().getCommCode();
                }

                if (code == DaquvConfig.CODE.API_LOGIN) {
                    if (SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_ARGUMENT_POLICY_AGREE)) {
                        DaquvSDK.getInstance().getAPI().getMainPage(DaquvUtil.getUrl("/webview/ibkCrm/v1/cmn/main"));
                    } else {
                        listener.addArgumentView();
                    }
                    if(result instanceof LoginTokenResponse) {
                        loginTokenResponse =  (LoginTokenResponse)result;
                    }
                }

                if (code == DaquvConfig.CODE.ENGINE_START_VOICE) {
                    micView.setAnimation(R.raw.main_mic_color_ibk);
                    micView.playAnimation();
                    sttView.setAnimation(R.raw.main_mic_color_ibk);
                    sttView.playAnimation();
                }

                if (code == DaquvConfig.CODE.ENGINE_STOP_VOICE) {
                    micView.cancelAnimation();
                    micView.setImageResource(R.drawable.img_main_pause);
                    sttView.cancelAnimation();
                    sttView.setImageResource(R.drawable.img_main_pause);
                }

                if(code == DaquvConfig.CODE.API_NLU_REASK) {
                    if(DaquvConfig.inputType == DaquvConfig.INPUT_TYPE.KEYBOARD ||
                            DaquvConfig.inputType == DaquvConfig.INPUT_TYPE.TOUCH) {
                        listener.addVoiceView(null , (String) result);
                    }
                }

                if(code == DaquvConfig.CODE.API_NLU) {
                    listener.showLoading();
                }

                if (code == DaquvConfig.CODE.API_ERROR ||
                        code == DaquvConfig.CODE.API_NLU_SUCCESS ||
                        code == DaquvConfig.CODE.API_NLU_FAIL ||
                        code == DaquvConfig.CODE.API_NLU_REASK ||
                        code == DaquvConfig.CODE.API_NLU_MAP ||
                        code == DaquvConfig.CODE.API_NLU_CONSULT ||
                        code == DaquvConfig.CODE.API_GET_CUSINFO
                ) {
                    listener.hideLoading();
                }

                if (code == DaquvConfig.CODE.API_ERROR ||
                        code == DaquvConfig.CODE.API_NLU_SUCCESS ||
                        code == DaquvConfig.CODE.API_NLU_MAP ||
                        code == DaquvConfig.CODE.API_NLU_CONSULT ||
                        code == DaquvConfig.CODE.API_GET_CUSINFO
                ) {
                    listener.removeVoiceView();
                }

                if (code == DaquvConfig.CODE.API_NLU_SUCCESS) {
                    listener.addDataView();
                }

                if (code == DaquvConfig.CODE.API_NLU_MAP) {
                    if (result instanceof LocationItemResponse &&
                            ((LocationItemResponse) result).getBody() != null &&
                            ((LocationItemResponse) result).getCount() > 0) {
                        listener.addMapView(((LocationItemResponse) result));
                    } else if (result instanceof LocationItemResponse) {
                        listener.addMapView(((LocationItemResponse) result));
                    }
                }

                if(code == DaquvConfig.CODE.API_GET_CUSINFO) {
                    listener.addConsultView( ((CusInfoResponse) result).getCompanyId(),
                            ((CusInfoResponse) result).getCmunNm());
                }

            }
        };

        listener = new FragmentListener() {
            @Override
            public void onBackPress(Fragment fragment) {

                //답변화면 2개일때 백키 처리하기
                //TTS API 도중 중단 처리 하지 말고 , TTS 할때 답변화면의 고유값 넣어서

                Logger.dev("=====onBackPress=====");

                String message = "fragment::";
                for (Fragment stack : fragmentManager.getFragments()) {
                    message += (stack.getTag() + ",");
                }
                Logger.dev(message);

                if (fragmentManager.getFragments().size() > 1) {

                    if (fragment != null) {
                        FragmentTransaction removeTransaction = fragmentManager.beginTransaction();
                        removeTransaction.setCustomAnimations(0,
                                R.anim.slide_out_right,
                                0, 0);
                        removeTransaction.remove(fragment)
                                .commitAllowingStateLoss();
                        return;
                    }

                    fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    Logger.dev("popBackStack(POP_BACK_STACK_INCLUSIVE)");
                } else {
                    onDestroy();
                    Logger.dev("onDestroy");
                }

                Logger.dev("=====onBackPress=====");
            }

            @Override
            public void addArgumentView() {
                ArgumentFragment data = new ArgumentFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(mainView.getId(), data, "Argument")
                        .commitAllowingStateLoss();
            }

            @Override
            public void addHTMLView(String title, String url, HTMLFragment.Listener htmlListener) {
                boolean hasHTMLView = false;
                Fragment hasFragment = null;
                for (Fragment fragment : fragmentManager.getFragments()) {
                    if ("HTML".equals(fragment.getTag())) {
                        hasHTMLView = true;
                        hasFragment = fragment;
                    }
                }
                HTMLFragment data = new HTMLFragment();
                data.setListener(listener);
                data.setHtmlListener(htmlListener);
                data.setTitle(title);
                data.setUrl(url);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(0, 0, 0, 0);
                if (hasHTMLView) {
                    fragmentTransaction.remove(hasFragment);
                }
                fragmentTransaction.add(mainView.getId(), data, "HTML")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void addMainView(boolean sttStart) {
                MainFragment data = new MainFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(mainView.getId(), data, "Main")
                        .commitAllowingStateLoss();
                speakerView.updateView();
                bottomContainer.setVisibility(View.VISIBLE);
            }

            @Override
            public void addDataView() {
                boolean hasView = false;
                Fragment hasFragment = null;
                for (Fragment fragment : fragmentManager.getFragments()) {
                    if ("Data".equals(fragment.getTag())) {
                        hasView = true;
                        hasFragment = fragment;
                    }
                }
                DataFragment data = new DataFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.slide_in_right,
                        R.anim.slide_out_left,
                        R.anim.slide_in_left,
                        R.anim.slide_out_right);
                if (hasView) {
                    fragmentTransaction.remove(hasFragment);
                }
                fragmentTransaction.add(mainView.getId(), data, "Data")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void removeDataView() {
                boolean hasView = false;
                Fragment hasFragment = null;
                for (Fragment fragment : fragmentManager.getFragments()) {
                    if ("Data".equals(fragment.getTag())) {
                        hasView = true;
                        hasFragment = fragment;
                    }
                }
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                if (hasView) {
                    fragmentTransaction.remove(hasFragment)
                            .commitAllowingStateLoss();
                }
            }

            @Override
            public void addMapView(LocationItemResponse response) {
                //중복 선택 화면에서 넘어오면 중복 선택 화면 제거
                if(sttView.getVisibility() == View.VISIBLE) {
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            removeDataView();
                        }
                    },200);
                }
                boolean hasView = false;
                for (Fragment fragment : fragmentManager.getFragments()) {
                    if ("Map".equals(fragment.getTag())) {
                        hasView = true;
                        break;
                    }
                }
                if (!hasView) {
                    MapFragment data = new MapFragment();
                    data.setListener(listener);

                    if (response.getBody() != null) {
                        data.setLocationItem(response.getBody());
                    }
                    if(!TextUtils.isEmpty(response.getCompanyName())) {
                        data.setCompanyName(response.getCompanyName());
                    }

                    Location location = new Location(DaquvSDK.getInstance().getLocation());
                    location.setLatitude(response.getLatitude());
                    location.setLongitude(response.getLongitude());
                    data.setLocation(location);

                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.setCustomAnimations(R.anim.slide_in_right,
                            R.anim.slide_out_left,
                            R.anim.slide_in_left,
                            R.anim.slide_out_right);
                    fragmentTransaction.add(mainView.getId(), data, "Map")
                            .addToBackStack(null)
                            .commitAllowingStateLoss();
                }
            }

            @Override
            public void addConsultView(String companyId, String companyNm) {
                //중복 선택 화면에서 넘어오면 중복 선택 화면 제거
                if(sttView.getVisibility() == View.VISIBLE) {
                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            removeDataView();
                        }
                    },200);
                }
                ConsultFragment data = new ConsultFragment();
                data.setListener(listener);
                data.setCompanyInfo(companyId,companyNm);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.slide_in_right,
                        R.anim.slide_out_left,
                        R.anim.slide_in_left,
                        R.anim.slide_out_right);
                fragmentTransaction.add(mainView.getId(), data, "Consult")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void addConsultEditView(String companyId, String companyNm, String contents) {
                ConsultEditFragment data = new ConsultEditFragment();
                data.setListener(listener);
                data.setCompanyInfo(companyId,companyNm);
                data.setContents(contents);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.slide_in_right,
                        R.anim.slide_out_left,
                        R.anim.slide_in_left,
                        R.anim.slide_out_right);
                fragmentTransaction.add(mainView.getId(), data, "ConsultEdit")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();

                postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        boolean hasView = false;
                        Fragment hasFragment = null;
                        for (Fragment fragment : fragmentManager.getFragments()) {
                            if ("Consult".equals(fragment.getTag())) {
                                hasView = true;
                                hasFragment = fragment;
                            }
                        }
                        if (hasView) {
                            FragmentTransaction removeTransaction = fragmentManager.beginTransaction();
                            removeTransaction.remove(hasFragment)
                                    .commitAllowingStateLoss();
                        }
                    }
                }, 250);
            }

            @Override
            public void addVoiceView() {
                addVoiceView(null , null);
            }

            @Override
            public void addVoiceView(String directMove, String reask) {
                boolean hasView = false;
                Fragment hasFragment = null;
                for (Fragment fragment : fragmentManager.getFragments()) {
                    if ("Voice".equals(fragment.getTag())) {
                        hasView = true;
                        hasFragment = fragment;
                    }
                }
                VoiceFragment data = new VoiceFragment();
                data.setListener(listener);
                data.setDirectMove(directMove);
                data.setReAsk(reask);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(0, 0, 0, 0);

                if (hasView) {
                    fragmentTransaction.remove(hasFragment);
                }
                fragmentTransaction.add(mainView.getId(), data, "Voice")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void removeVoiceView() {
                boolean hasVoiceView = false;
                Fragment hasFragment = null;
                for (Fragment fragment : fragmentManager.getFragments()) {
                    if ("Voice".equals(fragment.getTag())) {
                        hasVoiceView = true;
                        hasFragment = fragment;
                    }
                }
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                if (hasVoiceView) {
                    fragmentTransaction.remove(hasFragment)
                            .commitAllowingStateLoss();
                }
            }

            @Override
            public void addKeypadView(boolean isCompnaySearch , boolean isAddressSearch) {
                removeVoiceView();
                KeyPadFragment data = new KeyPadFragment();
                data.setListener(listener);
                data.setCompanySearch(isCompnaySearch);
                data.setAddressSearch(isAddressSearch);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.keyapd_slide_up, R.anim.slide_out_left, 0, 0);
                fragmentTransaction.add(mainView.getId(), data, "Keypad")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void addSettingView() {
                SettingFragment data = new SettingFragment();
                data.setListener(listener);
                data.setLoginTokenResponse(loginTokenResponse);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.slide_in_right,
                        R.anim.slide_out_left,
                        R.anim.slide_in_left,
                        R.anim.slide_out_right);
                fragmentTransaction.add(mainView.getId(), data, "Setting")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void showLoading() {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if(loadingView.getVisibility() != View.VISIBLE) {
                            loadingView.setVisibility(View.VISIBLE);
                            loadingImage.setAnimation(R.raw.v3_loading);
                            loadingImage.playAnimation();
                        }
                    }
                });
            }

            @Override
            public void hideLoading() {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        loadingView.setVisibility(View.GONE);
                        loadingImage.pauseAnimation();
                    }
                });
            }

            @Override
            public void startTurnSTT(boolean isStart) {
                if(isStart) {
                    DaquvSDK.getInstance().getEngine().startEngineTURN();
                } else {
                    DaquvSDK.getInstance().getEngine().stopEngine();
                }
            }

            @Override
            public void bottomSTTView(boolean isVisible) {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if (isVisible) {
                            bottomContainer.setVisibility(View.VISIBLE);
                            sttView.setVisibility(View.GONE);
                        } else {
                            bottomContainer.setVisibility(View.GONE);
                            sttView.setVisibility(View.VISIBLE);
                        }
                    }
                });
            }

            @Override
            public void startSTT() {
                listener.addVoiceView();
            }

            @Override
            public void login(Boolean agreeArgument) {
                DaquvSDK.getInstance().getAPI().loginMultiple(agreeArgument , loginInfo);
            }

            @Override
            public void splash() {
                SplashFragment data = new SplashFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(mainView.getId(), data, "Splash")
                        .commitAllowingStateLoss();
                bottomContainer.setVisibility(View.GONE);
            }

            @Override
            public void updateSpeaker() {
                speakerView.updateView();
            }
        };
        fragmentManager.registerFragmentLifecycleCallbacks(new FragmentManager.FragmentLifecycleCallbacks() {
            @Override
            public void onFragmentAttached(@NonNull FragmentManager fm, @NonNull Fragment f, @NonNull Context context) {
                super.onFragmentAttached(fm, f, context);
                setBottomView(f.getTag(), true);
            }

            @Override
            public void onFragmentViewDestroyed(@NonNull FragmentManager fm, @NonNull Fragment f) {
                super.onFragmentViewDestroyed(fm, f);
                isTTSDisableView(fm);
                setBottomView(getTopFragmentTag(), false);
                if(f.getTag().equalsIgnoreCase("Keypad") &&
                        (getTopFragmentTag().equalsIgnoreCase("Data"))) {
                    bottomContainer.setVisibility(View.VISIBLE);
                }
                if(f.getTag().equalsIgnoreCase("Map") &&
                        (getTopFragmentTag().equalsIgnoreCase("Data"))) {
                    bottomContainer.setVisibility(View.VISIBLE);
                }
            }

        }, true);

        DaquvSDK.getInstance().init(getContext(), sdkCallback);
        listener.splash();
        listener.login(null);
    }

    public void setViewListener(ViewListener viewListener) {
        this.viewListener = viewListener;
    }


    public void onDestroy() {
        if (viewListener != null) {
            viewListener.onDetached();
        } else {
            clearStack();
            setVisibility(View.GONE);
        }
        DaquvSDK.getInstance().removeCallBack(sdkCallback);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.micView) {
            if (DaquvSDK.getInstance().getEngine().isRunning()) {
                listener.removeVoiceView();
            } else {
                listener.addVoiceView();
            }
        } else if(view.getId() == R.id.bottom_stt) {
            if (DaquvSDK.getInstance().getEngine().isRunning()) {
                listener.startTurnSTT(false);
            } else {
                listener.startTurnSTT(true);
            }
        }else if (view.getId() == R.id.keypadView) {
            DaquvSDK.getInstance().getEngine().stopEngine();
            listener.addKeypadView(false, false);
        }
    }

    private void initView() {
        mainView = new FrameLayout(getContext());
        mainView.setId(R.id.mainView);
        ConstraintLayout.LayoutParams mainViewParams = new ConstraintLayout.LayoutParams(
                0, 0
        );
        mainViewParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        mainViewParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        mainViewParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        mainViewParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
        mainView.setLayoutParams(mainViewParams);
        addView(mainView);


        bottomContainer = new FrameLayout(getContext());
        bottomContainer.setId(R.id.bottom_container);
        ConstraintLayout.LayoutParams bottomContainerParams = new ConstraintLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        bottomContainerParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomContainerParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomContainerParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomContainer.setLayoutParams(bottomContainerParams);

        View inflatedLayout = LayoutInflater.from(getContext()).inflate(R.layout.view_button_container, (ViewGroup) getRootView(), false);
        inflatedLayout.setOnClickListener(view -> { /*NONE*/ });

        AppCompatImageView keypadView = inflatedLayout.findViewById(R.id.keypadView);
        keypadView.setOnClickListener(this);

        micView = inflatedLayout.findViewById(R.id.micView);
        micView.setOnClickListener(this);
        speakerView = inflatedLayout.findViewById(R.id.speakerView);

        bottomContainer.addView(inflatedLayout);
        addView(bottomContainer);

        sttView = new LottieAnimationView(getContext());
        sttView.setId(R.id.bottom_stt);
        sttView.setOnClickListener(this);
        ConstraintLayout.LayoutParams bottomSttParams = new ConstraintLayout.LayoutParams(
                DaquvUtil.convertDPtoPX(getContext() , 120)
                , DaquvUtil.convertDPtoPX(getContext() , 120)
        );
        bottomSttParams.bottomMargin = DaquvUtil.convertDPtoPX(getContext() , 19);
        bottomSttParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomSttParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomSttParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        sttView.setLayoutParams(bottomSttParams);
        sttView.setVisibility(View.GONE);
        addView(sttView);


        loadingView = new RelativeLayout(getContext());
        loadingView.setId(R.id.loadingView);
        loadingView.setVisibility(View.GONE);
        loadingView.setBackgroundColor(ContextCompat.getColor(getContext(), R.color.dqv_dim));
        ConstraintLayout.LayoutParams loadingViewParams = new ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        );
        loadingView.setLayoutParams(loadingViewParams);
        loadingView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {/*NONE*/}
        });

        loadingImage = new LottieAnimationView(getContext());
        loadingImage.setAnimation(R.raw.v3_loading);
        loadingImage.setRepeatCount(ValueAnimator.INFINITE);
        RelativeLayout.LayoutParams loadingImageParams = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        loadingImageParams.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        loadingImage.setLayoutParams(loadingImageParams);
        loadingView.addView(loadingImage);
        addView(loadingView);
    }

    public void setLoginInfo(String... loginInfo) {
        this.loginInfo = loginInfo;
    }

    public void setLoginInfo(String emn) {
        setLoginInfo("CRM", emn ,"ibkCrm");
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public void clearStack() {
        int backStackEntry = fragmentManager.getBackStackEntryCount();
        if (backStackEntry > 0) {
            for (int i = 0; i < backStackEntry; i++) {
                fragmentManager.popBackStackImmediate();
            }
        }
        if (fragmentManager.getFragments().size() > 0) {
            List<Fragment> fragments = fragmentManager.getFragments();
            for (Fragment fragment : fragments) {
                if (fragment != null) {
                    fragmentManager.beginTransaction().remove(fragment).commit();
                }
            }
        }
    }

    private void setBottomView(String tag, boolean attach) {
        if (tag != null &&
                (tag.equals("Splash") ||
                        tag.equals("Consult") ||
                        tag.equals("ConsultEdit") ||
                        tag.equals("Map") ||
                        tag.equals("Setting") ||
                        tag.equals("Argument") ||
                        tag.equals("Keypad") ||
                        tag.equals("HTML"))) {
            bottomContainer.setVisibility(View.GONE);
            sttView.setVisibility(View.GONE);
        } else if(tag != null &&
                (tag.equals("Main")))   {
            bottomContainer.setVisibility(View.VISIBLE);
            sttView.setVisibility(View.GONE);
        } else if(tag != null &&
                (tag.equals("Data") ||
                 tag.equals("Voice")) &&
                attach)   {
            bottomContainer.setVisibility(View.VISIBLE);
            sttView.setVisibility(View.GONE);
        }
    }

    private void isTTSDisableView(FragmentManager fm) {
        try {
            if(fm.getFragments().size() > 0) {
                String tag = fm.getFragments().get(fm.getFragments().size() - 1).getTag();
                if (tag != null &&
                        (tag.equals("Main"))) {
                    DaquvConfig.ttsSession = 0;
                    DaquvSDK.getInstance().stopTTS();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getTopFragmentTag() {
        if (fragmentManager.getFragments().size() > 0) {
            return fragmentManager.getFragments().get(fragmentManager.getFragments().size() - 1).getTag();
        }
        return null;
    }

    public void setWhiteStatusBarMode(Activity context, boolean onlyFlag) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!onlyFlag) {
                context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_main_theme));
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && context.getWindow() != null && context.getWindow().getInsetsController() != null) {
                context.getWindow().getInsetsController().setSystemBarsAppearance(
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                );
            } else {
                int systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    systemUiVisibility |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
                context.getWindow().getDecorView().setSystemUiVisibility(systemUiVisibility);
            }
        }
    }
}
