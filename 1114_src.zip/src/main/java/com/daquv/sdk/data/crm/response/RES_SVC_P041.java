package com.daquv.sdk.data.crm.response;

import com.daquv.sdk.utils.network.TranJson;
import com.google.gson.annotations.SerializedName;


/**
 * 인증번호 요청 통신 데이터
 */
public class RES_SVC_P041 extends TranJson {
    @SerializedName("RSLT_CD")
    private String rsltCd;

    @SerializedName("TRAN_NO")
    private String tranNo;

    @SerializedName("RSLT_MSG")
    private String rsltMsg;

    @SerializedName("RESP_DATA")
    private DATA body;

    public class DATA {

        @SerializedName("RSLT_CD")
        private String rsltCd;

        @SerializedName("TRSC_UNQ_NO")
        private String trscUnqNo;

        @SerializedName("RSLT_MSG")
        private String msg;

        public String getRsltCd() {
            return rsltCd;
        }

        public void setRsltCd(String rsltCd) {
            this.rsltCd = rsltCd;
        }

        public String getTrscUnqNo() {
            return trscUnqNo;
        }

        public void setTrscUnqNo(String trscUnqNo) {
            this.trscUnqNo = trscUnqNo;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }
    }

    public String getRsltCd() {
        return rsltCd;
    }

    public void setRsltCd(String rsltCd) {
        this.rsltCd = rsltCd;
    }

    public String getTranNo() {
        return tranNo;
    }

    public void setTranNo(String tranNo) {
        this.tranNo = tranNo;
    }

    public String getRsltMsg() {
        return rsltMsg;
    }

    public void setRsltMsg(String rsltMsg) {
        this.rsltMsg = rsltMsg;
    }

    public DATA getBody() {
        return body;
    }

    public void setBody(DATA body) {
        this.body = body;
    }
}
