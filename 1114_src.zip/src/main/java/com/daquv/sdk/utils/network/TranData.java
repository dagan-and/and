package com.daquv.sdk.utils.network;

public class TranData<T> {

    private String mTranId;
    protected T mTranData;

    public TranData() {

    }

    protected void setId (String id) {
        mTranId = id;
    }

    public String getId () {
        return mTranId;
    }

    public void set(T t) {
        this.mTranData = t;
    }

    public T get() {
        return mTranData;
    }
}
