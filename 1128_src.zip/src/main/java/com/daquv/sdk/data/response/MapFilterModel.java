package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class MapFilterModel implements Serializable {

    @SerializedName("filter")
    private ArrayList<MapFilterResponse> filter;

    public ArrayList<MapFilterResponse> getFilter() {
        return filter;
    }

    public void setFilter(ArrayList<MapFilterResponse> filter) {
        this.filter = filter;
    }
}
