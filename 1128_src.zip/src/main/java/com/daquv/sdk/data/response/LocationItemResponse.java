package com.daquv.sdk.data.response;

import com.daquv.sdk.utils.Logger;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class LocationItemResponse implements Serializable {

    @SerializedName("cnt")
    private int count;

    @SerializedName("companies")
    private ArrayList<LocationItem> body;

    @SerializedName("url")
    private String url;

    @SerializedName("sourceLatitude")
    private double sourceLatitude;

    @SerializedName("sourceLongitude")
    private double sourceLongitude;

    private double latitude;
    private double longitude;
    private String companyName;

    public LocationItemResponse() {

    }

    public LocationItemResponse(String latitude, String longitude) {
        try {
            this.latitude = Double.parseDouble(latitude);
            this.longitude = Double.parseDouble(longitude);
        } catch (NumberFormatException e ) {
            Logger.error(e);
        }
    }


    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public ArrayList<LocationItem> getBody() {
        return body;
    }

    public void setBody(ArrayList<LocationItem> body) {
        this.body = body;
    }

    public double getLatitude() {
        if(sourceLatitude > 0) {
            return sourceLatitude;
        }
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        if(sourceLongitude > 0) {
            return sourceLongitude;
        }
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getUrl() {
        return url;
    }
}
