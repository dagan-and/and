package com.daquv.sdk.network;

import android.util.LruCache;

import com.daquv.sdk.DaquvConfig;

public class ETagCache {

    private final LruCache<String, String> cache;

    public ETagCache() {
        cache = new LruCache<>(DaquvConfig.ETAG_MAX_CACHE_SIZE);
    }

    public void put(String key, String value) {
        cache.put(key, value);
    }

    public String get(String key) {
        return cache.get(key);
    }

    public void clear() {
        cache.evictAll();
    }
}
