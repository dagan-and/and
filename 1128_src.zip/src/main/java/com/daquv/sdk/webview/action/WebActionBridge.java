package com.daquv.sdk.webview.action;

import android.os.Handler;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.daquv.sdk.utils.Logger;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Hashtable;

/**
 * WebView Bridge
 * <br><br>
 * - App <--> Web Bridge <br>
 **/
public class WebActionBridge {

    /** WebView Handler */
    private final Handler mWebHandler = new Handler();



    /** WebAction 이 정의되어 있는 Action Class 저장 HashTable */
    private final Hashtable<String, BaseWebAction> mActionClassTable = new Hashtable<>();

    /**
     * WebView Bridge 생성자
     */
    public WebActionBridge() {

    }

    /**
     * Web -> App 로 WebAction 전달
     * <br><br>
     * - Javascript Interface
     * @param action Action JSONObject
     */
    @JavascriptInterface
    public void postMessage(final String action) {
        Logger.info("action :: "+action);

        mWebHandler.post(new Runnable() {
            @Override
            public void run() {

                try {
                    WebActionInfo webActionInfo = new WebActionInfo(action);
                    BaseWebAction actionClass = mActionClassTable.get(webActionInfo.getActionCode());

                    Logger.dev("actionClass isNull :: " + (actionClass == null));
                    if (actionClass != null) {
                        Logger.dev("actionClass :: " + actionClass.getClass().getSimpleName());
                        actionClass.callAction(webActionInfo);
                    }
                }
                catch (Throwable t) {
                    Logger.error(t.getMessage());
                }
            }
        });
    }

    /**
     * Web -> App 로 WebAction 전달
     * <br><br>
     * - Javascript Interface
     * @param action Action JSONObject
     */
    @JavascriptInterface
    public void postMessage(final String action, final String data) {
        Logger.info("action :: "+action);

        mWebHandler.post(new Runnable() {
            @Override
            public void run() {

                try {
                    WebActionInfo webActionInfo = new WebActionInfo(action, data);
                    BaseWebAction actionClass = mActionClassTable.get(webActionInfo.getActionCode());

                    Logger.dev("actionClass isNull :: " + (actionClass == null));
                    if (actionClass != null) {
                        Logger.dev("actionClass :: " + actionClass.getClass().getSimpleName());
                        actionClass.callAction(webActionInfo);
                    }
                }
                catch (Throwable t) {
                    Logger.error(t.getMessage());
                }
            }
        });
    }

    /**
     * Web -> App 로 WebAction 전달
     * <br><br>
     * - Javascript Interface
     * @param action Action JSONObject
     */
    @JavascriptInterface
    public void postMessage(final String action, final String data, final String callback) {
        Logger.info("action :: "+action);

        mWebHandler.post(new Runnable() {
            @Override
            public void run() {

                try {
                    WebActionInfo webActionInfo = new WebActionInfo(action, data, callback);
                    BaseWebAction actionClass = mActionClassTable.get(webActionInfo.getActionCode());

                    Logger.dev("actionClass isNull :: " + (actionClass == null));
                    if (actionClass != null) {
                        Logger.dev("actionClass :: " + actionClass.getClass().getSimpleName());
                        actionClass.callAction(webActionInfo);
                    }
                }
                catch (Throwable t) {
                    Logger.error(t.getMessage());
                }
            }
        });
    }

    /**
     * Web -> App 로 WebAction 전달
     * <br><br>
     * - Javascript Interface
     * @param action Action JSONObject
     */
    @JavascriptInterface
    public void postMessage(final String action, final String data, final String callback, final String callback2) {
        Logger.info("action :: "+action);

        mWebHandler.post(new Runnable() {
            @Override
            public void run() {

                try {
                    WebActionInfo webActionInfo = new WebActionInfo(action, data, callback, callback2);
                    BaseWebAction actionClass = mActionClassTable.get(webActionInfo.getActionCode());

                    Logger.dev("actionClass isNull :: " + (actionClass == null));
                    if (actionClass != null) {
                        Logger.dev("actionClass :: " + actionClass.getClass().getSimpleName());
                        actionClass.callAction(webActionInfo);
                    }
                }
                catch (Throwable t) {
                    Logger.error(t.getMessage());
                }
            }
        });
    }


    /**
     * Web -> App 로 WebAction 전달
     * <br><br>
     * - Javascript Interface
     * @param jsondata Action JSONObject
     */
    @JavascriptInterface
    public void iWebAction(final String jsondata) {
        Logger.info("jsondata :: "+jsondata);

        mWebHandler.post(new Runnable() {
            @Override
            public void run() {
                WebActionInfo webActionInfo = null;

                try {
                    JSONObject actionJson = new JSONObject(jsondata);
                    webActionInfo = new WebActionInfo(actionJson);

                    BaseWebAction actionClass = mActionClassTable.get(webActionInfo.getActionCode());

                    Logger.dev("actionClass isNull :: " + (actionClass == null));
                    if (actionClass != null) {
                        Logger.dev("actionClass :: " + actionClass.getClass().getSimpleName());
                        actionClass.callAction(webActionInfo);
                    }
                }
                catch (Throwable t) {
                    Logger.error(t.getMessage());
                }
            }
        });
    }

    public void loadAction(BaseWebAction actionClass) {
        Logger.info("actionClass Name :: " + actionClass.getClass().getSimpleName());

        ArrayList <String> actionList = actionClass.getActionList();

        for (String action : actionList) {

            if (!mActionClassTable.containsKey(action)) {
                // Action Class Hash Table 에 Action Class 저장
                mActionClassTable.put(action, actionClass);
            }
            else {
                Class superClass = actionClass.getClass().getSuperclass();
                BaseWebAction preActionClass = mActionClassTable.get(action);
                if (preActionClass != null && superClass != null && superClass.equals(preActionClass.getClass())) {
                    // Action Class 를 재정의하여 Action Method 를 재정의한 경우
                    Logger.error("actionClass :: " + actionClass.getClass().getSimpleName());
                    Logger.error("actionClass super :: " + actionClass.getClass().getSuperclass());
                    Logger.error("preActionClass :: " + preActionClass.getClass().getSimpleName());
                    // 이미 정의되어 있던 Action Class Hash Table 에 Action Class 저장
                    mActionClassTable.put(action, actionClass);
                }
            }
        }
    }


    /**
     * Web JavaScript Function 호출
     * @param jsCallFunc 호출 함수명
     */
    public void callJavaScript (WebView mWebView, String jsCallFunc) {
        callJavaScript(mWebView, jsCallFunc, null);
    }

    /**
     * Web JavaScript Function 호출
     * @param jsCallFunc 호출 함수명
     * @param jsCallParam 호출 함수 파라미터
     */
    public void callJavaScript (WebView mWebView, String jsCallFunc, Object jsCallParam) {
        Logger.info("jsCallFunc :: " + jsCallFunc);
        Logger.info("jsCallParam :: " + jsCallParam);
        String script = "javascript:" + jsCallFunc;

        String jsCallUrl = script + "(";

        if (jsCallParam != null) {
            if (jsCallParam instanceof String) {
                jsCallUrl += "'" + jsCallParam + "'";
            } else {
                jsCallUrl += jsCallParam;
            }

        }
        jsCallUrl += ");";

        mWebView.loadUrl(jsCallUrl);
        Logger.dev("jsCallUrl :: " + jsCallUrl);
    }
}
