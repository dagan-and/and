package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class NLUResultResponse implements Serializable {
    @SerializedName("url")
    private String url;

    @SerializedName("tail")
    private String tail;

    @SerializedName("tts")
    private String tts;

    @SerializedName("ttsText")
    private String ttsText;

    @SerializedName("intent")
    private String intent;

    @SerializedName("webViewFlag")
    private String webViewFlag;

    @SerializedName("entities")
    private ArrayList<Entities> entities;

    private String utterance;

    public NLUResultResponse() {
    }

    public NLUResultResponse(String url, String tail, String tts, String ttsText, String intent, String webViewFlag, ArrayList<Entities> entities) {
        this.url = url;
        this.tail = tail;
        this.tts = tts;
        this.ttsText = ttsText;
        this.intent = intent;
        this.webViewFlag = webViewFlag;
        this.entities = entities;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTail() {
        return tail;
    }

    public void setTail(String tail) {
        this.tail = tail;
    }

    public String getTts() {
        return tts;
    }

    public void setTts(String tts) {
        this.tts = tts;
    }

    public String getTtsText() {
        return ttsText;
    }

    public void setTtsText(String ttsText) {
        this.ttsText = ttsText;
    }

    public String getIntent() {
        return intent;
    }

    public void setIntent(String intent) {
        this.intent = intent;
    }

    public String getWebViewFlag() {
        return webViewFlag;
    }

    public void setWebViewFlag(String webViewFlag) {
        this.webViewFlag = webViewFlag;
    }

    public ArrayList<Entities> getEntities() {
        return entities;
    }

    public void setEntities(ArrayList<Entities> entities) {
        this.entities = entities;
    }

    public String getUtterance() {
        return utterance;
    }

    public void setUtterance(String utterance) {
        this.utterance = utterance;
    }
}
