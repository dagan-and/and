package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class STTReplaceResponse {
    @SerializedName("replace")
    private ArrayList<STTReplace> replaces;

    public ArrayList<STTReplace> getReplaces() {
        return replaces;
    }

    public void setReplaces(ArrayList<STTReplace> replaces) {
        this.replaces = replaces;
    }

    public static class STTReplace {
        @SerializedName("before")
        private String before;

        @SerializedName("after")
        private String after;

        public String getBefore() {
            return before;
        }

        public void setBefore(String before) {
            this.before = before;
        }

        public String getAfter() {
            return after;
        }

        public void setAfter(String after) {
            this.after = after;
        }
    }
}
