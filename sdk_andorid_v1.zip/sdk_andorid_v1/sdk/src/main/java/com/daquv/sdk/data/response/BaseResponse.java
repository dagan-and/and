package com.daquv.sdk.data.response;

import android.text.TextUtils;

import com.daquv.sdk.network.ETagCache;
import com.daquv.sdk.utils.Logger;
import com.google.gson.annotations.SerializedName;

import java.io.IOException;

import okhttp3.Response;

public class BaseResponse {
    @SerializedName("status")
    private int status;

    @SerializedName("success")
    private Boolean success;

    @SerializedName("retCd")
    private String retCd;

    Response response;
    ETagCache cache;
    boolean isSuccess;

    public BaseResponse(Response response, ETagCache cache) {
        this.response = response;
        this.cache = cache;

        if((response.isSuccessful() || response.code() == 304)
                && response.body() != null ) {
            isSuccess = true;

            if(!TextUtils.isEmpty(response.header("ETag"))) {
                cache.put(response.request().url().toString(), response.header("ETag"));
            }
        } else {
            isSuccess = false;
        }
    }

    public boolean isSuccess() {
        return isSuccess;
    }

    public String getBody() {
        if(response.code() == 304 && !TextUtils.isEmpty(cache.get(response.request().url().toString()))) {
            String eTag = cache.get(response.request().url().toString());
            return cache.get(eTag);
        } else {
            try {
                assert response.body() != null;
                String body = response.body().string();

                if(!TextUtils.isEmpty(response.header("ETag"))) {
                    cache.put(response.header("ETag"), body);
                }

                return body;
            } catch (IOException e) {
                Logger.error(e);
            }
        }
        return null;
    }


}
