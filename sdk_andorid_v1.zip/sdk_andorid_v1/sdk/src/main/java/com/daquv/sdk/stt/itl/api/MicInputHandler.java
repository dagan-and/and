package com.daquv.sdk.stt.itl.api;


import android.annotation.SuppressLint;
import android.media.AudioRecord;

public class MicInputHandler {
   MicInputHandler.OnProcessMicData processMicData;
    private static final int AUDIO_SOURCE = 6;
    private static final int SAMPLE_RATE_IN_HZ = 16000;
    private static final int CHANNEL_CONFIG = 16;
    private static final int AUDIO_FORMAT = 2;
    private static final int MIN_BUF_SIZE_IN_BYTES = 2560;
    private static final int CHUNK_BYTES = 320;
    private AudioRecord mAudioRecord;
    public int mReadBytes = 0;
    private final AudioRecord.OnRecordPositionUpdateListener mRecordUpdateListener = new AudioRecord.OnRecordPositionUpdateListener() {
        public void onMarkerReached(AudioRecord audioRecord) {
            //NONE
        }

        public void onPeriodicNotification(AudioRecord audioRecord) {
            byte[] audio = new byte[CHUNK_BYTES];
            MicInputHandler.this.mReadBytes = audioRecord.read(audio, 0, CHUNK_BYTES);
            if (MicInputHandler.this.mReadBytes == CHUNK_BYTES) {
                MicInputHandler.this.processMicData.onProcessMicData(audio);
            }
        }
    };

    public MicInputHandler() {
    }

    public void setOnProcessMicData(MicInputHandler.OnProcessMicData processMicData) {
        this.processMicData = processMicData;
    }

    private int getAudioBufferSize() {
        int mMinBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE_IN_HZ, CHANNEL_CONFIG, AUDIO_FORMAT);
        return Math.max(mMinBufferSize, MIN_BUF_SIZE_IN_BYTES);
    }

    @SuppressLint({"MissingPermission"})
    public void start() {
        int mAudioBufferSize = this.getAudioBufferSize();
        this.mAudioRecord = new AudioRecord(AUDIO_SOURCE, SAMPLE_RATE_IN_HZ, CHANNEL_CONFIG, AUDIO_FORMAT, mAudioBufferSize);
        this.mAudioRecord.setPositionNotificationPeriod(160);
        this.mAudioRecord.setRecordPositionUpdateListener(this.mRecordUpdateListener);
        this.mAudioRecord.startRecording();
    }

    public void stop() {
        if (this.mAudioRecord != null) {
            this.mAudioRecord.stop();
            this.mAudioRecord.release();
            this.mAudioRecord = null;
        }

    }

    public void pause() {
        if (this.mAudioRecord != null) {
            this.mAudioRecord.stop();
        }

    }

    public void resume() {
        if (this.mAudioRecord != null) {
            this.mAudioRecord.startRecording();
        }

    }

    public interface OnProcessMicData {
        void onProcessMicData(byte[] var1);
    }
}

