package com.daquv.sdk.utils.network;

import android.util.Log;

import com.daquv.sdk.utils.Logger;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TranJson extends TranData <HashMap<String, Object>> {

    public TranJson() {
        super();
        mTranData = new HashMap<>();
    }

    public TranJson(String id) {
        super();
        mTranData = new HashMap<>();
        setId(id);
    }

    public TranJson (String id, Object obj) throws JSONException {
        super();
        setId(id);
        if (obj instanceof JSONObject) {
            if(obj.equals(JSONObject.NULL)) {
                mTranData = (HashMap<String, Object>) JSONHelper.toHashMap(new JSONObject());
            } else {
                mTranData = (HashMap<String, Object>) JSONHelper.toHashMap((JSONObject) obj);
            }
        } else {
            mTranData = (HashMap<String, Object>) obj;
        }
    }

    /**
     * HashMap 으로 구성된 송신 Data 리턴한다. <br>
     * @return HashMap<String, Object> 송신 Data
     */
    public Map<String, Object> getData() {
        return get();
    }

    public void put (String key, Object val) {
        mTranData.put(key, val);
    }

    public String getString (String key) {
        if (mTranData.containsKey(key)) {
            return (String) mTranData.get(key);
        }
        return null;
    }

    public int getInt (String key) {
        if (mTranData.containsKey(key)) {
            return (int) mTranData.get(key);
        }
        return 0;
    }

    public boolean getBoolean (String key) {
        if (mTranData.containsKey(key)) {
            return (boolean) mTranData.get(key);
        }
        return false;
    }

    public Map<String, Object> getMap (String key) {
        if (mTranData.containsKey(key)) {
            return (HashMap<String, Object>) mTranData.get(key);
        }
        return new HashMap<>();
    }

    public List<Object> getList (String key) {
        if (mTranData.containsKey(key)) {
            return (ArrayList <Object> ) mTranData.get(key);
        }
        return new ArrayList<>();
    }

    public JSONObject getJSONObject() throws JSONException {
        return (JSONObject) JSONHelper.toJSON(get());
    }

    public JsonObject getGsonObject() throws JSONException {
        JSONObject object = (JSONObject) JSONHelper.toJSON(get());
        JsonObject gsonObject = new Gson().fromJson(object.toString(), JsonObject.class);
        Log.d("TranJson", "getGsonObject: " + gsonObject.toString());
        return gsonObject;
    }

    public String getJSON() throws JSONException {
        return getJSONObject().toString();
    }

    public JSONObject makeTranData(TranJson reqJobj) throws JSONException {
        Logger.dev("makeTranData >> tranJobj :: " + reqJobj.getJSONObject());
        JSONObject tranJobj = new JSONObject();
        tranJobj.put("CNTS_CRTS_KEY", "d394fae4-414c-77dd-1648-874550002060");
        tranJobj.put("DEVICE_INST_ID", "");
        tranJobj.put("TRAN_NO", reqJobj.getId());
        tranJobj.put("ENC_YN", "N");
        tranJobj.put("REQ_DATA", reqJobj.getJSONObject());
        return tranJobj;
    }
}
