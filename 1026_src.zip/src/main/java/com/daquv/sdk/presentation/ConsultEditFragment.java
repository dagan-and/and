package com.daquv.sdk.presentation;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.ui.BackPressEditText;
import com.daquv.sdk.ui.comm.ComDialogBuilder;
import com.daquv.sdk.ui.component.BasicButtonView;
import com.daquv.sdk.utils.HeightProvider;
import com.daquv.sdk.utils.Logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ConsultEditFragment extends Fragment  {

    int mYear;
    int mMonth;
    int mDay;
    int mHour;
    int mMinute;
    private View rootView;
    private String companyId;
    private String companyName;
    private String contents;
    private View keyboardPaddingTop;
    private View keyboardPaddingBottom;
    private EditText editName;
    private EditText editContents;
    private BasicButtonView btnRegist;
    private HeightProvider heightProvider;

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    DaquvEngine.Callback engineCallback;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_consult_edit, container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        rootView = view;
        keyboardPaddingTop = view.findViewById(R.id.keyboard_padding_top);
        keyboardPaddingBottom = view.findViewById(R.id.keyboard_padding_bottom);
        editName = view.findViewById(R.id.edit_company);
        editContents = view.findViewById(R.id.edit_contents);
        TextView editDate = view.findViewById(R.id.edit_date);
        TextView editTime = view.findViewById(R.id.edit_time);
        ImageView editDelete = view.findViewById(R.id.btn_company_delete);
        btnRegist = view.findViewById(R.id.btn_regist);

        Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);

        editDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(), R.style.DaquvPickerTheme, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        setDateView(editDate , year , monthOfYear , dayOfMonth);
                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.getDatePicker().setCalendarViewShown(false);
                datePickerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                datePickerDialog.show();
            }
        });
        editTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TimePickerDialog datePickerDialog = new TimePickerDialog(requireContext(),  R.style.DaquvPickerTheme, new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker timePicker, int i, int i1) {
                        setTimeView(editTime , i , i1);
                    }
                }, mHour, mMinute , false);
                datePickerDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
                datePickerDialog.show();
            }
        });
        editDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editName.setText("");
            }
        });
        editName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //NONE
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence != null && charSequence.length() > 0) {
                    if(charSequence.toString().contains("\n")) {
                        editContents.hasFocus();
                    }
                    editDelete.setVisibility(View.VISIBLE);
                } else {
                    editDelete.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //NONE
            }
        });

        editName.setText(companyName);
        editContents.setText(contents);
        setDateView(editDate , mYear , mMonth , mDay);
        setTimeView(editTime , mHour , mMinute);
        btnRegist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ComDialogBuilder dialogBuilder = new ComDialogBuilder(requireContext());
                dialogBuilder.showAlert(new ComDialogBuilder.OnCommDlgClickListener() {
                    @Override
                    public void onLeftButton() {}

                    @Override
                    public void onRightButton() {
                        Toast.makeText(requireContext(),"상담내용 등록 완료", Toast.LENGTH_SHORT).show();

                        String date = String.valueOf(mYear);
                        if(mMonth < 10) {
                            date += ("0" + mMonth);
                        } else {
                            date += mMonth;
                        }
                        if(mDay < 10) {
                            date += ("0" + mDay);
                        } else {
                            date += mDay;
                        }

                        String time = "";
                        if(mHour < 10) {
                            time += ("0" + mHour);
                        } else {
                            time += mHour;
                        }
                        if(mMinute < 10) {
                            time += ("0" + mMinute);
                        } else {
                            time += mMinute;
                        }

                        DaquvSDK.getInstance().getAPI().uploadConsultData(companyId, companyName , date , time, contents);
                        listener.onBackPress(ConsultEditFragment.this);
                    }

                    @Override
                    public void onDismiss() {}
                }, getString(R.string.consult_regist_title), getString(R.string.dqv_no), getString(R.string.dqv_yes));
            }
        });
        view.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressedCallback.handleOnBackPressed();
            }
        });
    }


    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }
    public void setCompanyInfo(String companyId, String companyName) {
        this.companyId = companyId;
        this.companyName = companyName;
    }
    public void setContents(String contents) {
        this.contents = contents;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                ComDialogBuilder dialogBuilder = new ComDialogBuilder(requireContext());
                dialogBuilder.showAlert(new ComDialogBuilder.OnCommDlgClickListener() {
                    @Override
                    public void onLeftButton() {
                    }
                    @Override
                    public void onRightButton() {
                        listener.onBackPress(ConsultEditFragment.this);
                    }

                    @Override
                    public void onDismiss() {}
                }, getString(R.string.consult_cancel_title),getString(R.string.consult_cancel_message), getString(R.string.dqv_no), getString(R.string.dqv_yes));
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        heightProvider = new HeightProvider(requireActivity());
        heightProvider.init();
        heightProvider.setHeightListener(new HeightProvider.HeightListener() {
            @Override
            public void onHeightChanged(int height) {
                try {
                    if(editContents.hasFocus()) {
                        //requireContext 가 null 인 경우 예외 처리
                        if (rootView.getMeasuredHeight() > 0 && height > 0) {
                            setViewHeight(keyboardPaddingBottom, height);
                        } else {
                            setViewHeight(keyboardPaddingBottom, 0);
                        }
                        if (height > 0 ) {
                            btnRegist.setVisibility(View.GONE);
                            keyboardPaddingTop.setVisibility(View.GONE);
                            keyboardPaddingBottom.setVisibility(View.VISIBLE);
                        } else if (height == 0) {
                            btnRegist.setVisibility(View.VISIBLE);
                            keyboardPaddingTop.setVisibility(View.VISIBLE);
                            keyboardPaddingBottom.setVisibility(View.GONE);
                        }
                    } else {
                        btnRegist.setVisibility(View.VISIBLE);
                        keyboardPaddingTop.setVisibility(View.VISIBLE);
                        keyboardPaddingBottom.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    Logger.error(e);
                }
            }
        });
    }

    public void setViewHeight(View view, int height) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = height;
        view.setLayoutParams(params);
    }

    private void setDateView(TextView editDate ,  int year , int monthOfYear, int dayOfMonth) {
        mYear = year;
        mMonth = monthOfYear;
        mDay = dayOfMonth;

        String day = "";
        if(dayOfMonth < 10) {
            day += "0" + dayOfMonth;
        } else {
            day += dayOfMonth;
        }

        editDate.setText(year +"." + (monthOfYear+1) + "." + day);
    }

    private void setTimeView(TextView editTime , int hour , int minute) {
        mHour = hour;
        mMinute = minute;

        String ampm = "";
        if(hour < 12) {
            ampm = "오전";
        } else {
            ampm = "오후";
            hour -= 12;
        }
        String min = "";
        if(minute < 10) {
            min += "0" + minute;
        } else {
            min += minute;
        }
        editTime.setText(ampm + " " + hour +":" + min);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        onBackPressedCallback.remove();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
    }

}
