package com.daquv.sdk.core;

import android.content.Context;
import android.text.TextUtils;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.data.crm.request.REQ_SVC_C028;
import com.daquv.sdk.data.crm.request.REQ_SVC_P041;
import com.daquv.sdk.data.crm.response.RES_SVC_C028;
import com.daquv.sdk.data.crm.response.RES_SVC_P041;
import com.daquv.sdk.data.request.ConsultRequest;
import com.daquv.sdk.data.request.LocationRequest;
import com.daquv.sdk.data.request.LoginRequest;
import com.daquv.sdk.data.request.NLURequest;
import com.daquv.sdk.data.response.BaseResponse;
import com.daquv.sdk.data.response.CusInfoModel;
import com.daquv.sdk.data.response.Entities;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.LocationItemModel;
import com.daquv.sdk.data.response.LoginTokenModel;
import com.daquv.sdk.data.response.MapFilterModel;
import com.daquv.sdk.data.response.MapFilterResponse;
import com.daquv.sdk.data.response.NLUResultModel;
import com.daquv.sdk.data.response.RsaKeyModel;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.data.response.STTReplaceResponse;
import com.daquv.sdk.data.response.TTSModel;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.network.HttpClient;
import com.daquv.sdk.network.ETagCache;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.network.TranJson;
import com.daquv.sdk.utils.secure.RSAUtils;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.io.File;
import java.net.CookieHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.Callable;

import io.reactivex.Observable;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.CookieJar;
import okhttp3.FormBody;
import okhttp3.JavaNetCookieJar;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DaquvAPI {
    //right click -> folding -> Collapse all

    private final Context mContext;
    private final CompositeDisposable commonDisposable;
    private final APICallback mAPICallBack;
    private final CookieHandler cookieHandler;
    private final ETagCache responseCache = new ETagCache();
    private String mainUrl;
    private String mainData;
    private String resultUrl;
    private String resultData;

    private CookieJar getCookieJar() {
        return new JavaNetCookieJar(cookieHandler);
    }

    public DaquvAPI(Context context, APICallback callback) {
        mContext = context;
        mAPICallBack = callback;
        commonDisposable = new CompositeDisposable();
        cookieHandler = new java.net.CookieManager();
    }

    public static class APICallback {
        public void onAPIResult(int code, Object result) {
            /**
             * API 응답 CallBack
             */
        }
    }

    /**
     * 결과 페이지 데이터
     *
     * @return HTML
     */
    public String getResultData() {
        return resultData;
    }

    /**
     * 결과 페이지 URL
     *
     * @return URL
     */
    public String getResultUrl() {
        return resultUrl;
    }

    /**
     * 메인 페이지 데이터
     *
     * @return HTML
     */
    public String getMainData() {
        return mainData;
    }

    /**
     * 메인 페이지 URL
     *
     * @return URL
     */
    public String getMainUrl() {
        return mainUrl;
    }


    public void sendError(Exception e) {
        Logger.error(e);
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, DaquvUtil.getExceptionLog(e));
    }

    public void sendError(Throwable e) {
        Logger.error(e);
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, DaquvUtil.getExceptionLog(e));
    }


    private String[] encryptLoinRequest(String json, String... info) {
        RsaKeyModel bodyResponse = new Gson().fromJson(json, RsaKeyModel.class);
        if (bodyResponse.getBody() == null) {
            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                    new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
            return null;
        }

        String rsaExponent = bodyResponse.getBody().getRsaExponent();
        String rsaModulus = bodyResponse.getBody().getRsaModulus();

        String[] encData = new String[info.length];
        for (int i = 0; i < info.length; i++) {
            encData[i] = RSAUtils.getEncryptRSA(rsaModulus, rsaExponent, info[i]);
        }
        return encData;
    }

    /**
     * 로그인
     *
     * @param info 0 email(ID)
     *             1 Password
     *             2 Company Id
     *             3 emp Id
     */
    public void login(String... info) {
        Callable<Response> callable = () -> {

            String url = "";
            switch (DaquvConfig.service) {
                case HUB:
                case POSCO:
                    url = DaquvConfig.API.AUTH_KEY_URL;
                    break;
                case IBKCRM:
                    url = DaquvConfig.API.CRM_AUTH_KEY_URL;
                    break;
                default:
                    url = DaquvConfig.API.AUTH_KEY_URL;
                    break;
            }

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addJWTToken(false)
                    .isPost(false)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        try {
                            if (response.isSuccessful() && response.body() != null) {

                                LoginRequest reqSvcLogin = new LoginRequest(DaquvConfig.service ,encryptLoinRequest(response.body().string() , info));

                                Callable<Response> callable = () -> {
                                    HttpClient client = new HttpClient.Builder()
                                            .setUrl(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service ?
                                                    DaquvConfig.API.CRM_LOGIN_URL : DaquvConfig.API.LOGIN_URL)
                                            .setCookie(getCookieJar())
                                            .setCache(responseCache)
                                            .setJsonData(reqSvcLogin.getJSON())
                                            .addJWTToken(false)
                                            .isLogging(true)
                                            .builder();
                                    return client.getCall().execute();
                                };

                                commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe(new Consumer<Response>() {
                                            @Override
                                            public void accept(Response response) throws Exception {
                                                BaseResponse baseResponse = new BaseResponse(response, responseCache);
                                                if (baseResponse.isSuccess()) {
                                                    LoginTokenModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), LoginTokenModel.class);

                                                    if (bodyResponse.getBody() == null) {
                                                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                new ErrorData(DaquvConfig.CODE.API_LOGIN, "ERROR CODE:" + response.code()));
                                                        return;
                                                    }

                                                    DaquvConfig.jwtToken = bodyResponse.getBody().getToken();
                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_LOGIN, bodyResponse.getBody());
                                                } else {
                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                            new ErrorData(DaquvConfig.CODE.API_LOGIN, "ERROR CODE:" + response.code()));
                                                }
                                            }
                                        }, new Consumer<Throwable>() {
                                            @Override
                                            public void accept(Throwable throwable) throws Exception {
                                                sendError(throwable);
                                            }
                                        }));


                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_LOGIN, "REQ URL:\n" + response.request().url() + "\n\n"
                                        + "RES CODE:: " + response.code() +
                                                "\nRES MSG:: " + response.message()));
                            }
                        } catch (Exception e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    public void loginMultiple(Boolean agreeArgument , String... info) {
        try {
            Callable<Response> callable = () -> {

                HttpClient client = new HttpClient.Builder()
                        .setUrl(DaquvConfig.API.CRM_WAS_AUTH_KEY_URL)
                        .setCookie(getCookieJar())
                        .setCache(responseCache)
                        .addJWTToken(false)
                        .isPost(false)
                        .builder();
                return client.getCall().execute();
            };

            commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(new Consumer<Response>() {
                        @Override
                        public void accept(Response response) throws Exception {
                            try {
                                if (response.isSuccessful() && response.body() != null) {

                                    String[] encryptLoinRequest = encryptLoinRequest(response.body().string() ,info[0],info[1],info[2]);
                                    LoginRequest reqSvcLogin = new LoginRequest(DaquvConfig.SERVICE.IBKCRM , encryptLoinRequest);

                                    Callable<Response> callable = () -> {
                                        HttpClient client = new HttpClient.Builder()
                                                .setUrl(DaquvConfig.API.CRM_WAS_LOGIN_URL)
                                                .setCookie(getCookieJar())
                                                .setCache(responseCache)
                                                .setJsonData(reqSvcLogin.getJSON())
                                                .addJWTToken(false)
                                                .isLogging(true)
                                                .builder();
                                        return client.getCall().execute();
                                    };

                                    commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                                            .observeOn(Schedulers.io())
                                            .subscribe(new Consumer<Response>() {
                                                @Override
                                                public void accept(Response response) throws Exception {
                                                    BaseResponse baseResponse = new BaseResponse(response, responseCache);
                                                    if (baseResponse.isSuccess()) {
                                                        LoginTokenModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), LoginTokenModel.class);

                                                        if (bodyResponse.getBody() == null) {
                                                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                    new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
                                                            return;
                                                        }

                                                        DaquvConfig.jwtToken = bodyResponse.getBody().getToken();

                                                        Callable<Response> callable = () -> {

                                                            HttpClient client = new HttpClient.Builder()
                                                                    .setUrl(DaquvConfig.API.CRM_AUTH_KEY_URL)
                                                                    .setCookie(getCookieJar())
                                                                    .setCache(responseCache)
                                                                    .addJWTToken(false)
                                                                    .isPost(false)
                                                                    .builder();
                                                            return client.getCall().execute();
                                                        };

                                                        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                                                                .observeOn(Schedulers.io())
                                                                .subscribe(new Consumer<Response>() {
                                                                    @Override
                                                                    public void accept(Response response) throws Exception {
                                                                        try {
                                                                            if (response.isSuccessful() && response.body() != null) {


                                                                                String agree = "";
                                                                                if(agreeArgument != null && agreeArgument) {
                                                                                    agree = "Y";
                                                                                }
                                                                                String[] encryptLoinRequest = encryptLoinRequest(response.body().string() ,info[0],info[1],info[2]);
                                                                                LoginRequest reqSvcLogin = new LoginRequest(DaquvConfig.SERVICE.IBKCRM ,
                                                                                        encryptLoinRequest[0],
                                                                                        encryptLoinRequest[1],
                                                                                        encryptLoinRequest[2],
                                                                                        agree);

                                                                                Callable<Response> callable = () -> {
                                                                                    HttpClient client = new HttpClient.Builder()
                                                                                            .setUrl(DaquvConfig.API.CRM_LOGIN_URL)
                                                                                            .setCookie(getCookieJar())
                                                                                            .setCache(responseCache)
                                                                                            .setJsonData(reqSvcLogin.getJSON())
                                                                                            .addJWTToken(false)
                                                                                            .isLogging(true)
                                                                                            .builder();
                                                                                    return client.getCall().execute();
                                                                                };

                                                                                commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                                                                                        .observeOn(Schedulers.io())
                                                                                        .subscribe(new Consumer<Response>() {
                                                                                            @Override
                                                                                            public void accept(Response response) throws Exception {
                                                                                                BaseResponse baseResponse = new BaseResponse(response, responseCache);
                                                                                                if (baseResponse.isSuccess()) {
                                                                                                    LoginTokenModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), LoginTokenModel.class);

                                                                                                    if (bodyResponse.getBody() == null) {
                                                                                                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                                                new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
                                                                                                        return;
                                                                                                    }

                                                                                                    DaquvConfig.ibkToken = bodyResponse.getBody().getToken();
                                                                                                    //약관동의 여부 체크
                                                                                                    if(!TextUtils.isEmpty(bodyResponse.getBody().getAggrYn()) &&
                                                                                                            bodyResponse.getBody().getAggrYn().equalsIgnoreCase("Y")) {
                                                                                                        SharedPref.getInstance().put(DaquvConfig.Preference.KEY_ARGUMENT_POLICY_AGREE, true);
                                                                                                    }
                                                                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_LOGIN, bodyResponse.getBody());
                                                                                                } else {
                                                                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                                            new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
                                                                                                }
                                                                                            }
                                                                                        }, new Consumer<Throwable>() {
                                                                                            @Override
                                                                                            public void accept(Throwable throwable) throws Exception {
                                                                                                sendError(throwable);
                                                                                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                                        new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
                                                                                            }
                                                                                        }));



                                                                            }
                                                                        } catch (Exception e) {
                                                                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                    new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
                                                                        }
                                                                    }
                                                                }));


                                                    } else {
                                                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
                                                    }
                                                }
                                            }, new Consumer<Throwable>() {
                                                @Override
                                                public void accept(Throwable throwable) throws Exception {
                                                    sendError(throwable);
                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                            new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
                                                }
                                            }));


                                } else {
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                            new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
                                }
                            } catch (Exception e) {
                                sendError(e);
                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {
                            sendError(throwable);
                        }
                    }));
        } catch (Exception e) {
            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                    new ErrorData(DaquvConfig.CODE.API_LOGIN, e.getMessage()));
        }
    }


    /**
     * NLU 데이터 요청
     *
     * @param utterance 발화문구
     */
    public void getNLUData(String utterance) {
        NLURequest reqSvcLogin = new NLURequest(utterance);

        Callable<Response> callable = () -> {

            String url = "";
            switch (DaquvConfig.service) {
                case HUB:
                case POSCO:
                    url = DaquvConfig.API.NLU_URL;
                    break;
                case IBKCRM:
                    url = DaquvConfig.API.CRM_NLU_URL;
                    break;
                default:
                    url = DaquvConfig.API.NLU_URL;
                    break;
            }

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(reqSvcLogin.getJSON())
                    .isLogging(true)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        String json = baseResponse.getBody();

                        if (baseResponse.isSuccess()) {
                            NLUResultModel bodyResponse = new Gson().fromJson(json, NLUResultModel.class);
                            bodyResponse.getBody().setUtterance(utterance);
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU, bodyResponse.getBody());
                        } else {
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_NLU, json));
                            getFailPage(new NLUResultResponse());
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                new ErrorData(DaquvConfig.CODE.API_NLU, throwable.toString()));
                        getFailPage(new NLUResultResponse());
                    }
                }));

    }


    /**
     * 지도 데이터 요청
     *
     * @param latitude  위도 좌표
     * @param longitude 경도 좌표
     * @param radius    검색 반경
     */
    public void getMapData(String latitude, String longitude, String radius) {
        String mRadius = radius.replaceAll("M", "");
        if (radius.toUpperCase().contains("K")) {
            String value = radius.split("K")[0];
            int fValue = (int) (Float.parseFloat(value) * 1000);
            mRadius = String.valueOf(fValue);
        }
        LocationRequest reqLocation = new LocationRequest(latitude, longitude, mRadius);

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_MAP_URL)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(reqLocation.getJSON())
                    .addIBKToken(true)
                    .isLogging(true)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        if (baseResponse.isSuccess()) {
                            LocationItemModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), LocationItemModel.class);
                            bodyResponse.getBody().setLatitude(Double.parseDouble(latitude));
                            bodyResponse.getBody().setLongitude(Double.parseDouble(longitude));
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_MAP, bodyResponse.getBody());
                        } else {
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_NLU_MAP, mContext.getString(R.string.err_msg_daquv_9)));
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));

    }

    /**
     * 결과 페이지 요청
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getResultPage(NLUResultResponse nluResultResponse) {
        //BODY
        FormBody.Builder formBody = new FormBody.Builder();
        formBody.add("intent_code", TextUtils.isEmpty(nluResultResponse.getIntent()) ? "null" : nluResultResponse.getIntent());
        formBody.add("utterance", TextUtils.isEmpty(nluResultResponse.getUtterance()) ? "null" : nluResultResponse.getUtterance());

        if (nluResultResponse.getEntities() != null && !nluResultResponse.getEntities().isEmpty()) {
            ArrayList<Entities> entities = nluResultResponse.getEntities();
            for (int i = 0; i < entities.size(); i++) {
                Entities entity = entities.get(i);
                formBody.add("entities[" + i + "].entity", TextUtils.isEmpty(entity.getEntity()) ? "null" : entity.getEntity());
                formBody.add("entities[" + i + "].value", TextUtils.isEmpty(entity.getValue()) ? "null" : entity.getValue());
            }
        }

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvUtil.getUrl(nluResultResponse.getUrl()))
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setBody(formBody.build())
                    .addIBKToken(DaquvConfig.service == DaquvConfig.SERVICE.IBKCRM)
                    .isLogging(false)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        if (baseResponse.isSuccess()) {
                            resultUrl = DaquvUtil.getUrl(nluResultResponse.getUrl());
                            resultData = baseResponse.getBody();
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_SUCCESS, DaquvUtil.getUrl(nluResultResponse.getUrl()));
                        } else {
                            getFailPage(nluResultResponse);
                            Logger.error(baseResponse.getBody());
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable e) throws Exception {
                        sendError(e);
                        getFailPage(nluResultResponse);
                    }
                }));

    }


    /**
     * 특정 좌표 주변기업 리스트 요청
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getSearchCopList(NLUResultResponse nluResultResponse) {
        //BODY
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("intent_code", TextUtils.isEmpty(nluResultResponse.getIntent()) ? "null" : nluResultResponse.getIntent());

            if (nluResultResponse.getEntities() != null && !nluResultResponse.getEntities().isEmpty()) {
                ArrayList<Entities> entities = nluResultResponse.getEntities();
                for (int i = 0; i < entities.size(); i++) {
                    Entities entity = entities.get(i);
                    if(!TextUtils.isEmpty(entity.getEntity()) && !TextUtils.isEmpty(entity.getValue())) {
                        jsonObject.put(entity.getEntity(), entity.getValue());
                    }
                }
            }

            Callable<Response> callable = () -> {
                HttpClient client = new HttpClient.Builder()
                        .setUrl(DaquvConfig.API.CRM_SEARCH_COP_LIST)
                        .setCookie(getCookieJar())
                        .setCache(responseCache)
                        .setJsonData(jsonObject.toString())
                        .addIBKToken(true)
                        .isLogging(true)
                        .builder();
                return client.getCall().execute();
            };

            commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(new Consumer<Response>() {
                        @Override
                        public void accept(Response response) throws Exception {
                            BaseResponse baseResponse = new BaseResponse(response, responseCache);
                            if (baseResponse.isSuccess()) {
                                LocationItemModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), LocationItemModel.class);
                                if(!TextUtils.isEmpty(bodyResponse.getBody().getUrl())) {
                                    NLUResultResponse listItemResponse = new NLUResultResponse();
                                    listItemResponse.setUrl(bodyResponse.getBody().getUrl());
                                    listItemResponse.setIntent("IB018");

                                    ArrayList<Entities> entities = new ArrayList<>();
                                    entities.add(new Entities("COUNTERPARTNAME", nluResultResponse.getEntities().get(0).getValue(),null,null));
                                    listItemResponse.setEntities(entities);

                                    getResultPage(listItemResponse);
                                } else if(bodyResponse.getBody().getLatitude() > 0L && bodyResponse.getBody().getLongitude() > 0L){
                                    getMapData(String.valueOf(bodyResponse.getBody().getLatitude()),
                                            String.valueOf(bodyResponse.getBody().getLongitude()),
                                            DaquvConfig.defaultRadius);
                                } else {
                                    getTTSBinary(mContext.getString(R.string.map_search_fail_counterpartname), null, DaquvConfig.CODE.API_NLU_REASK);
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_REASK, mContext.getString(R.string.map_search_fail_counterpartname));
                                }
                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_SEARCH_COPLIST, mContext.getString(R.string.err_msg_daquv_12)));
                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable e) throws Exception {
                            sendError(e);
                        }
                    }));

        } catch ( Exception e) {
            Logger.error(e);
        }
    }

    /**
     * 메인 페이지 요청
     *
     * @param url 메인페이지 주소
     */
    public void getMainPage(String url) {

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addIBKToken(DaquvConfig.service == DaquvConfig.SERVICE.IBKCRM)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        try {
                            if (response.isSuccessful()) {
                                mainUrl = url;
                                mainData = response.body().string();
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_MAIN_DATA, url);
                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_MAIN_DATA, mContext.getString(R.string.err_msg_daquv_8)));
                            }
                        } catch (Exception e) {
                            sendError(e);
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_MAIN_DATA, mContext.getString(R.string.err_msg_daquv_8)));
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable e) throws Exception {
                        sendError(e);
                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                new ErrorData(DaquvConfig.CODE.API_MAIN_DATA, mContext.getString(R.string.err_msg_daquv_8)));
                    }
                }));

    }


    /**
     * 재질의 페이지 요청
     * TTS API 실행(재잘의 문구)
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getReAskPage(NLUResultResponse nluResultResponse) {
        if (!TextUtils.isEmpty(nluResultResponse.getTts())) {
            TTSResponse response = new TTSResponse(nluResultResponse.getTts(), DaquvConfig.CODE.API_NLU_REASK);
            DaquvConfig.ttsSession = nluResultResponse.getTts().hashCode();
            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_TTS, response);
        } else {
            getTTSBinary(nluResultResponse.getTtsText(), null, DaquvConfig.CODE.API_NLU_REASK);
        }
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_REASK, nluResultResponse.getTtsText());
    }

    /**
     * 실패 페이지 요청
     * TTS API 실행(실패 문구)
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getFailPage(NLUResultResponse nluResultResponse) {
        DaquvSDK.getInstance().getEngine().addFailCount();
        if (DaquvSDK.getInstance().getEngine().isMaxFailCount()) {
            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_FAIL_MAX, "API_NLU_FAIL_MAX");
            return;
        }
        String message;
        if (TextUtils.isEmpty(nluResultResponse.getTts())) {
            message = mContext.getString(R.string.err_fail_title);
            getTTSBinary(message, null, DaquvConfig.CODE.API_NLU_FAIL);
        } else {
            message = nluResultResponse.getTts();
            getTTSBinary(message, null, DaquvConfig.CODE.API_NLU_FAIL);
        }
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_FAIL, message);
    }

    /**
     * 중복기업 확인 요청
     *
     * @param countpartname NLU 데이터
     */
    public void getCusInfo(String countpartname) {
        //BODY
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("entNm", countpartname);

            Callable<Response> callable = () -> {
                HttpClient client = new HttpClient.Builder()
                        .setUrl(DaquvConfig.API.CRM_GET_CUSINFO)
                        .setCookie(getCookieJar())
                        .setCache(responseCache)
                        .setJsonData(jsonObject.toString())
                        .addIBKToken(true)
                        .isLogging(true)
                        .builder();
                return client.getCall().execute();
            };

            commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(new Consumer<Response>() {
                        @Override
                        public void accept(Response response) throws Exception {
                            BaseResponse baseResponse = new BaseResponse(response, responseCache);
                            if (baseResponse.isSuccess()) {
                                CusInfoModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), CusInfoModel.class);
                                if(!TextUtils.isEmpty(bodyResponse.getBody().getUrl())) {
                                    NLUResultResponse listItemResponse = new NLUResultResponse();
                                    listItemResponse.setUrl(bodyResponse.getBody().getUrl());
                                    listItemResponse.setIntent("IB017");

                                    ArrayList<Entities> entities = new ArrayList<>();
                                    entities.add(new Entities("COUNTERPARTNAME", countpartname,null,null));
                                    listItemResponse.setEntities(entities);

                                    getResultPage(listItemResponse);
                                } else if(!TextUtils.isEmpty(bodyResponse.getBody().getCompanyId())){
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_GET_CUSINFO, bodyResponse.getBody());
                                } else {
                                    getTTSBinary(mContext.getString(R.string.map_search_fail_counterpartname), null, DaquvConfig.CODE.API_NLU_REASK);
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_REASK, mContext.getString(R.string.map_search_fail_counterpartname));
                                }
                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_GET_CUSINFO, mContext.getString(R.string.err_msg_daquv_13)));
                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable e) throws Exception {
                            sendError(e);
                        }
                    }));

        } catch ( Exception e) {
            Logger.error(e);
        }
    }

    /**
     * 상담내용 등록 페이지 요청
     * TTS API 실행(재잘의 문구)
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getConsultPage(NLUResultResponse nluResultResponse) {
        String countpartname = "";
        if(nluResultResponse.getEntities() != null && nluResultResponse.getEntities().size() > 0) {
            for(Entities entities : nluResultResponse.getEntities()) {
                if(!TextUtils.isEmpty(entities.getEntity()) &&
                        entities.getEntity().equalsIgnoreCase("COUNTERPARTNAME")) {
                    countpartname = entities.getValue();
                }
            }
        }
        getCusInfo(countpartname);
    }

    public void uploadConsultData(String companyId, String entNm , String dscsnDe, String dscsnTime , String dscsnCn) {

        ConsultRequest request = new ConsultRequest(companyId, entNm, dscsnDe, dscsnTime, dscsnCn);

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_CONSULT_URL)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(request.getJSON())
                    .addIBKToken(true)
                    .isLogging(true)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        if (baseResponse.isSuccess()) {
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_CONSULT_UPLOAD, baseResponse.getBody());
                        } else {
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_CONSULT_UPLOAD, mContext.getString(R.string.err_msg_daquv_11)));
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));

    }


    /**
     * TTS Binary 요청
     *
     * @param tts 변환할 TTS 문구
     */
    public void getTTSBinary(String tts, String callback, int code) {
        DaquvConfig.ttsSession = tts.hashCode();
        Callable<Response> callable = () -> {

            HashMap<String, String> parameter = new HashMap<>();
            parameter.put("text", tts);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("text", tts);

            String url = "";
            switch (DaquvConfig.service) {
                case HUB:
                case POSCO:
                    url = DaquvConfig.API.TTS_URL;
                    break;
                case IBKCRM:
                    url = DaquvConfig.API.CRM_TTS_URL;
                    break;
                default:
                    url = DaquvConfig.API.TTS_URL;
                    break;
            }

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addJWTToken(false)
                    .addIBKToken(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service)
                    .isPost(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service)
                    .setParameter(parameter)
                    .setJsonData(jsonObject.toString())
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        try {
                            if (baseResponse.isSuccess()) {
                                TTSModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), TTSModel.class);
                                if (!TextUtils.isEmpty(callback)) {
                                    bodyResponse.getItems().setCallBack(callback);
                                }
                                if (code > 0) {
                                    bodyResponse.getItems().setCode(code);
                                }
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_TTS, bodyResponse.getItems());
                            } else {
                                Logger.error(mContext.getString(R.string.err_msg_daquv_7) + "::" + response.body().string());
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_TTS, mContext.getString(R.string.err_msg_daquv_7)));
                            }
                        } catch (Exception e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    public void getTTSBinary(String tts) {
        getTTSBinary(tts, null, 0);
    }


    /**
     * TTS Binary 요청
     */
    public void uploadAudioFile(String filePath) {
        Callable<Response> callable = () -> {

            File file = new File(filePath);

            MultipartBody.Builder bodyBuilder = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart(
                            "file",
                            file.getName(),
                            RequestBody.create(MediaType.parse("application/octet-stream"), file)
                    )
                    .addFormDataPart("companyId", "kiwoom");

            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.AUDIO_UPLOAD_URL)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setBody(bodyBuilder.build())
                    .isLogging(true)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
//                        File tempFile = new File(filePath);
//                        if(tempFile.exists()) {
//                            tempFile.delete();
//                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
//                        File tempFile = new File(filePath);
//                        if(tempFile.exists()) {
//                            tempFile.delete();
//                        }
                    }
                }));
    }

    /**
     * 지도 필터 데이터 요청
     */
    public void getMapFilter() {
        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_GET_MAP_FILTER)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addIBKToken(true)
                    .isPost(false)
                    .isLogging(false)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        try {
                            if (baseResponse.isSuccess()) {
                                MapFilterModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), MapFilterModel.class);
                                DaquvConfig.mapFilterList = bodyResponse.getFilter();
                                for(MapFilterResponse data : DaquvConfig.mapFilterList) {
                                    if(data.getCategory().equalsIgnoreCase("radius")) {
                                        DaquvConfig.defaultRadius = data.getValue().get(0).getName();
                                    }
                                }
                            }
                        } catch (Exception e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    /**
     * TTS Binary 요청
     */
    public void getSttReplaceData() {


        Callable<Response> callable = () -> {

            String url = "";
            switch (DaquvConfig.service) {
                case HUB:
                case POSCO:
                    url = DaquvConfig.API.STT_REPLACE_URL;
                    break;
                case IBKCRM:
                    url = DaquvConfig.API.CRM_STT_REPLACE_URL;
                    break;
                default:
                    url = DaquvConfig.API.STT_REPLACE_URL;
                    break;
            }

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addIBKToken(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service)
                    .isPost(false)
                    .isLogging(false)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        try {
                            if (baseResponse.isSuccess()) {
                                STTReplaceResponse bodyResponse = new Gson().fromJson(baseResponse.getBody(), STTReplaceResponse.class);
                                DaquvConfig.replaces = bodyResponse.getReplaces();
                            }
                        } catch (Exception e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }


    /**
     * 인증번호 요청
     */
    public void crmGetRequestCode(String appId,
                                  String cellPhoneNo,
                                  String birthday,
                                  String ecnmc,
                                  String name,
                                  String cellPhoneVendor,
                                  String frnr) {
        REQ_SVC_P041 reqJsonObject = new REQ_SVC_P041(appId, cellPhoneNo, birthday, ecnmc, name, cellPhoneVendor, frnr);

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_BASE_URL)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(new TranJson().makeTranData(reqJsonObject).toString())
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        try {
                            if (response.isSuccessful()) {
                                RES_SVC_P041 bodyResponse = new Gson().fromJson(response.body().string(), RES_SVC_P041.class);
                                if (bodyResponse.getBody() == null) {
                                    Logger.error(mContext.getString(R.string.err_msg_daquv_5) + "::" + bodyResponse.getRsltMsg());
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, mContext.getString(R.string.err_msg_daquv_5));
                                    return;
                                }
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_REQUEST_CODE, bodyResponse);
                            } else {
                                Logger.error(mContext.getString(R.string.err_msg_daquv_5) + "::" + response.body().string());
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, mContext.getString(R.string.err_msg_daquv_5));
                            }
                        } catch (Exception e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    /**
     * 인증번호 검증
     */
    public void crmGetVerifyCode(String appId,
                                 String clphNo,
                                 String trscUnqNo,
                                 String smsCertNo) {
        REQ_SVC_C028 reqJsonObject = new REQ_SVC_C028(appId, clphNo, trscUnqNo, smsCertNo);

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_BASE_URL)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(new TranJson().makeTranData(reqJsonObject).toString())
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        try {
                            if (response.isSuccessful()) {
                                RES_SVC_C028 bodyResponse = new Gson().fromJson(response.body().string(), RES_SVC_C028.class);
                                if (bodyResponse.getBody() == null) {
                                    Logger.error(mContext.getString(R.string.err_msg_daquv_6) + "::" + bodyResponse.getRsltMsg());
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, mContext.getString(R.string.err_msg_daquv_6));
                                    return;
                                }
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_VERIFY_CODE, bodyResponse);
                            } else {
                                Logger.error(mContext.getString(R.string.err_msg_daquv_6) + "::" + response.body().string());
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, mContext.getString(R.string.err_msg_daquv_6));
                            }
                        } catch (Exception e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }


    //============== NLU CONVERSION ================//

    /**
     * 순번 데이터 반환
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getTURNData(NLUResultResponse nluResultResponse) {
        if (!TextUtils.isEmpty(nluResultResponse.getIntent()) && nluResultResponse.getIntent().equals(DaquvConfig.appConfig.intentCodes.turn)) {
            for (Entities entities : nluResultResponse.getEntities()) {
                if (entities.getEntity().equals("TURN")) {
                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_TURN, entities.getValue());
                    return;
                }
            }
        }
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_TURN, mContext.getString(R.string.err_msg_daquv_10));
    }
}