package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CompanyInfo implements Serializable {
    @SerializedName("companyId")
    private String companyId;

    @SerializedName("companyName")
    private String companyName;

    @SerializedName("clientSecret")
    private String clientSecret;

    public CompanyInfo() {
    }

    public CompanyInfo(String companyId, String companyName, String clientSecret) {
        this.companyId = companyId;
        this.companyName = companyName;
        this.clientSecret = clientSecret;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getClientSecret() {
        return clientSecret;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }
}