package com.daquv.sdk.data.request;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.utils.network.TranJson;

public class LoginRequest extends TranJson {

    public LoginRequest(DaquvConfig.SERVICE service ,String... info) {
        super();
        put("email", info[0]);
        if(DaquvConfig.SERVICE.IBKCRM == service) {
            put("emn", info[1]);
            if(info.length > 3) {
                put("updateAggrYn", info[3]);
            }
        } else {
            put("password", info[1]);
        }
        put("companyId", info[2]);
    }
}