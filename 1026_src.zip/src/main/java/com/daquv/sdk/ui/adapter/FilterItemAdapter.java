package com.daquv.sdk.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.data.response.MapFilterValue;
import com.daquv.sdk.ui.component.BasicSwitch;

import java.util.ArrayList;

public class FilterItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_SELECT = 0;
    private static final int TYPE_MULTI = 1;

    private int type = TYPE_SELECT;
    private String category;
    private ArrayList<MapFilterValue> selected;
    private ArrayList<MapFilterValue> filters;

    public interface OnItemClickListener {
        void onItemClick(String category, ArrayList<MapFilterValue> data);
    }

    private OnItemClickListener listener = null;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public FilterItemAdapter(ArrayList<MapFilterValue> filters) {
        this.filters = filters;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflateView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_filter_item, parent, false);
        return new SelectHolder(inflateView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MapFilterValue items = filters.get(position);
        if (holder instanceof SelectHolder) {
            SelectHolder dataHolder = (SelectHolder) holder;
            dataHolder.name.setText(items.getName());
            if(selected.contains(items)) {
                dataHolder.check.setVisibility(View.VISIBLE);
            } else {
                dataHolder.check.setVisibility(View.INVISIBLE);
            }
            dataHolder.container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setTag("container");
                    if (listener != null) {
                        if(type == TYPE_SELECT) {
                            selected.clear();
                            selected.add(items);
                            listener.onItemClick(category, selected);
                        } else {
                            if(selected.contains(items)) {
                                selected.remove(items);
                            } else {
                                selected.add(items);
                            }
                            listener.onItemClick(category, selected);
                            notifyDataSetChanged();
                        }
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return filters.size();
    }

    public void setFilters(ArrayList<MapFilterValue> filters) {
        this.filters = filters;
    }

    public ArrayList<MapFilterValue> getFilters() {
        return filters;
    }

    public ArrayList<MapFilterValue> getSelected() {
        return selected;
    }

    public void setSelected(ArrayList<MapFilterValue> selected) {
        this.selected = selected;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void notifyChanged() {
        notifyItemRangeChanged(0, getItemCount(), true);
    }

    static class SelectHolder extends RecyclerView.ViewHolder {
        LinearLayoutCompat container;
        TextView name;
        ImageView check;

        SelectHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.item_container);
            name = itemView.findViewById(R.id.item_name);
            check = itemView.findViewById(R.id.item_check);
        }
    }
}
