package com.daquv.sdk.data.request;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.utils.network.TranJson;

public class LoginMultiRequest {

   private LoginRequest loginRequest;
   private LoginRequest loginRequest2;

    public LoginRequest getLoginRequest() {
        return loginRequest;
    }

    public void setLoginRequest(LoginRequest loginRequest) {
        this.loginRequest = loginRequest;
    }

    public LoginRequest getLoginRequest2() {
        return loginRequest2;
    }

    public void setLoginRequest2(LoginRequest loginRequest2) {
        this.loginRequest2 = loginRequest2;
    }
}