package com.daquv.sdk.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.widget.Toast;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.stt.inside.utils.VoiceRecorder;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class AudioFileRecorder {

    private static final int CHANNEL = AudioFormat.CHANNEL_IN_MONO;
    private static final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;
    private static final int[] SAMPLE_RATE_CANDIDATES = new int[]{16000, 22050, 44100, 11025};

    private final Object mLock = new Object();
    private final Context context;

    private AudioRecord audioRecord;
    private Thread recordingThread;
    private FileOutputStream outputStream;
    private boolean isRecording = false;
    private short[] buffer = null;
    private int sampleRate = 0;

    public AudioFileRecorder(Context context) {
        this.context = context;
        File logDirectory = new File(DaquvConfig.dirPath);
        if (!logDirectory.exists()) {
            logDirectory.mkdirs();
        }
    }

    @SuppressLint("MissingPermission")
    public void startRecording() {

        for (int sampleRate : SAMPLE_RATE_CANDIDATES) {
            int sizeInBytes = AudioRecord.getMinBufferSize(sampleRate, CHANNEL, ENCODING);
            if (sizeInBytes == AudioRecord.ERROR_BAD_VALUE) {
                continue;
            }
            final AudioRecord audioRecord = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    sampleRate, CHANNEL, ENCODING, sizeInBytes);

            if (audioRecord.getState() == AudioRecord.STATE_INITIALIZED) {

                this.buffer = new short[sizeInBytes];
                this.audioRecord = audioRecord;
                this.sampleRate = sampleRate;
                break;
            } else {
                audioRecord.release();
            }
        }

        if(audioRecord == null || buffer == null) {
            Toast.makeText(context , "녹음을 할 수 없습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            outputStream = context.openFileOutput("temp.pcm", Context.MODE_PRIVATE);
            audioRecord.startRecording();
            isRecording = true;

            recordingThread = new Thread(new ProcessVoice());
            recordingThread.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class ProcessVoice implements Runnable {

        @Override
        public void run() {
            while (isRecording) {
                synchronized (mLock) {
                    if (Thread.currentThread().isInterrupted()) {
                        break;
                    }
                    if(buffer == null) {
                        return;
                    }
                    int size = audioRecord.read(buffer, 0, buffer.length);
                    try {
                        if (size == AudioRecord.ERROR_INVALID_OPERATION || size == AudioRecord.ERROR_BAD_VALUE) {
                            return;
                        }
                        byte[] data = convert(buffer);
                        outputStream.write(data);
                    } catch (IOException e) {
                        Logger.error(e);
                    }
                }
            }
        }
    }

    public void resumeRecording() {
        //NONE
    }

    public void pauseRecording() {
        //NONE
    }

    public void stopRecording() {
        synchronized (mLock) {
            isRecording = false;
            if (recordingThread != null) {
                recordingThread.interrupt();
                recordingThread = null;
            }
            if (audioRecord != null) {
                try {
                    audioRecord.stop();
                } catch (Exception ignore) {
                    Logger.error(ignore);
                } finally {
                    audioRecord.release();
                    audioRecord = null;
                }
            }
            buffer = null;
            if(outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException e) {
                    Logger.error(e);
                }
            }
            File pcmFile = new File(DaquvConfig.dirPath + "/temp.pcm");
            File wavFile = new File(DaquvConfig.dirPath + "/temp.wav");
            try {
                rawToWave(pcmFile, wavFile);
            } catch (IOException e) {
                Logger.error(e);
                Toast.makeText(context , "녹음 파일이 저장되지 않았습니다.", Toast.LENGTH_SHORT).show();
            } finally {
                DaquvSDK.getInstance().getAPI().uploadAudioFile(wavFile.getAbsolutePath());
            }
        }
    }

    public boolean isRecording() {
        return isRecording;
    }


    private void rawToWave(final File pcmFile, final File waveFile) throws IOException {
        byte[] rawData = new byte[(int) pcmFile.length()];
        DataInputStream input = null;
        try {
            input = new DataInputStream(new FileInputStream(pcmFile));
            input.read(rawData);
        } finally {
            if (input != null) {
                input.close();
            }
        }
        DataOutputStream output = null;
        try {
            output = new DataOutputStream(new FileOutputStream(waveFile));
            // WAVE header
            writeString(output, "RIFF"); // chunk id
            writeInt(output, 36 + rawData.length); // chunk size
            writeString(output, "WAVE"); // format
            writeString(output, "fmt "); // subchunk 1 id
            writeInt(output, 16); // subchunk 1 size
            writeShort(output, (short) 1); // audio format (1 = PCM)
            writeShort(output, (short) 1); // number of channels
            writeInt(output, sampleRate); // sample rate
            writeInt(output, sampleRate * 2); // byte rate
            writeShort(output, (short) 2); // block align
            writeShort(output, (short) 16); // bits per sample
            writeString(output, "data"); // subchunk 2 id
            writeInt(output, rawData.length); // subchunk 2 size
            // Audio data (conversion big endian -> little endian)
            short[] shorts = new short[rawData.length / 2];
            ByteBuffer.wrap(rawData).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts);
            ByteBuffer bytes = ByteBuffer.allocate(shorts.length * 2);
            for (short s : shorts) {
                bytes.putShort(s);
            }
            output.write(rawData);
        } finally {
            if (output != null) {
                output.close();
            }
        }
    }

    public byte[] convert(short[] audioData) {

        int bufferSizeInBytes = audioData.length * 2;
        byte[] buffer = new byte[bufferSizeInBytes];
        for (int i = 0; i < audioData.length; i++) {
            buffer[i * 2] = (byte) (audioData[i] & 0xff);
            buffer[(i * 2) + 1] = (byte) ((audioData[i] >> 8) & 0xff);
        }

        return buffer;
    }

    private void writeInt(final DataOutputStream output, final int value) throws IOException {
        output.write(value >> 0);
        output.write(value >> 8);
        output.write(value >> 16);
        output.write(value >> 24);
    }

    private void writeShort(final DataOutputStream output, final short value) throws IOException {
        output.write(value >> 0);
        output.write(value >> 8);
    }

    private void writeString(final DataOutputStream output, final String value) throws IOException {
        for (int i = 0; i < value.length(); i++) {
            output.write(value.charAt(i));
        }
    }
}
