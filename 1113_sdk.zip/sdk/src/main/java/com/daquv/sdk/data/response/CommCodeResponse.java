package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class CommCodeResponse implements Serializable {

    @SerializedName("cmmn_cd")
    private String cmmnCd;

    @SerializedName("code_nm")
    private String codeNm;

    public String getCmmnCd() {
        return cmmnCd;
    }

    public void setCmmnCd(String cmmnCd) {
        this.cmmnCd = cmmnCd;
    }

    public String getCodeNm() {
        return codeNm;
    }

    public void setCodeNm(String codeNm) {
        this.codeNm = codeNm;
    }
}
