package com.daquv.sdk.data.response;


import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class RsaKeyResponse implements Serializable {
    @SerializedName("RSAModulus")
    private String rsaModulus;

    @SerializedName("RSAExponent")
    private String rsaExponent;

    public RsaKeyResponse() {
    }

    public RsaKeyResponse(String rsaModulus, String rsaExponent) {
        this.rsaModulus = rsaModulus;
        this.rsaExponent = rsaExponent;
    }

    public String getRsaModulus() {
        return rsaModulus;
    }

    public void setRsaModulus(String rsaModulus) {
        this.rsaModulus = rsaModulus;
    }

    public String getRsaExponent() {
        return rsaExponent;
    }

    public void setRsaExponent(String rsaExponent) {
        this.rsaExponent = rsaExponent;
    }
}