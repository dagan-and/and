package com.daquv.sdk.presentation;

import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_COLLAPSED;
import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED;
import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_HIDDEN;

import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.Entities;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.data.response.LocationItemResponse;
import com.daquv.sdk.data.response.MapFilterResponse;
import com.daquv.sdk.data.response.FilterValue;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.ui.FilterBottomSheetView;
import com.daquv.sdk.ui.FilterView;
import com.daquv.sdk.ui.MapBottomSheetView;
import com.daquv.sdk.ui.comm.ComDialogBuilder;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.HeightProvider;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.webview.ComWebView;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraPosition;
import com.naver.maps.map.CameraUpdate;
import com.naver.maps.map.MapView;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.NaverMapOptions;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.UiSettings;
import com.naver.maps.map.clustering.Cluster;
import com.naver.maps.map.clustering.ClusterMarkerInfo;
import com.naver.maps.map.clustering.ClusterMarkerUpdater;
import com.naver.maps.map.clustering.Clusterer;
import com.naver.maps.map.clustering.ClusteringKey;
import com.naver.maps.map.clustering.DefaultClusterMarkerUpdater;
import com.naver.maps.map.clustering.DefaultClusterOnClickListener;
import com.naver.maps.map.clustering.DefaultMarkerManager;
import com.naver.maps.map.clustering.DistanceStrategy;
import com.naver.maps.map.clustering.LeafMarkerInfo;
import com.naver.maps.map.clustering.LeafMarkerUpdater;
import com.naver.maps.map.clustering.MarkerInfo;
import com.naver.maps.map.clustering.MarkerManager;
import com.naver.maps.map.clustering.Node;
import com.naver.maps.map.clustering.TagMergeStrategy;
import com.naver.maps.map.overlay.Align;
import com.naver.maps.map.overlay.CircleOverlay;
import com.naver.maps.map.overlay.LocationOverlay;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.Overlay;
import com.naver.maps.map.overlay.OverlayImage;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.FormBody;

public class MapFragment extends Fragment implements OnMapReadyCallback, Overlay.OnClickListener {

    DaquvEngine.Callback engineCallback;
    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;

    private ArrayList<MapFilterResponse> filters = new ArrayList<>();
    private final ArrayList<Marker> markers = new ArrayList<>();

    private final ArrayList<Marker> clusters = new ArrayList<>();
    private ArrayList<LocationItem> locationItem= new ArrayList<>();
    private Location location;
    private String companyName;
    private NaverMap naverMap;
    private Marker positionMarker;
    private Marker selectMarker;
    private FilterView filterView;
    private View filterDim;
    private ViewGroup filterContainer;
    private ViewGroup dataSheetContainer;
    private ViewGroup filterSheetContainer;
    private MapBottomSheetView dataSheetView;
    private FilterBottomSheetView filterSheetView;
    private TextView btnMy;
    private TextView btnCompany;
    private TextView btnAddress;
    private TextView searchByLocation;
    private HeightProvider heightProvider;
    private FrameLayout keypadOutside;

    private boolean isMapDataBeforeMapObject;
    private LocationItemResponse locationItemResponse;
    private LatLng currentCameraPosition = new LatLng(0L,0L);

    private Clusterer<ItemKey> clusterer;
    private HashMap<String, Integer> groupCountMap = new HashMap<>();
    private DecimalFormat decimalFormat = new DecimalFormat("#,###");
    private double currentZoom = 0.0;
    private ExecutorService mExecutor;


    private class ItemKey implements ClusteringKey {
        private final String companyId;
        private final LatLng latLng;

        public ItemKey(String companyId, LatLng latLng) {
            this.companyId = companyId;
            this.latLng = latLng;
        }

        @Override
        public LatLng getPosition() {
            return latLng;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            ItemKey itemKey = (ItemKey) o;
            return companyId.equals(itemKey.companyId);
        }

        @Override
        public int hashCode() {
            return companyId.hashCode();
        }
    }

    public class CustomMarkerManager implements MarkerManager {

        @NonNull
        @UiThread
        public final Marker retainMarker(@NonNull MarkerInfo info) {
            return this.createMarker();
        }

        @UiThread
        public final void releaseMarker(@NonNull MarkerInfo info, @NonNull Marker marker) {
            marker.setMap(null);
        }

        @NonNull
        @UiThread
        public Marker createMarker() {
            return new Marker();
        }
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_map, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        filterContainer = view.findViewById(R.id.filter_container);
        dataSheetContainer = view.findViewById(R.id.data_sheet);
        filterSheetContainer = view.findViewById(R.id.filter_sheet);
        filterDim = view.findViewById(R.id.filter_dim);
        btnMy = view.findViewById(R.id.btn_my);
        btnCompany = view.findViewById(R.id.btn_company);
        btnAddress = view.findViewById(R.id.btn_address);
        keypadOutside = view.findViewById(R.id.keypad_outside);
        searchByLocation = view.findViewById(R.id.search_by_location);
        view.findViewById(R.id.btn_home).setOnClickListener(view1 -> listener.addMainView(false));

        mExecutor = Executors.newCachedThreadPool();

        FragmentManager fm = getChildFragmentManager();
        com.naver.maps.map.MapFragment mapView = (com.naver.maps.map.MapFragment)fm.findFragmentById(R.id.map_container);
        if (mapView == null) {
            mapView = com.naver.maps.map.MapFragment.newInstance();
            fm.beginTransaction().add(R.id.map_container, mapView).commit();
        }

        mapView.getMapAsync(this);

        if(DaquvConfig.mapFilterList != null &&
                DaquvConfig.mapFilterList.getFilter() != null &&
                DaquvConfig.mapFilterList.getFilter().size() > 0) {
            for(MapFilterResponse data : DaquvConfig.mapFilterList.getFilter()) {
                data.getSelected().clear();
            }
            filters = DaquvConfig.mapFilterList.getFilter();
        }

        btnMy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.showLoading();
                DaquvSDK.getInstance().getAPI().getMapData("내 위치",String.valueOf(DaquvSDK.getInstance().getLocation().getLatitude()),
                        String.valueOf(DaquvSDK.getInstance().getLocation().getLongitude()),
                        getFilterRadius(),
                        filters);
            }
        });
        searchByLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.showLoading();
                DaquvSDK.getInstance().getAPI().getMapData(companyName,String.valueOf(currentCameraPosition.latitude),
                        String.valueOf(currentCameraPosition.longitude),
                        getFilterRadius(),
                        filters);
            }
        });
        btnCompany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.addKeypadView(true, false);
            }
        });
        btnAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.addKeypadView(false, true);
            }
        });
        keypadOutside.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(dataSheetView.getEditText().getWindowToken(), 0);
            }
        });

        setDataSheetView();
        setFilterSheetView();

    }

    public void setLocationItem(ArrayList<LocationItem> item) {
        this.locationItem = item;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    public void setCompanyName(String name) { this.companyName = name;}

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);
                if (code == DaquvConfig.CODE.API_NLU_MAP) {
                    if (result instanceof LocationItemResponse &&
                            ((LocationItemResponse) result).getBody() != null) {

                        if(naverMap == null) {
                            Logger.info("주변 기업데이터가 지도 객체 생성보다 먼저 내려옴");
                            isMapDataBeforeMapObject = true;
                            locationItemResponse = (LocationItemResponse) result;
                            return;
                        }

                        setMapData((LocationItemResponse) result);

                    } else {
                        locationItem.clear();
                        resetMarkers();
                        initButtonState();

                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                DaquvSDK.getInstance().getAPI().getTTSBinary(requireContext().getString(R.string.map_no_data));
                            }
                        }, 300);

                    }
                }
                if (code == DaquvConfig.CODE.KEYPAD_COMPANY) {
                    NLUResultResponse response = new NLUResultResponse();
                    response.setEntities(new ArrayList<>());
                    ArrayList<Entities> entities = new ArrayList<>();
                    entities.add(new Entities("counterPartName", ((String) result).trim(),null,null));
                    entities.add(new Entities("gubun", "1",null,null));
                    response.setEntities(entities);
                    DaquvSDK.getInstance().getAPI().getSearchCopList(response);
                }
                if (code == DaquvConfig.CODE.KEYPAD_ADDRESS) {
                    NLUResultResponse response = new NLUResultResponse();
                    response.setEntities(new ArrayList<>());
                    ArrayList<Entities> entities = new ArrayList<>();
                    entities.add(new Entities("counterPartName", ((String) result).trim(),null,null));
                    entities.add(new Entities("gubun", "3",null,null));
                    response.setEntities(entities);
                    DaquvSDK.getInstance().getAPI().getSearchCopList(response);
                }
                if(code == DaquvConfig.CODE.API_ERROR) {
                    if(result instanceof ErrorData) {
                        if(((ErrorData) result).getCode() == DaquvConfig.CODE.KEYPAD_COMPANY) {
                            DaquvSDK.getInstance().getAPI().getTTSBinary(((ErrorData) result).getMsg());
                            ComDialogBuilder dialogBuilder = new ComDialogBuilder(requireContext());
                            dialogBuilder.showConfirm(new ComDialogBuilder.OnCommDlgClickListener() {
                                @Override
                                public void onLeftButton() {/*NONE*/}
                                @Override
                                public void onRightButton() {/*NONE*/}

                                @Override
                                public void onDismiss() {

                                }
                            }, requireContext().getString(R.string.err_msg_daquv_13), requireContext().getString(R.string.dqv_confirm));
                        }
                        if(((ErrorData) result).getCode() == DaquvConfig.CODE.KEYPAD_ADDRESS) {
                            DaquvSDK.getInstance().getAPI().getTTSBinary(((ErrorData) result).getMsg());
                            ComDialogBuilder dialogBuilder = new ComDialogBuilder(requireContext());
                            dialogBuilder.showConfirm(new ComDialogBuilder.OnCommDlgClickListener() {
                                @Override
                                public void onLeftButton() {/*NONE*/}
                                @Override
                                public void onRightButton() {/*NONE*/}

                                @Override
                                public void onDismiss() {

                                }
                            }, requireContext().getString(R.string.err_msg_daquv_15), requireContext().getString(R.string.dqv_confirm));
                        }
                    }
                }
            }
        };

        DaquvSDK.getInstance().addCallBack(engineCallback);

        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if(filterSheetView.isStateExpanded()) {
                    filterDim.setVisibility(View.GONE);
                    filterSheetView.collapseView();
                    return;
                }
                if(filterContainer.getChildCount() > 0) {
                    setFilterView(false);
                    return;
                }
                if(dataSheetView.isStateExpanded()) {
                    dataSheetView.collapseView();
                    return;
                }
                listener.onBackPress(MapFragment.this);
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        heightProvider = new HeightProvider(requireActivity());
        heightProvider.init();
        heightProvider.setHeightListener(new HeightProvider.HeightListener() {
            @Override
            public void onHeightChanged(int height) {
                try {
                    if (height > 0 ) {
                        keypadOutside.setVisibility(View.VISIBLE);
                    } else if (height == 0) {
                        keypadOutside.setVisibility(View.GONE);
                    }
                } catch (NullPointerException e) {
                    Logger.error(e);
                }
            }
        });
    }

    private void setMapData(LocationItemResponse result) {
        setLocationItem(((LocationItemResponse) result).getBody());

        Location location = new Location(DaquvSDK.getInstance().getLocation());
        location.setLatitude(((LocationItemResponse) result).getLatitude());
        location.setLongitude(((LocationItemResponse) result).getLongitude());
        setLocation(location);

        companyName = ((LocationItemResponse) result).getCompanyName();

        CameraUpdate cameraUpdate = CameraUpdate.scrollTo(new LatLng(
                location.getLatitude(),
                location.getLongitude()));
        naverMap.moveCamera(cameraUpdate);

        if (clusterer != null) {
            clusterer.clear();
        }
        if(groupCountMap != null) {
            groupCountMap.clear();
        }
        if (markers.size() > 0) {
            for (Marker marker : markers) {
                marker.setMap(null);
            }
        }
        markers.clear();

        resetMarkers();
        initButtonState();

        mExecutor.execute(new Runnable() {
            @Override
            public void run() {
                Map<ItemKey, LocationItem> map = new HashMap<>();
                for (LocationItem it : locationItem) {
                    ItemKey itemKey = new ItemKey(it.getCompanyId(), new LatLng(it.getLatitude(), it.getLongitude()));
                    if (groupCountMap.get(it.getAddressGroup()) == null ) {
                        groupCountMap.put(it.getAddressGroup(), 1);
                    } else {
                        groupCountMap.put(it.getAddressGroup(), groupCountMap.get(it.getAddressGroup()) + 1);
                    }
                    map.put(itemKey, it);
                }
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if (clusterer != null) {
                            clusterer.addAll(map);
                            clusterer.setMap(naverMap);
                        }
                        if(dataSheetView != null) {
                            dataSheetView.updateItem(locationItem);
                        }
                    }
                });
            }
        });

        if(locationItem != null && !locationItem.isEmpty()) {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    DaquvSDK.getInstance().getAPI().getTTSBinary(String.format(requireContext().getString(R.string.map_search_data), locationItem.size()));
                }
            }, 300);
        } else {
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override
                public void run() {
                    DaquvSDK.getInstance().getAPI().getTTSBinary(requireContext().getString(R.string.map_no_data));
                }
            }, 300);
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
        onBackPressedCallback.remove();
    }

    @Override
    public boolean onClick(Overlay p0) {

        resetMarkers();

        Marker marker = (Marker) p0;
        LocationItem item = (LocationItem) p0.getTag();
        if(groupCountMap.containsKey(item.getAddressGroup()) && groupCountMap.get(item.getAddressGroup()) > 1) {
            marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_building_s));
        } else {
            if (!TextUtils.isEmpty(item != null ? item.getIbtrYN() : null) && "Y".equalsIgnoreCase(item.getIbtrYN())) {
                marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_trade_y_s));
            } else {
                marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_trade_n_s));
            }
        }
        marker.setIconTintColor(Color.TRANSPARENT);

        // 3. Select Marker
        selectMarker = marker;

        if(groupCountMap.containsKey(item.getAddressGroup()) && groupCountMap.get(item.getAddressGroup()) > 1) {
            selectMarker.setTag(marker.getTag());
        } else {
            selectMarker.setTag(marker.getTag());
        }
        markers.add(marker);

        //선택한 마커와 동일한 주소가 있으면 리스트 담기
        ArrayList<LocationItem> duplicateList = new ArrayList<>();
        for(LocationItem data : locationItem) {
            if(item.getLatitude() == data.getLatitude() &&
                    item.getLongitude() == data.getLongitude()) {
                duplicateList.add(data);
            }
        }
        dataSheetView.setSelectItem(duplicateList);
        return false;
    }

    private void addClusters(Marker marker) {
        if(!clusters.contains(marker)) {
            clusters.add(marker);
        }
    }

    private void resetClusters() {
        if(!clusters.isEmpty()) {
            clusters.clear();
        }
    }

    private void resetMarkers() {
        for (Marker marker : markers) {
            LocationItem item = (LocationItem) marker.getTag();
            if (groupCountMap.containsKey(item.getAddressGroup()) && groupCountMap.get(item.getAddressGroup()) > 1) {
                // ê·¸ë£¹ ë§ì»¤ì¼ ë
                marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_building));
            } else {
                if (!TextUtils.isEmpty(item != null ? item.getIbtrYN() : null) && "Y".equalsIgnoreCase(item.getIbtrYN())) {
                    marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_trade_y));
                } else {
                    marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_trade_n));
                }
            }
            marker.setIconTintColor(Color.TRANSPARENT);
        }
        markers.clear();
    }

    @Override
    public void onMapReady(NaverMap naverMap) {
        this.naverMap = naverMap;
        Logger.dev("onMapReady");

        naverMap.setCameraPosition(new CameraPosition(new LatLng(location.getLatitude(), location.getLongitude()), DaquvConfig.defaultZoom));

        //맵 Zoom Level 지정
        naverMap.setMinZoom(DaquvConfig.minZoom);
        naverMap.setMaxZoom(DaquvConfig.maxZoom);

        UiSettings uiSettings = naverMap.getUiSettings();
        uiSettings.setLogoGravity(Gravity.LEFT|Gravity.TOP);
        uiSettings.setLogoMargin(10,10,10,10);


        //지도뷰 선택 리스너
        naverMap.addOnCameraChangeListener(new NaverMap.OnCameraChangeListener() {
            @Override
            public void onCameraChange(int i, boolean b) {
                if (dataSheetView.isStateExpanded()) {
                    dataSheetView.collapseView();
                }
                currentCameraPosition = naverMap.getCameraPosition().target;
            }
        });

        CircleOverlay circle = new CircleOverlay();
        LocationOverlay locationOverlay = naverMap.getLocationOverlay();
        locationOverlay.setVisible(true);
        locationOverlay.setIcon(OverlayImage.fromResource(R.drawable.img_map_me));
        locationOverlay.setIconHeight(DaquvUtil.convertDPtoPX(requireContext(), 26));
        locationOverlay.setIconWidth(DaquvUtil.convertDPtoPX(requireContext(), 26));

        // ì§ëë·° ì í ë¦¬ì¤ë
        naverMap.addOnCameraChangeListener(new NaverMap.OnCameraChangeListener() {
            @Override
            public void onCameraChange(int i, boolean b) {
                CameraPosition cameraPosition = naverMap.getCameraPosition();
                currentZoom = cameraPosition.zoom;
            }
        });

        naverMap.addOnCameraIdleListener(new NaverMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {
                CameraPosition cameraPosition = naverMap.getCameraPosition();
                currentZoom = cameraPosition.zoom;

                int radius = 1000;
                try {
                    String defaultRadius = DaquvConfig.defaultRadius;
                    String mRadius = defaultRadius.replaceAll("M", "");
                    if (defaultRadius.toUpperCase().contains("K")) {
                        String value = defaultRadius.split("K")[0];
                        int fValue = (int) (Float.parseFloat(value) * 1000);
                        mRadius = String.valueOf(fValue);
                    }
                    radius = Integer.parseInt(mRadius);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                circle.setRadius(radius + 50);
                circle.setColor(getResources().getColor(R.color.circle_background));
                locationOverlay.setPosition(cameraPosition.target);
                circle.setCenter(cameraPosition.target);
                circle.setMap(naverMap);

                if ((int)currentZoom <= DaquvConfig.ZOOM_LEVEL_SI) {
                    for(Marker marker : clusters) {
                        ClusterMarkerInfo info = (ClusterMarkerInfo) marker.getTag();
                        marker.setCaptionText(((LocationItem) info.getTag()).getAddressSI() + "\n" + decimalFormat.format(info.getSize()));
                        marker.setWidth(DaquvUtil.convertDPtoPX(requireContext(), 70));
                        marker.setHeight(DaquvUtil.convertDPtoPX(requireContext(), 70));
                        marker.setIcon(OverlayImage.fromResource(R.drawable.bg_cluster_si));
                        marker.setCaptionTextSize(12);
                    }
                } else if ((int)currentZoom <= DaquvConfig.ZOOM_LEVEL_GU) {
                    for(Marker marker : clusters) {
                        ClusterMarkerInfo info = (ClusterMarkerInfo) marker.getTag();
                        marker.setCaptionText(((LocationItem) info.getTag()).getAddressGU() + "\n" + decimalFormat.format(info.getSize()));
                        marker.setWidth(DaquvUtil.convertDPtoPX(requireContext(), 60));
                        marker.setHeight(DaquvUtil.convertDPtoPX(requireContext(), 60));
                        marker.setIcon(OverlayImage.fromResource(R.drawable.bg_cluster_gu));
                        marker.setCaptionTextSize(12);
                    }
                } else if ((int)currentZoom < DaquvConfig.ZOOM_LEVEL_DONG) {
                    for(Marker marker : clusters) {
                        ClusterMarkerInfo info = (ClusterMarkerInfo) marker.getTag();
                        marker.setCaptionText(((LocationItem) info.getTag()).getAddressDONG() + "\n" + decimalFormat.format(info.getSize()));
                        marker.setWidth(DaquvUtil.convertDPtoPX(requireContext(), 50));
                        marker.setHeight(DaquvUtil.convertDPtoPX(requireContext(), 50));
                        marker.setIcon(OverlayImage.fromResource(R.drawable.bg_cluster_dong));
                        marker.setCaptionTextSize(10);
                    }
                }
            }
        });
        clusterer = new Clusterer.ComplexBuilder<ItemKey>()
                .minClusteringZoom(7)
                .maxClusteringZoom(18)
                .maxScreenDistance(200)
                .thresholdStrategy(zoom -> 0.0)
                .tagMergeStrategy(new TagMergeStrategy() {
                    @Nullable
                    @Override
                    public Object mergeTag(@NonNull Cluster cluster) {
                        if(cluster.getMaxZoom() < DaquvConfig.ZOOM_LEVEL_DONG) {
                            return cluster.getChildren().get(0).getTag();
                        } else {
                            return null;
                        }
                    }
                })
                .distanceStrategy(new DistanceStrategy() {
                    @Override
                    public double getDistance(int zoom, Node node1, Node node2) {
                        if (node1.getTag() != null && node1.getTag() instanceof LocationItem &&
                                node2.getTag() != null && node2.getTag() instanceof LocationItem) {
                            LocationItem node1Item = (LocationItem) node1.getTag();
                            LocationItem node2Item = (LocationItem) node2.getTag();

                            if (zoom <= DaquvConfig.ZOOM_LEVEL_SI) {
                                return node1Item.getAddressSI().equals(node2Item.getAddressSI()) ? -1.0 : 1.0;
                            } else if (zoom <= DaquvConfig.ZOOM_LEVEL_GU) {
                                return node1Item.getAddressGU().equals(node2Item.getAddressGU()) ? -1.0 : 1.0;
                            } else if (zoom < DaquvConfig.ZOOM_LEVEL_DONG) {
                                return node1Item.getAddressDONG().equals(node2Item.getAddressDONG()) ? -1.0 : 1.0;
                            }
                            return 1.0;
                        } else {
                            return 1.0;
                        }
                    }
                })
                .markerManager(new CustomMarkerManager() {
                    @NonNull
                    @Override
                    public Marker createMarker() {
                        Marker marker = super.createMarker();
                        marker.setSubCaptionTextSize(10f);
                        marker.setSubCaptionColor(Color.WHITE);
                        marker.setSubCaptionHaloColor(Color.TRANSPARENT);
                        return marker;
                    }
                })
                .clusterMarkerUpdater(new ClusterMarkerUpdater() {
                    @Override
                    public void updateClusterMarker(@NonNull ClusterMarkerInfo info, @NonNull Marker marker) {
                        int size = info.getSize();
                        if (info.getTag() instanceof LocationItem) {
                            marker.setForceShowIcon(true);
                            marker.setOnClickListener(new DefaultClusterOnClickListener(info));
                            marker.setCaptionTextSize(12);
                            marker.setCaptionColor(Color.WHITE);
                            marker.setCaptionHaloColor(Color.TRANSPARENT);
                            marker.setCaptionAligns(Align.Center);
                            marker.setTag(info);
                            marker.setAnchor(DefaultClusterMarkerUpdater.DEFAULT_CLUSTER_ANCHOR);
                            if ((int)currentZoom <= DaquvConfig.ZOOM_LEVEL_SI) {
                                marker.setWidth(DaquvUtil.convertDPtoPX(requireContext(), 70));
                                marker.setHeight(DaquvUtil.convertDPtoPX(requireContext(), 70));
                                marker.setIcon(OverlayImage.fromResource(R.drawable.bg_cluster_si));
                                marker.setCaptionText(((LocationItem) info.getTag()).getAddressSI() + "\n" + decimalFormat.format(size));
                            } else if ((int)currentZoom <= DaquvConfig.ZOOM_LEVEL_GU) {
                                marker.setWidth(DaquvUtil.convertDPtoPX(requireContext(), 60));
                                marker.setHeight(DaquvUtil.convertDPtoPX(requireContext(), 60));
                                marker.setIcon(OverlayImage.fromResource(R.drawable.bg_cluster_gu));
                                marker.setCaptionText(((LocationItem) info.getTag()).getAddressGU() + "\n" + decimalFormat.format(size));
                            } else if ((int)currentZoom < DaquvConfig.ZOOM_LEVEL_DONG) {
                                marker.setWidth(DaquvUtil.convertDPtoPX(requireContext(), 50));
                                marker.setHeight(DaquvUtil.convertDPtoPX(requireContext(), 50));
                                marker.setIcon(OverlayImage.fromResource(R.drawable.bg_cluster_dong));
                                marker.setCaptionTextSize(10);
                                marker.setCaptionText(((LocationItem) info.getTag()).getAddressDONG() + "\n" + decimalFormat.format(size));
                            }
                            addClusters(marker);
                        }
                    }
                })
                .leafMarkerUpdater(new LeafMarkerUpdater(){
                    @Override
                    public void updateLeafMarker(@NonNull LeafMarkerInfo info, @NonNull Marker marker) {
                        resetClusters();
                        if(info.getTag() != null && info.getTag() instanceof LocationItem) {
                            LocationItem item = (LocationItem) info.getTag();
                            marker.setForceShowIcon(true);
                            marker.setCaptionAligns(Align.Bottom);
                            marker.setCaptionHaloColor(Color.WHITE);
                            marker.setCaptionColor(Color.BLACK);
                            marker.setCaptionTextSize(12);
                            marker.setIconTintColor(Color.TRANSPARENT);
                            marker.setOnClickListener(MapFragment.this);
                            marker.setTag(item); //
                            if(groupCountMap.containsKey(item.getAddressGroup()) && groupCountMap.get(item.getAddressGroup()) > 1) {
                                marker.setZIndex(1);

                                marker.setWidth(DaquvUtil.convertDPtoPX(requireContext(), 24));
                                marker.setHeight(DaquvUtil.convertDPtoPX(requireContext(), 24));
                                marker.setCaptionText(groupCountMap.get(item.getAddressGroup()) + "개" );
                                marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_building));

                            } else {
                                // marker.setTag(item);
                                marker.setWidth(DaquvUtil.convertDPtoPX(requireContext(), 26));
                                marker.setHeight(DaquvUtil.convertDPtoPX(requireContext(), 26));
                                marker.setCaptionText(item.getCompanyNm());

                                if (selectMarker != null && selectMarker.getTag() != null && selectMarker.getTag().equals(item.getCompanyId())) {
                                    if (!TextUtils.isEmpty(item.getIbtrYN()) && "Y".equalsIgnoreCase(item.getIbtrYN())) {
                                        marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_trade_y_s));
                                    } else {
                                        marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_trade_n_s));
                                    }
                                    item.setSelected(true);
                                } else {
                                    if (!TextUtils.isEmpty(item.getIbtrYN()) && "Y".equalsIgnoreCase(item.getIbtrYN())) {
                                        marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_trade_y));
                                    } else {
                                        marker.setIcon(OverlayImage.fromResource(R.drawable.img_map_trade_n));
                                    }
                                    item.setSelected(false);
                                }
                            }
                        }
                    }
                })
                .build();


        if(isMapDataBeforeMapObject) {
            isMapDataBeforeMapObject = false;
            setMapData(locationItemResponse);
        }
        initButtonState();
    }

    private void setDataSheetView() {

        //키보드 올라오면 체크해서 더미뷰 탭 하면 내려가게 만들고
        //기타등등

        dataSheetView = new MapBottomSheetView(requireContext(),
                dataSheetContainer,
                locationItem,
                new MapBottomSheetView.OnStateListener() {
                    @Override
                    public void onStateChanged(int newState) {/*NONE*/}

                    @Override
                    public void onItemClick(String tag, LocationItem data) {
                        if (tag.equals("Container")) {
                            //답변화면 이동
                            try {
                                NLUResultResponse nluResultResponse = new NLUResultResponse();
                                nluResultResponse.setMapDepth(true);
                                nluResultResponse.setUrl("/webview/ibkCrm/v1/company/cusInfoSub");

                                HashMap<String,String> formBody = new HashMap<>();
                                formBody.put("mainCompanyId", "map");
                                formBody.put("companyId", data.getCompanyId());
                                formBody.put("ldinSe", "TCH");
                                nluResultResponse.setFormBuilder(formBody);

                                DaquvSDK.getInstance().getAPI().getResultPage(nluResultResponse);
                                listener.showLoading();
                            } catch (NullPointerException e) {
                                Logger.error(e);
                            }
                        } else if (tag.equals("Filter")) {
                            dataSheetView.collapseView();
                            setFilterView(true);
                        } else if (tag.equals("Navi")) {
                            ArrayList<LocationItem> mark = new ArrayList<>();
                            mark.add(new LocationItem("내 위치", location.getLatitude(), location.getLongitude()));
                            mark.add(data);
                            if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_tmap))) {
                                DaquvUtil.runTMap(requireContext(), mark);
                            } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_kakao))) {
                                DaquvUtil.runKakaoMap(requireContext(), mark);
                            } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_naver))) {
                                DaquvUtil.runNaverMap(requireContext(), mark);
                            }
                        }
                    }

                    @Override
                    public void onNaviClick(ArrayList<LocationItem> datas) {
                        ArrayList<LocationItem> mark = new ArrayList<>();
                        mark.add(new LocationItem("내 위치", location.getLatitude(), location.getLongitude()));
                        mark.addAll(datas);
                        if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(getString(R.string.map_tmap))) {
                            DaquvUtil.runTMap(requireContext(), mark);
                        } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(getString(R.string.map_naver))) {
                            DaquvUtil.runNaverMap(requireContext(), mark);
                        }
                    }
                });
    }


    private void setFilterSheetView() {
        filterView = new FilterView(requireContext());
        filterView.init(filters, new FilterView.OnStateListener() {
            @Override
            public void onItemClick(String tag, MapFilterResponse data) {
                filterDim.setVisibility(View.VISIBLE);
                if (data.getCategory().equals("navi")) {
                    filterSheetView.setType(FilterBottomSheetView.TYPE.NAVI, data);
                } else {
                    if(data.getSearch().equals("Y")) {
                        filterSheetView.setType(FilterBottomSheetView.TYPE.SEARCH, data);
                    } else {
                        filterSheetView.setType(FilterBottomSheetView.TYPE.NONE, data);
                    }
                }
                filterSheetView.expandView();
            }

            @Override
            public void onSearch(ArrayList<MapFilterResponse> current) {
                filters = current;

                listener.showLoading();
                DaquvSDK.getInstance().getAPI().getMapData(companyName ,String.valueOf(location.getLatitude()),
                        String.valueOf(location.getLongitude()),
                        getFilterRadius(), current);
            }

            @Override
            public void onBackPress() {
                setFilterView(false);
            }
        });
        filterDim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filterDim.setVisibility(View.GONE);
                filterSheetView.collapseView();
            }
        });
        filterSheetView = new FilterBottomSheetView(requireActivity(),
                filterSheetContainer,
                new ArrayList<>(),
                new FilterBottomSheetView.OnStateListener() {
                    @Override
                    public void onStateChanged(int newState) {
                        Logger.dev("onStateChanged::" + newState);
                        if(newState == STATE_HIDDEN) {
                            filterDim.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onItemClick(String category, ArrayList<FilterValue> data) {
                        filterView.update(category, data);
                    }
                });
    }

    private void setFilterView(boolean show) {

        if(filterView.getAnimation() != null && !filterView.getAnimation().hasEnded()) {
            return;
        }
        if(show) {
            filterView.initFlag();
            filterContainer.addView(filterView);
            Animation slideInRightAnimation = AnimationUtils.loadAnimation(getContext(), R.anim.slide_in_right);
            filterView.startAnimation(slideInRightAnimation);
        } else {
            if(filterContainer.getChildCount() > 0) {
                Animation slideOutRightAnimation = AnimationUtils.loadAnimation(getContext(), R.anim.slide_out_right);
                slideOutRightAnimation.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {/*NONE*/}

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        filterContainer.removeAllViews();
                        filterView.undoClear();
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {/*NONE*/}
                });
                filterView.startAnimation(slideOutRightAnimation);
            }
        }
    }

    private String getFilterRadius() {
        String radius = "";
        for (MapFilterResponse filter : filters) {
            if("radius".equals(filter.getCategory())) {
                radius = filter.getSelected().get(0).getName();
                DaquvConfig.defaultRadius = radius;
            }
        }
        return radius;
    }

    private void initButtonState() {
        btnMy.setBackgroundResource(R.drawable.rounded_rect_with_stroke_map);
        btnMy.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
        btnCompany.setBackgroundResource(R.drawable.rounded_rect_with_stroke_map);
        btnCompany.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
        btnAddress.setBackgroundResource(R.drawable.rounded_rect_with_stroke_map);
        btnAddress.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
        if(!TextUtils.isEmpty(companyName)) {
            if(companyName.equals("내 위치")) {
                btnMy.setBackgroundResource(R.drawable.rounded_rect_with_fill_map);
                btnMy.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_white));
            } else if(companyName.equals("주소")) {
                btnAddress.setBackgroundResource(R.drawable.rounded_rect_with_fill_map);
                btnAddress.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_white));
            } else {
                btnCompany.setBackgroundResource(R.drawable.rounded_rect_with_fill_map);
                btnCompany.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_white));
            }
        }
    }

    public void clearFilter() {
        if(DaquvConfig.mapFilterList != null &&
                DaquvConfig.mapFilterList.getFilter() != null &&
                DaquvConfig.mapFilterList.getFilter().size() > 0) {
            for(MapFilterResponse data : DaquvConfig.mapFilterList.getFilter()) {
                data.getSelected().clear();
                DaquvUtil.initFilterValue(data);
            }
            filters = DaquvConfig.mapFilterList.getFilter();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        clearFilter();
        heightProvider.destory();
        onBackPressedCallback.remove();
        locationItem.clear();
        markers.clear();
        clusterer.clear();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
        DaquvSDK.getInstance().stopTTS();
    }

}
