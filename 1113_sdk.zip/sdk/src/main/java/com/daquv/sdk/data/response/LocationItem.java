package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

public class LocationItem {

    @SerializedName("company_id")
    private String companyId;

    @SerializedName("com_nm")
    private String companyNm;

    @SerializedName("lat")
    private double latitude;

    @SerializedName("lon")
    private double longitude;

    @SerializedName("dist")
    private int distance;

    @SerializedName("ceo_nm")
    private String ceoNm;

    @SerializedName("addr")
    private String address;

    @SerializedName("ibtr_yn")
    private String ibtrYN;

    @SerializedName("eprt")
    private String eprtClarDtcvNm;

    @SerializedName("iprt")
    private String iprtClarDtcvNm;

    @SerializedName("ibk")
    private String ibkKcisEninBal;

    @SerializedName("ano")
    private String anoKcisEninBal;

    @SerializedName("main_brcd")
    private String mainBrcd;

    @SerializedName("si")
    private String addressSI;

    @SerializedName("gu")
    private String addressGU;

    @SerializedName("dong")
    private String addressDONG;

    @SerializedName("group")
    private String addressGroup;

    private boolean selected;

    private int originPosition;

    public LocationItem() {
    }

    public LocationItem(String companyNm, double latitude , double longitude) {
        this.companyNm = companyNm;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getDistance() {
        return distance;
    }

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    public String getCeoNm() {
        return ceoNm;
    }

    public void setCeoNm(String ceoNm) {
        this.ceoNm = ceoNm;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getIbtrYN() {
        return ibtrYN;
    }

    public void setIbtrYN(String ibtrYN) {
        this.ibtrYN = ibtrYN;
    }

    public String getEprtClarDtcvNm() {
        return eprtClarDtcvNm;
    }

    public void setEprtClarDtcvNm(String eprtClarDtcvNm) {
        this.eprtClarDtcvNm = eprtClarDtcvNm;
    }

    public String getIprtClarDtcvNm() {
        return iprtClarDtcvNm;
    }

    public void setIprtClarDtcvNm(String iprtClarDtcvNm) {
        this.iprtClarDtcvNm = iprtClarDtcvNm;
    }

    public String getIbkKcisEninBal() {
        return ibkKcisEninBal;
    }

    public void setIbkKcisEninBal(String ibkKcisEninBal) {
        this.ibkKcisEninBal = ibkKcisEninBal;
    }

    public String getAnoKcisEninBal() {
        return anoKcisEninBal;
    }

    public void setAnoKcisEninBal(String anoKcisEninBal) {
        this.anoKcisEninBal = anoKcisEninBal;
    }

    public String getMainBrcd() {
        return mainBrcd;
    }

    public void setMainBrcd(String mainBrcd) {
        this.mainBrcd = mainBrcd;
    }

    public int getOriginPosition() {
        return originPosition;
    }

    public void setOriginPosition(int originPosition) {
        this.originPosition = originPosition;
    }

    public String getAddressSI() {
        return addressSI;
    }

    public void setAddressSI(String addressSI) {
        this.addressSI = addressSI;
    }

    public String getAddressGU() {
        return addressGU;
    }

    public void setAddressGU(String addressGU) {
        this.addressGU = addressGU;
    }

    public String getAddressDONG() {
        return addressDONG;
    }

    public void setAddressDONG(String addressDONG) {
        this.addressDONG = addressDONG;
    }

    public String getAddressGroup() {
        return addressGroup;
    }

    public void setAddressGroup(String addressGroup) {
        this.addressGroup = addressGroup;
    }
}
