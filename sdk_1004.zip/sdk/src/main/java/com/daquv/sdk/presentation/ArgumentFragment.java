package com.daquv.sdk.presentation;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.ui.component.BasicButtonView;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.secure.PreventRecordUtils;
import com.daquv.sdk.webview.ComWebView;

public class ArgumentFragment extends Fragment {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    DaquvEngine.Callback engineCallback;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        PreventRecordUtils.getInstance().setSecureFlag(requireActivity());
        return inflater.inflate(R.layout.fragment_daquv_argument, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageView imageView = view.findViewById(R.id.argument_close);
        CheckBox argumentCheck = view.findViewById(R.id.argument_check);
        CheckBox policyCheck = view.findViewById(R.id.policy_check);
        BasicButtonView btnConfirm = view.findViewById(R.id.argument_confirm);
        LinearLayoutCompat argumentContainer = view.findViewById(R.id.argument_container);
        LinearLayoutCompat policyContainer = view.findViewById(R.id.policy_container);
        ImageView argumentContents = view.findViewById(R.id.argument_contents);
        ImageView policyContents = view.findViewById(R.id.policy_contents);
        ((TextView) view.findViewById(R.id.argument_msg)).setText(getString(R.string.dqv_argument_msg) + " "+ getString(R.string.dqv_essential));
        ((TextView) view.findViewById(R.id.policy_msg)).setText(getString(R.string.dqv_policy_msg) + " " +getString(R.string.dqv_essential));

        argumentContainer.setOnClickListener(view1 ->
                argumentCheck.setChecked(!argumentCheck.isChecked())
        );
        policyContainer.setOnClickListener(view12 ->
                policyCheck.setChecked(!policyCheck.isChecked())
        );
        argumentCheck.setOnCheckedChangeListener((compoundButton, b) -> {btnConfirm.setEnabled(checkAll(argumentCheck , policyCheck));});
        policyCheck.setOnCheckedChangeListener((compoundButton, b) -> btnConfirm.setEnabled(checkAll(argumentCheck , policyCheck)));

        argumentContents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                listener.addHTMLView(getString(R.string.dqv_argument_msg),
                        "https://daquv.com/policy/service",
                        new HTMLFragment.Listener() {
                            @Override
                            public void onConfirm() {
                                argumentCheck.setChecked(true);
                            }
                        });
            }
        });
        policyContents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.addHTMLView(getString(R.string.dqv_policy_msg),
                        "https://daquv.com/policy/privacy",
                        new HTMLFragment.Listener() {
                            @Override
                            public void onConfirm() {
                                policyCheck.setChecked(true);
                            }
                        });
            }
        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onBackPress();
            }
        });
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DaquvSDK.getInstance().getAPI().getMainPage(DaquvUtil.getUrl("/webview/ibkCrm/v1/company/main"));
                SharedPref.getInstance().put(DaquvConfig.Preference.KEY_ARGUMENT_POLICY_AGREE, true);
            }
        });
    }

    private boolean checkAll(CheckBox checkBox1, CheckBox checkBox2) {
        return checkBox1.isChecked() && checkBox2.isChecked();
    }


    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);


            }
        };
        DaquvSDK.getInstance().addCallBack(engineCallback);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        onBackPressedCallback.remove();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
    }
}
