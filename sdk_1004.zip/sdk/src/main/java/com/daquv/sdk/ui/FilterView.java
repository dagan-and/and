package com.daquv.sdk.ui;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.R;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.ui.adapter.FilterAdapter;
import com.daquv.sdk.utils.SharedPref;

import java.util.ArrayList;

public class FilterView extends FrameLayout {

    private ImageView filterLine;
    private RecyclerView recyclerView;
    private ImageView btnPre;
    private FilterAdapter adapter;

    public FilterView(@NonNull Context context) {
        super(context);
        View view = LayoutInflater.from(context).inflate(R.layout.view_filter, null);
        this.recyclerView = view.findViewById(R.id.filter_recyclerview);
        this.btnPre = view.findViewById(R.id.btn_pre);
        this.filterLine = view.findViewById(R.id.filter_line);
        addView(view);
    }

    public void init(ArrayList<AppConfig.Filter> listItem, OnStateListener listener) {

        btnPre.setOnClickListener(view -> {
            if (listener != null) {
                listener.onBackPress();
            }
        });
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstVisibleItemPosition() == 0
                        && ((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition() == 0) {
                    filterLine.setVisibility(View.INVISIBLE);
                } else {
                    filterLine.setVisibility(View.VISIBLE);
                }
            }
        });

        AppConfig.Filter navi = new AppConfig.Filter();
        navi.category = "navi";
        navi.search = "N";
        navi.type = "select";
        navi.name = "길찾기/경로 설정";
        if (TextUtils.isEmpty(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI))) {
            SharedPref.getInstance().put(DaquvConfig.Preference.KEY_NAVI, DaquvConfig.appConfig.mapInfo.navi);
        }
        if (TextUtils.isEmpty(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI))) {
            SharedPref.getInstance().put(DaquvConfig.Preference.KEY_MULTI_NAVI, DaquvConfig.appConfig.mapInfo.multiNavi);
        }
        ArrayList<String> naviValue = new ArrayList<>();
        naviValue.add(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI) + "/" +
                SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI));
        navi.value = naviValue;
        listItem.add(0, navi);

        for (AppConfig.Filter data : listItem) {
            data.selected.add(data.value.get(0));
        }

        adapter = new FilterAdapter(listItem);
        adapter.setOnItemClickListener((v, data) -> {
            if (listener != null) {
                listener.onItemClick(v.getTag().toString(), data);
            }
        });
        recyclerView.setAdapter(adapter);
    }

    public void update(String category, ArrayList<String> data) {
        ArrayList<AppConfig.Filter> filters = adapter.getFilters();

        for (AppConfig.Filter items : filters) {
            if (items.category.equals(category)) {
                items.selected = data;
            }
        }
        adapter.setFilters(filters);
    }

    public interface OnStateListener {
        void onItemClick(String tag, AppConfig.Filter data);

        void onBackPress();
    }
}
