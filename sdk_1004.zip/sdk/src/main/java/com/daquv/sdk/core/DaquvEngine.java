package com.daquv.sdk.core;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.STTReplaceResponse;
import com.daquv.sdk.stt.inside.OnInsideListener;
import com.daquv.sdk.stt.inside.RegisterInsideSDK;
import com.daquv.sdk.stt.inside.conf.InsideConst;
import com.daquv.sdk.stt.itl.ITLModel;
import com.daquv.sdk.stt.itl.api.ItlController;
import com.daquv.sdk.stt.itl.api.ItlSocketIoClient;
import com.daquv.sdk.utils.Logger;
import com.kt.gigagenie.inside.network.grpc.model.Payload;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;


public class DaquvEngine {
    private ArrayList<Callback> mCallback;
    private final Context mContext;
    private boolean isRunning = false;

    public static class Callback {
        public void onResult(int code, Object result) {
            /**
             * 엔진 응답 CallBack
             * - API 동작
             * - STT 동작
             */
        }
    }


    public DaquvEngine(Context context) {
        this.mContext = context;
    }

    public boolean isRunning() {
        return isRunning;
    }

    public void initEngine() {
        if (DaquvConfig.engine == DaquvConfig.ENGINE.ITL) {
            ITLModel.getInstance().launchITLEngine(mContext, new ItlController.OnResultListener() {
                @Override
                public void onResult(Message message) {
                    switch (message.what) {
                        case ItlSocketIoClient.ALERT:
                            onAPIResult(DaquvConfig.CODE.ENGINE_ERROR_VOICE, new ErrorData(ItlSocketIoClient.ALERT, (String) message.obj));
                            stopEngine();
                            break;
                        case ItlSocketIoClient.TIMEOUT:
                            onAPIResult(DaquvConfig.CODE.ENGINE_ERROR_VOICE, new ErrorData(ItlSocketIoClient.TIMEOUT, (String) message.obj));
                            stopEngine();
                            break;
                        case ItlSocketIoClient.READY:
                            onAPIResult(DaquvConfig.CODE.ENGINE_INIT, null);
                            break;
                        case ItlSocketIoClient.JSON_RESULT:
                            String json = (String) message.obj;
                            String result = null;
                            String status = null;
                            try {
                                JSONObject jObj = new JSONObject(json);
                                result = jObj.getString("sentence");
                                status = jObj.getString("status");
                            } catch (JSONException e) {
                                Logger.error(e);
                            }
                            if (TextUtils.isEmpty(result) || TextUtils.isEmpty(status)) {
                                onAPIResult(DaquvConfig.CODE.ENGINE_NONE_DATA, null);
                                stopEngine();
                            } else if (ITLModel.STATUS.PARTIAL.name().equals(status)) {
                                onAPIResult(DaquvConfig.CODE.ENGINE_RUNNING_DATA, result);
                            } else if (ITLModel.STATUS.FINAL.name().equals(status)) {
                                //문구 치환
                                if(DaquvConfig.replaces.size() > 0) {
                                    for(STTReplaceResponse.STTReplace replace : DaquvConfig.replaces) {
                                        result = result.replace(replace.getBefore(), replace.getAfter());
                                    }
                                }
                                onAPIResult(DaquvConfig.CODE.ENGINE_FINAL_DATA, result);
                                stopEngine();
                            }
                            break;
                        default:
                            Logger.dev(String.valueOf(message.obj));
                            break;
                    }
                }
            });
        } else if (DaquvConfig.engine == DaquvConfig.ENGINE.INSIDE) {
            RegisterInsideSDK.getInstance().init(mContext, new OnInsideListener() {
                @Override
                public void onChangeStatus(InsideConst.Status status) {
                    switch (status) {
                        case INIT:
                            resetFailCount();
                            onAPIResult(DaquvConfig.CODE.ENGINE_INIT, null);
                            break;
                        case START_LISTEN:
                            onAPIResult(DaquvConfig.CODE.ENGINE_START_VOICE, null);
                            break;
                        case STOP_LISTEN:
                        case STOP:
                            break;
                        default:
                            break;
                    }
                }

                @Override
                public void onVoiceResult(String result) {
                    if (TextUtils.isEmpty(result)) {
                        onAPIResult(DaquvConfig.CODE.ENGINE_NONE_DATA, null);
                    } else {
                        onAPIResult(DaquvConfig.CODE.ENGINE_FINAL_DATA, result);
                    }

                }

                @Override
                public void onError(int errCode, String errMsg) {
                    //agent_onEvent 에서 JSON 파싱하는 부분 에러(아~~~~ 와 같이 비정상적인 발화 시)
                    if (errCode == InsideConst.Error.CODE_FAIL_PARSING) {
                        return;
                    }
                    // NLU 를 쓰기때문에 해당 에러 리턴은 무시
                    if (errCode == InsideConst.Error.CODE_FAIL_RECOG) {
                        return;
                    }
                    //5초이내 발화하지 않는 경우
                    if (errCode == 901) {
                        onAPIResult(DaquvConfig.CODE.ENGINE_NONE_DATA, null);
                        onChangeStatus(InsideConst.Status.STOP);
                        return;
                    }
                    onAPIResult(DaquvConfig.CODE.ENGINE_ERROR_VOICE, new ErrorData(errCode, errMsg));
                    onChangeStatus(InsideConst.Status.STOP);
                }

                @Override
                public void onCommand(Payload payload, String intent, JSONObject appInfo, String sysMsg) {
                    /*
                     * NLU 모델 사용시 작성
                     */
                }

                @Override
                public void onVoice(short[] data, int size) {
                    /*
                     * 음성 데이터 사용시 작성
                     */
                }
            });
        }
    }

    public void stopEngine() {
        isRunning = false;
        onAPIResult(DaquvConfig.CODE.ENGINE_STOP_VOICE, null);

        if (DaquvConfig.engine == DaquvConfig.ENGINE.ITL) {
            ITLModel.getInstance().stopController();
        } else if (DaquvConfig.engine == DaquvConfig.ENGINE.INSIDE) {
            RegisterInsideSDK.getInstance().voiceStop();
        }
    }

    public void startEngine() {
        if(isRunning) {
            return;
        }
        DaquvSDK.getInstance().stopTTS();
        onAPIResult(DaquvConfig.CODE.ENGINE_START_VOICE, null);
        isRunning = true;

        if (DaquvConfig.engine == DaquvConfig.ENGINE.ITL) {
            ITLModel.getInstance().startController();
        } else if (DaquvConfig.engine == DaquvConfig.ENGINE.INSIDE) {
            RegisterInsideSDK.getInstance().voiceStart();
        }
    }


    public void addCallBack(Callback callback) {
        if (mCallback == null || mCallback.isEmpty()) {
            mCallback = new ArrayList<>();
        }
        mCallback.add(callback);
    }

    public void removeCallBack(Callback callback) {
        if (mCallback == null || mCallback.isEmpty()) {
            return;
        }
        mCallback.remove(callback);
    }

    public void clearCallBack() {
        if (mCallback == null || mCallback.isEmpty()) {
            return;
        }
        mCallback.clear();
    }

    public void onAPIResult(int code, Object result) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    if(mCallback != null && mCallback.size() > 0) {
                        Iterator<Callback> iterator = mCallback.iterator();
                        while (iterator.hasNext()) {
                            Callback callback = iterator.next();
                            callback.onResult(code, result);
                        }
                    }
                } catch (Exception e) {
                    Logger.error(e);
                }
            }
        });
    }


    /**
     * isContinue 발화 실패 가능 여부
     * resetFailCount 실패 카운트 초기화
     * addFailCount 실패 카운트 증가
     * <p>
     * 음성인식 -> 실패 -> 음성인식 을 한 사이클로 봐서 반복할 수 있는 횟수
     */
    private final static int MAX_FAIL_COUNT = 3;
    private int failCount = 0;

    public boolean isMaxFailCount() {
        if(DaquvConfig.useNLUFailCount) {
            return failCount >= MAX_FAIL_COUNT;
        } else {
            return false;
        }
    }

    public void resetFailCount() {
        failCount = 0;
    }

    public void addFailCount() {
        failCount++;
    }


}