package com.daquv.sdk.webview.action;

import android.os.Parcel;
import android.os.Parcelable;

import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.webview.constant.WebConst;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Web -> App 로 전달한 WebAction 정보
 **/
public class WebActionInfo implements Parcelable {

    /** Web -> App 로 전달한 WebAction 정보 */
    private final String mWebActionJson;

    /**
     * 생성자
     * @param webActionJson Web -> App 로 전달한 WebAction 정보
     * @throws JSONException
     */
    public WebActionInfo(JSONObject webActionJson) throws JSONException {
        Logger.info("webActionJson :: " + webActionJson);
        mWebActionJson = webActionJson.toString();
    }

    /**
     * 생성자
     * @param actionCode Action Code
     * @param actionUUID Action UUID
     * @throws JSONException
     */
    public WebActionInfo(String actionCode, String actionUUID) throws JSONException {
        Logger.info(" actionCode :: " + actionCode);
        Logger.info("actionUUID :: " + actionUUID);

        JSONObject jobjWebAction = new JSONObject();
        jobjWebAction.put(WebConst.WebAction.KEY_ACTION_CODE, actionCode);
        jobjWebAction.put(WebConst.WebAction.KEY_ACTION_UUID, actionUUID);
        mWebActionJson = jobjWebAction.toString();
    }

    /**
     * 생성자
     * @param actionCode Action Code
     * @param actionUUID Action UUID
     * @param actionData Action Data
     * @throws JSONException
     */
    public WebActionInfo(String actionCode, String actionUUID, JSONObject actionData) throws JSONException {
        Logger.info("actionCode :: " + actionCode);
        Logger.info("actionUUID :: " + actionUUID);
        Logger.info("actionUUID :: " + actionData);

        JSONObject jobjWebAction = new JSONObject();
        jobjWebAction.put(WebConst.WebAction.KEY_ACTION_CODE, actionCode);
        jobjWebAction.put(WebConst.WebAction.KEY_ACTION_UUID, actionUUID);
        jobjWebAction.put(WebConst.WebAction.KEY_ACTION_DATA, actionData);
        mWebActionJson = jobjWebAction.toString();
    }


    protected WebActionInfo(Parcel in) {
        mWebActionJson = in.readString();
    }

    public static final Creator<WebActionInfo> CREATOR = new Creator<WebActionInfo>() {
        @Override
        public WebActionInfo createFromParcel(Parcel in) {
            return new WebActionInfo(in);
        }

        @Override
        public WebActionInfo[] newArray(int size) {
            return new WebActionInfo[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(mWebActionJson);
    }

    /**
     * Web -> App 로 전달한 WebAction 정보 반환
     * @return Web -> App 로 전달한 WebAction 정보
     */
    public JSONObject getWebActionJson() {
        try {
            return new JSONObject(mWebActionJson);
        } catch (JSONException e){
            Logger.error(e);
        }

        return new JSONObject();
    }

    /**
     * Action Code 반환
     * @return Action Code (_action_code)
     */
    public String getActionCode()  {
        return getWebActionJson().optString(WebConst.WebAction.KEY_ACTION_CODE, "");
    }

    /**
     * Action UUID 반환
     * @return Action UUID (_action_uuid)
     */
    public String getActionUUID() {
        return getWebActionJson().optString(WebConst.WebAction.KEY_ACTION_UUID, "");
    }

    /**
     * Action Data 반환
     * @return Action Data (_action_data)
     */
    public JSONObject getActionData() {
        JSONObject jobjData = getWebActionJson().optJSONObject(WebConst.WebAction.KEY_ACTION_DATA);
        if (jobjData == null)
            return new JSONObject();
        else
            return jobjData;
    }


}
