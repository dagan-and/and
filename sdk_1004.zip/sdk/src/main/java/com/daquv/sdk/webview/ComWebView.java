package com.daquv.sdk.webview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.daquv.sdk.BuildConfig;
import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.network.JSONHelper;
import com.daquv.sdk.webview.action.DefaultAction;
import com.daquv.sdk.webview.action.WebActionBridge;
import com.daquv.sdk.webview.action.WebActionInfo;
import com.daquv.sdk.webview.client.ComWebChromeClient;
import com.daquv.sdk.webview.client.ComWebClient;
import com.daquv.sdk.webview.constant.WebConst;

import org.json.JSONObject;

import java.util.Map;
import java.util.Set;

public class ComWebView extends WebView {


    OnWebActionListener onWebActionListener;
    String blurCSS;

    public ComWebView(Context context) {
        super(context);
        initialize();
    }

    public ComWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    public ComWebView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize();
    }

    public interface OnWebActionListener {
        void onShortCut(String utterance);
        void onClose();
        void onCapture();
    }
    

    @SuppressLint("SetJavaScriptEnabled")
    private void initialize() {
        setWebViewClient(new ComWebClient(this));
        setWebChromeClient(new ComWebChromeClient(this));

        setWebContentsDebuggingEnabled(DaquvConfig.isDebug);
        setLayerType(LAYER_TYPE_HARDWARE, null);


        WebSettings webSettings = getSettings();
        webSettings.setJavaScriptEnabled(true);

        setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webSettings.setSupportZoom(false);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setTextZoom(100);

        // UserAgent 설정
        String userAgent = webSettings.getUserAgentString();
        Logger.dev("Default userAgent :: " + userAgent);
        try {
            Map<String, Object> deviceInfo = JSONHelper.toHashMap(DaquvUtil.getDeviceInfo(getContext()));
            Set<String> keySet = deviceInfo.keySet();
            for (String key : keySet) {
                userAgent += ";" + key + "=" + deviceInfo.get(key);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Logger.dev("Custom userAgent :: " + userAgent);
        webSettings.setUserAgentString(userAgent);

        // net::ERR_CACHE_MISS 이슈 수정을 위한 캐시 모드 설정
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        initBridge(new WebActionBridge());

    }

    public void addListener(OnWebActionListener listener) {
        this.onWebActionListener = listener;
    }

    public void loadMainPage() {
        loadDataWithBaseURL(DaquvSDK.getInstance().getAPI().getMainUrl(),
                DaquvSDK.getInstance().getAPI().getMainData(),
                "text/html", "UTF-8", null);
    }

    public void loadDataPage() {
        loadDataWithBaseURL(DaquvSDK.getInstance().getAPI().getResultUrl(),
                DaquvSDK.getInstance().getAPI().getResultData(),
                "text/html", "UTF-8", null);
    }

    public void onPageStarted() {
        Logger.dev("onPageStarted");
    }

    public void onPageFinished() {
        Logger.dev("onPageFinished");
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        onDestroy();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
    }



    /**
     * WebView Destroy
     */
    public void onDestroy() {
        Logger.info("destroyWebView () call");
        clearCache(true);
        clearHistory();
        removeJavascriptInterface(WebConst.WebAction.HUB_INTERFACE_NAME);
        removeJavascriptInterface(WebConst.WebAction.SDK_INTERFACE_NAME);
        stopLoading();
        removeAllViews();
        destroy();
    }

    public void onWebViewError(ConsoleMessage consoleMessage) {
        // 콘솔 로그를 크래시 리포트에 저장
        String[] webCallStack = {consoleMessage.sourceId(), String.valueOf(consoleMessage.lineNumber())};
        String[] callStack = new String[webCallStack.length];
        System.arraycopy(webCallStack, 0, callStack, 0, webCallStack.length);
        if (consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.WARNING ||
                consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
            Logger.web(consoleMessage);
        }
    }

    public void initBridge(WebActionBridge bridge) {
        addJavascriptInterface(bridge, WebConst.WebAction.HUB_INTERFACE_NAME);
        addJavascriptInterface(bridge, WebConst.WebAction.SDK_INTERFACE_NAME);
        bridge.loadAction(new DefaultAction(bridge, new DefaultAction.WebActionCallback() {
            @Override
            public void event(WebActionInfo webActionInfo) {
                String actionCode = webActionInfo.getActionCode();
                if ("webResultTTS".equals(actionCode)) {
                    if (SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_USE_TTS, true)) {
                        JSONObject actionDataJson = webActionInfo.getActionData();
                        String data = actionDataJson.optString("_data");
                        String callback = actionDataJson.optString("_call_back");
                        if(!TextUtils.isEmpty(data)) {
                            DaquvSDK.getInstance().getAPI().getTTSBinary(data, callback, DaquvConfig.CODE.API_NLU_SUCCESS);
                        }
                    }
                }

                if ("startSTT".equals(actionCode)) {
                    DaquvSDK.getInstance().getEngine().startEngine();
                }

                if ("stopSTT".equals(actionCode)) {
                    DaquvSDK.getInstance().getEngine().stopEngine();
                }

                // 질의로 바로 이동하기
                if ("stttext".equals(actionCode)) {
                    JSONObject actionDataJson = webActionInfo.getActionData();
                    String data = actionDataJson.optString("stt");
                    if(onWebActionListener != null) {
                        onWebActionListener.onShortCut(data);
                    }
                }

                // 화면 종료하기
                if ("closeWindow".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        onWebActionListener.onClose();
                    }
                }
            }
        }));
    }

    public void onBackPress() {
        if(DaquvConfig.service == DaquvConfig.SERVICE.POSCO) {
            evaluateJavascript("javascript:getPopupState()", new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String s) {
                    if(s.equals("2")) {
                        loadUrl("javascript:closePopup2()");
                    } else if(s.equals("3")) {
                        loadUrl("javascript:closePopup3()");
                    } else if(s.equals("4")) {
                        loadUrl("javascript:closeOption2()");
                    } else {
                        if(onWebActionListener != null) {
                            onWebActionListener.onClose();
                        }
                    }
                }
            });
        } else {
            evaluateJavascript("javascript:getDepthState()", new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String s) {
                    if(s.equals("1")) {
                        if(onWebActionListener != null) {
                            onWebActionListener.onClose();
                        }
                    } else if(s.equals("2")) {
                        loadUrl("javascript:close2Depth()");
                    } else if(s.equals("3")) {
                        loadUrl("javascript:close3Depth()");
                    } else {
                        if(onWebActionListener != null) {
                            onWebActionListener.onClose();
                        }
                    }
                }
            });
        }

        /* 뒤로가기 가능한지 체크
        if(canGoBack()) {
            loadUrl("javascript:history.back()");
        } else {
            activity.finish();
        }
        */
    }
}