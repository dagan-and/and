package com.daquv.sdk.presentation;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.R;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.HeightProvider;
import com.daquv.sdk.utils.Logger;

public class MeetingFragment extends Fragment  {


    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    private View rootView;
    private View keyboardPaddingBottom;
    private HeightProvider heightProvider;
    private EditText editContents;
    private ScrollView scrollView;
    private TextView titleContents;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_meeting , container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rootView = view;
        keyboardPaddingBottom = view.findViewById(R.id.keyboard_padding_bottom);
        editContents = view.findViewById(R.id.edit_contents);
        scrollView = view.findViewById(R.id.scrollview);
        titleContents = view.findViewById(R.id.title_contents);
    }


    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);


        heightProvider = new HeightProvider(requireActivity());
        heightProvider.init();
        heightProvider.setHeightListener(new HeightProvider.HeightListener() {
            @Override
            public void onHeightChanged(int height) {
                try {
                    //requireContext 가 null 인 경우 예외 처리
                    if (rootView.getMeasuredHeight() > 0 && height > 0) {
                        setViewHeight(keyboardPaddingBottom, height + DaquvUtil.convertDPtoPX(requireContext(), 20));
                    } else {
                        setViewHeight(keyboardPaddingBottom, DaquvUtil.convertDPtoPX(requireContext(), 150));
                    }
                    if (height > 0 ) {
                        if(editContents.hasFocus()) {
                            scrollView.postOnAnimationDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    scrollView.smoothScrollTo(0, computeDistanceToView(scrollView , titleContents));
                                }
                            },150);
                        }
                    }
                } catch (Exception e) {
                    Logger.error(e);
                }
            }
        });
    }

    public void setViewHeight(View view, int height) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = height;
        view.setLayoutParams(params);
    }

    public int computeDistanceToView(ScrollView scrollView, View view) {
        return Math.abs(calculateRectOnScreen(scrollView).top - (scrollView.getScrollY() + calculateRectOnScreen(view).top));
    }

    public Rect calculateRectOnScreen(View view) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        return new Rect(
                location[0],
                location[1],
                location[0] + view.getMeasuredWidth(),
                location[1] + view.getMeasuredHeight()
        );
    }

    private void popBackStack() {
        //소프트 키보드 내리기
//        InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
//        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);

        listener.onBackPress();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        heightProvider.destory();
        onBackPressedCallback.remove();
    }
}
