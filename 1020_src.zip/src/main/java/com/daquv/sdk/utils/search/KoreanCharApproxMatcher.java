
package com.daquv.sdk.utils.search;

public class KoreanCharApproxMatcher {
    private KoreanCharApproxMatcher() {} // Can never be instantiated.

    /**
     * 주어진 두 문자를 음절 근사 매칭으로 비교한다.
     *
     * 비교할 첫번째 문자는 두번째 문자보다 항상 자모 개수가 같거나 많아야 한다.
     * 예를 들어 {@code isMatch('한', '하')}는 성공하지만 {@code isMatch('하', '한')}은
     * 실패한다.
     *
     * @param t 비교할 첫번째 문자.
     * @param p 비교할 두번째 문자.
     * @return 매칭이 성공하면 {@code true}, 실패하면 {@code false}.
     */
    public static boolean isMatch(char t, char p) {
        return decompose(t).startsWith(decompose(p));
    }

    private static String decompose(char c) {
        if (KoreanChar.isSyllable(c))
            return String.join("", KoreanChar.decomposeCompat(c));
        else if (KoreanChar.isCompatChoseong(c))
            return KoreanChar.splitJamo(c);
        else if (KoreanChar.isChoseong(c))
            return KoreanChar.splitJamo(KoreanChar.choseongToCompatChoseong(c));
        else
            return String.valueOf(c);
    }
}
