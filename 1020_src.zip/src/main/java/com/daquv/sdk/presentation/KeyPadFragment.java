package com.daquv.sdk.presentation;

import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.ui.BackPressEditText;
import com.daquv.sdk.utils.HeightProvider;
import com.daquv.sdk.utils.Logger;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

public class KeyPadFragment extends Fragment implements View.OnClickListener {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;

    private View rootView;
    private View keyboardPaddingBottom;
    private BackPressEditText editText;
    private HeightProvider heightProvider;
    private BottomSheetBehavior<View> bottomSheetView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_keypad , container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        DaquvSDK.getInstance().getEngine().cleanState();
        rootView = view;
        editText = view.findViewById(R.id.keypadEditText);
        keyboardPaddingBottom = view.findViewById(R.id.keyboard_padding_bottom);

        bottomSheetView = BottomSheetBehavior.from(view.findViewById(R.id.bottom_sheet));
        bottomSheetView.setState(BottomSheetBehavior.STATE_EXPANDED);
        bottomSheetView.setSkipCollapsed(true);
        bottomSheetView.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                if(newState == BottomSheetBehavior.STATE_HIDDEN) {
                    popBackStack();
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                //onSlide
            }
        });

        ImageView keyboardClose = view.findViewById(R.id.keyboardClose);
        keyboardClose.setOnClickListener(this);
        ImageView keyboardButton = view.findViewById(R.id.keyboardButton);
        keyboardButton.setOnClickListener(this);

        editText.setOnBackPressListener(new BackPressEditText.OnBackPressListener() {
            @Override
            public void onBackPress(int keyCode) {
                bottomSheetView.setState(BottomSheetBehavior.STATE_HIDDEN);
            }
        });
        editText.setOnEditorActionListener(new EditText.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                    if (!TextUtils.isEmpty(editText.getText())) {
                        keyboardButton.callOnClick();
                    }
                }
                return true ;
            }
        });
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //NONE
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence != null && charSequence.length() > 0) {
                    if(charSequence.toString().contains("\n")) {
                        keyboardButton.callOnClick();
                    }
                    keyboardButton.setImageResource(R.drawable.btn_keypad_send);
                } else {
                    keyboardButton.setImageResource(R.drawable.btn_keypad_mic);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //NONE
            }
        });

        //소프트 키보드 열기
        editText.post(new Runnable() {
            @Override
            public void run() {
                editText.requestFocus();
                InputMethodManager inputMethodManager = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                inputMethodManager.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
            }
        });
    }


    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.keyboardClose) {
            popBackStack();
        } else if(view.getId() == R.id.keyboardButton) {
            if(!TextUtils.isEmpty(editText.getText())) {
                popBackStack();
                listener.showLoading();
                DaquvSDK.getInstance().getAPI().getNLUData(editText.getText().toString());
            } else {
                popBackStack();
                listener.startSTT();
            }
        }
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress(null);
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        heightProvider = new HeightProvider(requireActivity());
        heightProvider.init();
        heightProvider.setHeightListener(new HeightProvider.HeightListener() {
            @Override
            public void onHeightChanged(int height) {
                try {
                    //requireContext 가 null 인 경우 예외 처리
                    if (rootView.getMeasuredHeight() > 0 && height > 0) {
                       setViewHeight(keyboardPaddingBottom, height);
                    } else {
                        setViewHeight(keyboardPaddingBottom, 0);
                    }
                    if (height > 0 ) {
                        keyboardPaddingBottom.setVisibility(View.VISIBLE);
                    } else if (height == 0) {
                        keyboardPaddingBottom.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    Logger.error(e);
                }
            }
        });
    }

    public void setViewHeight(View view, int height) {
        ViewGroup.LayoutParams params = view.getLayoutParams();
        params.height = height;
        view.setLayoutParams(params);
    }

    private void popBackStack() {
        //소프트 키보드 내리기
        InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);

        listener.onBackPress(null);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        heightProvider.destory();
        onBackPressedCallback.remove();
    }

}
