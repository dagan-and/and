package com.example.sampleapplication;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.pm.ShortcutInfoCompat;
import androidx.core.content.pm.ShortcutManagerCompat;
import androidx.core.graphics.drawable.IconCompat;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.daquv.sdk.presentation.MainFragment;
import com.daquv.sdk.DaquvConfig;

import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.utils.DaquvUtil;
import com.example.sampleapplication.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding = null;
    private static final int REQUEST_PERMISSION = 999;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        //오디오 권한 체크
        //위치 권한 체크
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            android.Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    }, REQUEST_PERMISSION);
            return;
        }
        init();
    }

    private void init() {


        DaquvSDK.getInstance().init(this, new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);
                //로그인 성공
                if (code == DaquvConfig.CODE.API_LOGIN) {
                    //로딩 화면 끄기
                    binding.simpleLoading.setVisibility(View.GONE);

                    binding.mainWebview.setVisibility(View.VISIBLE);
                    binding.mainWebview.loadUrl("https://www.ibk.co.kr/");
                }
            }
        });

        binding.btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.inputEmn.getText() != null) {
                    DaquvSDK.getInstance().getAPI().login("CRM", binding.inputEmn.getText().toString(), "ibkCrm");


                    //소프트 키보드 내리기
                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(binding.inputEmn.getWindowToken(), 0);

                    //로딩 화면 보이기
                    binding.simpleLoading.setVisibility(View.VISIBLE);
                }
            }
        });

        binding.buttonDaquv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (DaquvSDK.getInstance().isLogin()) {
                    binding.daquvView.init(getSupportFragmentManager());
                }
            }
        });

        binding.buttonLauncher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent targetIntent = new Intent(MainActivity.this, LauncherActivity.class);
                targetIntent.setAction(Intent.ACTION_VIEW);
                targetIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                DaquvUtil.addShortCut(MainActivity.this, targetIntent, "다큐브", R.drawable.daquv_icon);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                init();
            } else {
                Toast.makeText(this, "오디오 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        DaquvSDK.getInstance().onDestroy();
    }
}