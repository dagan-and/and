package com.example.sampleapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.presentation.DaquvView;
import com.example.sampleapplication.databinding.ActivityLauncherBinding;


public class LauncherActivity extends AppCompatActivity {
    private ActivityLauncherBinding binding = null;
    private static final int REQUEST_PERMISSION = 999;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_launcher);

        //오디오 , 위치 권한 체크
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            android.Manifest.permission.RECORD_AUDIO,
                            android.Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    }, REQUEST_PERMISSION);
            return;
        }
        init();
    }

    private void init() {
        DaquvSDK.getInstance().init(this, new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);
                //로그인 성공
                if (code == DaquvConfig.CODE.API_LOGIN) {
                    binding.simpleLoading.setVisibility(View.GONE);

                    binding.daquvView.init(getSupportFragmentManager());
                    binding.daquvView.setViewListener(new DaquvView.ViewListener() {
                        @Override
                        public void onAttached() {
                            //다큐브 뷰 추가 완료
                        }

                        @Override
                        public void onDetached() {
                            //다큐브 뷰 제거시
                            finish();
                        }
                    });
                }
            }
        });

        DaquvSDK.getInstance().getAPI().login("CRM", "017268", "ibkCrm");

        binding.simpleLoading.setVisibility(View.VISIBLE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                init();
            } else {
                Toast.makeText(this, "오디오 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        DaquvSDK.getInstance().onDestroy();
        super.onDestroy();
    }
}