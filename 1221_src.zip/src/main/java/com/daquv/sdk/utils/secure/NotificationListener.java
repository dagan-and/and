package com.daquv.sdk.utils.secure;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import com.daquv.sdk.utils.Logger;

public class NotificationListener extends NotificationListenerService {

    private SharedPreferences preferences;

    @Override
    public IBinder onBind(Intent intent) {
        preferences = getSharedPreferences("NotificationListener", MODE_PRIVATE);
        return super.onBind(intent);
    }

    @Override
    public StatusBarNotification[] getActiveNotifications() {
        return super.getActiveNotifications();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        super.onNotificationPosted(sbn);

        if(preferences != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                boolean isAudioCapture = false;
                for(StatusBarNotification noti : getActiveNotifications()) {
                    if("com.samsung.android.app.smartcapture".equals(noti.getPackageName())) {
                        Logger.info("smartcapture::running");
                        isAudioCapture = true;
                    }
                }
                Logger.info("smartcapture::none");
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean("capture", isAudioCapture);
                editor.apply();
            }
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        super.onNotificationRemoved(sbn);

        if(preferences != null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                boolean isAudioCapture = false;
                for(StatusBarNotification noti : getActiveNotifications()) {
                    if("com.samsung.android.app.smartcapture".equals(noti.getPackageName())) {
                        Logger.info("smartcapture::running");
                        isAudioCapture = true;
                    }
                }
                Logger.info("smartcapture::none");
                SharedPreferences.Editor editor = preferences.edit();
                editor.putBoolean("capture", isAudioCapture);
                editor.apply();
            }
        }
    }
}
