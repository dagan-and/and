package com.daquv.sdk.ui;

import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED;
import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_HIDDEN;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.FilterValue;
import com.daquv.sdk.ui.adapter.ConsultItemAdapter;
import com.daquv.sdk.ui.adapter.FilterItemAdapter;
import com.daquv.sdk.ui.adapter.FilterItemAdapterDecoration;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.util.ArrayList;

public class ConsultBottomSheetView {
    public interface OnStateListener {
        void onStateChanged(int newState);

        void onItemClick(FilterValue data, int type);
    }

    private final Activity context;
    private final OnStateListener listener;
    private final BottomSheetBehavior<View> bottomSheetView;
    private final RecyclerView recyclerView;
    private final ConsultItemAdapter adapter;
    private int type = 1;


    public ConsultBottomSheetView(Activity context,
                                  ViewGroup view,
                                  ArrayList<FilterValue> listItem,
                                  OnStateListener listener) {
        this.context = context;
        this.listener = listener;


        bottomSheetView = BottomSheetBehavior.from(view);
        this.recyclerView = view.findViewById(R.id.recycler_view);
        this.adapter = new ConsultItemAdapter(listItem);
        init();

        view.setOnClickListener(new View.OnClickListener() {@Override public void onClick(View view) {/*NONE*/}});
    }

    private void init() {
        bottomSheetView.setState(BottomSheetBehavior.STATE_HIDDEN);
        bottomSheetView.setHideable(true);
        bottomSheetView.setSkipCollapsed(true);
        bottomSheetView.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(View bottomSheet, int newState) {
                if (newState == STATE_HIDDEN) {
                    context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_main_theme));
                }
                if (newState == STATE_EXPANDED) {
                    context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_dark_dim));
                }
                if (listener != null) {
                    listener.onStateChanged(newState);
                }
            }

            @Override
            public void onSlide(View bottomSheet, float slideOffset) {
                //onSlide
            }
        });
        this.recyclerView.addItemDecoration(new FilterItemAdapterDecoration(recyclerView.getContext()));
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new ConsultItemAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(FilterValue data) {
                for(FilterValue value : adapter.getFilters()) {
                    value.setSelect(false);
                }
                data.setSelect(true);
                listener.onItemClick(data, type);
            }
        });
    }

    public void setType(int type) {
        this.type = type;
    }

    public void setFilters(ArrayList<FilterValue> filters) {
        this.adapter.setFilters(filters);
        this.adapter.notifyDataSetChanged();
    }


    public boolean isStateExpanded() {
        return bottomSheetView.getState() == STATE_EXPANDED ||
                bottomSheetView.getState() == BottomSheetBehavior.STATE_HALF_EXPANDED;
    }

    public void expandView() {
        bottomSheetView.setState(STATE_EXPANDED);
        context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_dark_dim));
    }

    public void collapseView() {
        bottomSheetView.setState(BottomSheetBehavior.STATE_HIDDEN);
        context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_main_theme));
    }
}
