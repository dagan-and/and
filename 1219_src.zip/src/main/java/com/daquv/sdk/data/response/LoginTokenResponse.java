package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class LoginTokenResponse  implements Serializable {

    @SerializedName("userInfo")
    private UserInfo userInfo;

    @SerializedName("companyInfoDto")
    private CompanyInfo companyInfo;

    @SerializedName("email")
    private String email;

    @SerializedName("companyId")
    private String companyId;

    @SerializedName("cmmncId")
    private String cmmncId;

    @SerializedName("jwtToken")
    private String token;

    @SerializedName("aggrYn")
    private String aggrYn;

    @SerializedName("recQuestVO")
    private ArrayList<RecQuestVO> recQuestVO;

    @SerializedName("recEntityVO")
    private ArrayList<RecEntityVO> recEntityVO;

    @SerializedName("emn")
    private String emn;

    @SerializedName("emm")
    private String emm;

    @SerializedName("pnmnBrcd")
    private String pnmnBrcd;

    @SerializedName("pnmnBrn")
    private String pnmnBrn;

    @SerializedName("aggrRegDt")
    private String aggrRegDt;

    private Boolean isAuthAgree = false;

    public static class RecQuestVO implements Serializable {
        @SerializedName("ctgry")
        private String ctgry;

        @SerializedName("ctgryNm")
        private String ctgryNm;

        @SerializedName("sys")
        private String sys;

        @SerializedName("sysNm")
        private String sysNm;

        @SerializedName("info")
        private ArrayList<RecQuestInfo> info;

        public String getCtgry() {
            return ctgry;
        }

        public String getCtgryNm() {
            return ctgryNm;
        }

        public String getSys() {
            return sys;
        }

        public String getSysNm() {
            return sysNm;
        }

        public ArrayList<RecQuestInfo> getInfo() {
            return info;
        }
    }

    public static class RecQuestInfo implements Serializable {
        @SerializedName("quest")
        private String quest;


        public String getQuest() {
            return quest;
        }
    }

    public static class RecEntityVO implements Serializable {
        @SerializedName("intent")
        private String intent;

        @SerializedName("entity")
        private ArrayList<String> entity;

        public String getIntent() {
            return intent;
        }

        public ArrayList<String> getEntity() {
            return entity;
        }
    }

    public UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public CompanyInfo getCompanyInfo() {
        return companyInfo;
    }

    public void setCompanyInfo(CompanyInfo companyInfo) {
        this.companyInfo = companyInfo;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCmmncId() {
        return cmmncId;
    }

    public void setCmmncId(String cmmncId) {
        this.cmmncId = cmmncId;
    }

    public String getEmn() {
        return emn;
    }

    public void setEmn(String emn) {
        this.emn = emn;
    }

    public String getPnmnBrcd() {
        return pnmnBrcd;
    }

    public void setPnmnBrcd(String pnmnBrcd) {
        this.pnmnBrcd = pnmnBrcd;
    }

    public ArrayList<RecQuestVO> getRecQuestVO() {
        return recQuestVO;
    }

    public void setRecQuestVO(ArrayList<RecQuestVO> recQuestVO) {
        this.recQuestVO = recQuestVO;
    }

    public ArrayList<RecEntityVO> getRecEntityVO() {
        return recEntityVO;
    }

    public void setRecEntityVO(ArrayList<RecEntityVO> recEntityVO) {
        this.recEntityVO = recEntityVO;
    }

    public Boolean getAuthAgree() {
        return isAuthAgree;
    }

    public void setAuthAgree(Boolean authAgree) {
        isAuthAgree = authAgree;
    }

    public String getAggrYn() {
        return aggrYn;
    }

    public String getEmm() {
        return emm;
    }

    public void setEmm(String emm) {
        this.emm = emm;
    }

    public String getPnmnBrn() {
        return pnmnBrn;
    }

    public void setPnmnBrn(String pnmnBrn) {
        this.pnmnBrn = pnmnBrn;
    }

    public String getAggrRegDt() {
        return aggrRegDt;
    }

    public void setAggrRegDt(String aggrRegDt) {
        this.aggrRegDt = aggrRegDt;
    }
}
