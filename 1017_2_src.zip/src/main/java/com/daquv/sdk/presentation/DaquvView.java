package com.daquv.sdk.presentation;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.os.Build;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.airbnb.lottie.LottieAnimationView;
import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.LocationItemResponse;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.ui.SpeakerView;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;

import java.util.List;

public class DaquvView extends ConstraintLayout implements View.OnClickListener {

    public DaquvView(@NonNull Context context) {
        super(context);
        init();
    }

    public DaquvView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }               

    public DaquvView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }


    public interface ViewListener{
        void onAttached();
        void onDetached();
    }

    public interface FragmentListener{
        void onBackPress();
        void addArgumentView();
        void addHTMLView(String title, String url, HTMLFragment.Listener htmlListener);
        void addMainView();
        void addDataView();
        void addMapView(LocationItemResponse items);
        void addConsultView();
        void addVoiceView();
        void removeVoiceView();
        void addKeypadView();
        void addSettingView();
        void showLoading();
        void hideLoading();
        void startSTT();
        void login();
    }

    String[] loginInfo;
    RelativeLayout loadingView;
    FrameLayout bottomContainer;
    FrameLayout mainView;
    FragmentManager fragmentManager;
    FragmentListener listener;
    DaquvEngine.Callback sdkCallback;
    LottieAnimationView micView;
    SpeakerView speakerView;
    LottieAnimationView loadingImage;
    ViewListener viewListener;

    private void init() {
        initView();
        setWhiteStatusBarMode((Activity)getContext()  , false);
        setVisibility(View.VISIBLE);
    }

    public void launch() {
        if(!DaquvSDK.getInstance().checkPermission(getContext())) {
            return;
        }

        setBackgroundColor(ContextCompat.getColor(getContext() ,R.color.dqv_white));

        sdkCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);
                if(code == DaquvConfig.CODE.API_MAIN_DATA) {
                    listener.addMainView();
                    if(viewListener != null) {
                        viewListener.onAttached();
                    }
                }

                if(code == DaquvConfig.CODE.API_LOGIN) {
                    if(SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_ARGUMENT_POLICY_AGREE)) {
                        DaquvSDK.getInstance().getAPI().getMainPage(DaquvUtil.getUrl("/webview/ibkCrm/v1/cmn/main"));
                    } else {
                        listener.addArgumentView();
                    }
                }

                if(code == DaquvConfig.CODE.ENGINE_START_VOICE) {
                    micView.setAnimation(R.raw.main_mic_color_ibk);
                    micView.playAnimation();
                }

                if(code == DaquvConfig.CODE.ENGINE_STOP_VOICE) {
                    micView.cancelAnimation();
                    micView.setImageResource(R.drawable.img_main_pause);
                }

                if(code == DaquvConfig.CODE.API_NLU_SUCCESS) {
                    listener.hideLoading();
                    listener.addDataView();
                    listener.removeVoiceView();
                }

                if(code == DaquvConfig.CODE.API_NLU_MAP){
                    listener.hideLoading();
                }

                if(code == DaquvConfig.CODE.API_NLU_FAIL) {
                    listener.hideLoading();
                }

                if(code == DaquvConfig.CODE.API_NLU_REASK) {
                    listener.hideLoading();

                }

                if(code == DaquvConfig.CODE.API_NLU_MAP) {
                    if(result instanceof LocationItemResponse &&
                            ((LocationItemResponse) result).getBody() != null &&
                            ((LocationItemResponse) result).getCount() > 0) {
                        listener.addMapView(((LocationItemResponse) result));
                    } else if(result instanceof LocationItemResponse) {
                        DaquvSDK.getInstance().getAPI().getTTSBinary("조회 할 수 있는 기업이 없습니다.");
                        listener.addMapView(((LocationItemResponse) result));
                    }
                    listener.removeVoiceView();
                }

                if(code == DaquvConfig.CODE.API_ERROR) {
                    if(result instanceof ErrorData) {
                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
                        alertDialog.setMessage(((ErrorData) result).getMsg());
                        alertDialog.create().show();
                    }
                    listener.hideLoading();
                }
            }
        };

        listener = new FragmentListener() {
            @Override
            public void onBackPress() {

                //답변화면 2개일때 백키 처리하기
                //TTS API 도중 중단 처리 하지 말고 , TTS 할때 답변화면의 고유값 넣어서

                Logger.dev("=====onBackPress=====");

                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                String message = "onBackPress::";
                for (Fragment fragment : fragmentManager.getFragments()) {
                    message += (fragment.getTag() + ",");
                }
                builder.setMessage(message);
                builder.show();

                if(fragmentManager.getFragments().size() > 1) {
                    if(fragmentManager.getFragments().size() == 2 && hasFragment("Main")) {
                        bottomContainer.setVisibility(View.VISIBLE);
                    }
                    if(hasFragment("KeyPad") || hasFragment("Map") || hasFragment("Consult") ) {
                        fragmentManager.popBackStack();
                        Logger.dev("popBackStack");
                        return;
                    }
                    fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                    bottomContainer.setVisibility(View.VISIBLE);
                    Logger.dev("popBackStack(POP_BACK_STACK_INCLUSIVE)");
                } else {
                    onDestroy();
                    Logger.dev("onDestroy");
                }

                Logger.dev("=====onBackPress=====");
            }

            @Override
            public void addArgumentView() {
                ArgumentFragment data = new ArgumentFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(mainView.getId(), data, "Argument")
                        .commitAllowingStateLoss();
                bottomContainer.setVisibility(View.GONE);
            }

            @Override
            public void addHTMLView(String title, String url, HTMLFragment.Listener htmlListener) {
                boolean hasHTMLView = false;
                Fragment hasFragment = null;
                for(Fragment fragment : fragmentManager.getFragments()) {
                    if("HTML".equals(fragment.getTag())) {
                        hasHTMLView = true;
                        hasFragment = fragment;
                    }
                }
                HTMLFragment data = new HTMLFragment();
                data.setListener(listener);
                data.setHtmlListener(htmlListener);
                data.setTitle(title);
                data.setUrl(url);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(0,0,0,0);
                if (hasHTMLView) {
                    fragmentTransaction.remove(hasFragment);
                }
                fragmentTransaction.add(mainView.getId(), data , "HTML")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void addMainView() {
                MainFragment data = new MainFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(mainView.getId(), data, "Main")
                        .commitAllowingStateLoss();
                bottomContainer.setVisibility(View.VISIBLE);
                speakerView.updateView();

                addVoiceView();
            }

            @Override
            public void addDataView() {
                boolean hasView = false;
                Fragment hasFragment = null;
                for(Fragment fragment : fragmentManager.getFragments()) {
                    if("Data".equals(fragment.getTag())) {
                        hasView = true;
                        hasFragment = fragment;
                    }
                }
                DataFragment data = new DataFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.slide_in_right,
                        R.anim.slide_out_left,
                        R.anim.slide_in_left,
                        R.anim.slide_out_right);
                if (hasView) {
                    fragmentTransaction.remove(hasFragment);
                }
                fragmentTransaction.add(mainView.getId(), data , "Data")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void addMapView(LocationItemResponse response) {
                boolean hasView = false;
                for(Fragment fragment : fragmentManager.getFragments()) {
                    if("Map".equals(fragment.getTag())) {
                        hasView = true;
                    }
                }
                if(!hasView) {
                    MapFragment data = new MapFragment();
                    data.setListener(listener);

                    if(response.getBody() != null) {
                        data.setLocationItem(response.getBody());
                    }

                    Location location = new Location(DaquvSDK.getInstance().getLocation());
                    location.setLatitude(response.getLatitude());
                    location.setLongitude(response.getLongitude());
                    data.setLocation(location);

                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.setCustomAnimations(R.anim.slide_in_right,
                            R.anim.slide_out_left,
                            R.anim.slide_in_left,
                            R.anim.slide_out_right);
                    fragmentTransaction.add(mainView.getId(), data , "Map")
                            .addToBackStack(null)
                            .commitAllowingStateLoss();
                    bottomContainer.setVisibility(View.GONE);
                }
            }

            @Override
            public void addConsultView() {
                ConsultFragment data = new ConsultFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.slide_in_right,
                        R.anim.slide_out_left,
                        R.anim.slide_in_left,
                        R.anim.slide_out_right);
                fragmentTransaction.add(mainView.getId(), data , "Consult")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
                bottomContainer.setVisibility(View.GONE);
            }

            @Override
            public void addVoiceView() {
                VoiceFragment data = new VoiceFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(0, 0, 0, 0);
                fragmentTransaction.add(mainView.getId(), data, "Voice")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void removeVoiceView() {
                boolean hasVoiceView = false;
                Fragment hasFragment = null;
                for(Fragment fragment : fragmentManager.getFragments()) {
                    if("Voice".equals(fragment.getTag())) {
                        hasVoiceView = true;
                        hasFragment = fragment;
                    }
                }
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                if (hasVoiceView) {
                    fragmentTransaction.remove(hasFragment)
                            .commitAllowingStateLoss();
                }
            }

            @Override
            public void addKeypadView() {
                KeyPadFragment data = new KeyPadFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.keyapd_slide_up, R.anim.slide_out_left, 0, 0);
                fragmentTransaction.add(mainView.getId(), data, "KeyPad")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void addSettingView() {
                SettingFragment data = new SettingFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.slide_in_right,
                        R.anim.slide_out_left,
                        R.anim.slide_in_left,
                        R.anim.slide_out_right);
                fragmentTransaction.add(mainView.getId(), data, "Setting")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
                bottomContainer.setVisibility(View.GONE);
            }

            @Override
            public void showLoading() {
                loadingView.setVisibility(View.VISIBLE);
                loadingImage.setAnimation(R.raw.v3_loading);
                loadingImage.playAnimation();
            }

            @Override
            public void hideLoading() {
                loadingView.setVisibility(View.GONE);
                loadingImage.pauseAnimation();
            }

            @Override
            public void startSTT() {
                listener.addVoiceView();
            }

            @Override
            public void login() {
                SplashFragment data = new SplashFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(mainView.getId(), data, "Splash")
                        .commitAllowingStateLoss();
                bottomContainer.setVisibility(View.GONE);

                DaquvSDK.getInstance().getAPI().login(loginInfo);
            }
        };
        DaquvSDK.getInstance().init(getContext() , sdkCallback);
        listener.login();
    }

    public void setViewListener(ViewListener viewListener) {
        this.viewListener = viewListener;
    }


    public void onDestroy() {
        if(viewListener != null) {
            viewListener.onDetached();
        } else {
            clearStack();
            setVisibility(View.GONE);
        }
        DaquvSDK.getInstance().removeCallBack(sdkCallback);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.micView) {
            if(DaquvSDK.getInstance().getEngine().isRunning()) {
                listener.removeVoiceView();
            } else {
                listener.addVoiceView();
            }
        } else if(view.getId() == R.id.keypadView) {
            DaquvSDK.getInstance().getEngine().stopEngine();
            listener.addKeypadView();
//
//            listener.addSettingView();

//            listener.addRecorderView();
//            listener.addConsultView();

            //지도기능 사용하는지 체크
            //getLocation 널체크
//            LocationManager locationManager = (LocationManager) getContext().getSystemService(LOCATION_SERVICE);
//            if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
//                DaquvSDK.getInstance().getAPI().getMapData(String.valueOf(DaquvSDK.getInstance().getLocation().getLatitude()),
//                        String.valueOf(DaquvSDK.getInstance().getLocation().getLongitude()),
//                        DaquvConfig.appConfig.mapInfo.filter.get(0).value.get(0));
//            } else {
//                Toast.makeText(getContext(), "GPS 기능을 활성화 해주세요.", Toast.LENGTH_SHORT).show();
//            }

            NLUResultResponse nluResultResponse = new NLUResultResponse();
            //브리핑
            nluResultResponse.setUrl("/webview/ibkCrm/v1/brf/crmBrf");
            nluResultResponse.setIntent("IB001");
            //일정조회
//            nluResultResponse.setUrl("/webview/ibkCrm/v1/scd/inqScheduleList");
//            nluResultResponse.setIntent("IB015");
//
//            DaquvSDK.getInstance().getAPI().getResultPage(nluResultResponse);
        }
    }

    private void initView() {
        mainView = new FrameLayout(getContext());
        mainView.setId(R.id.mainView);
        ConstraintLayout.LayoutParams mainViewParams = new ConstraintLayout.LayoutParams(
                0, 0
        );
        mainViewParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        mainViewParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        mainViewParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        mainViewParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
        mainView.setLayoutParams(mainViewParams);
        addView(mainView);


        bottomContainer = new FrameLayout(getContext());
        bottomContainer.setId(R.id.bottom_container);
        ConstraintLayout.LayoutParams bottomContainerParams = new ConstraintLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT
        );
        bottomContainerParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomContainerParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomContainerParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomContainer.setLayoutParams(bottomContainerParams);

        View inflatedLayout= LayoutInflater.from(getContext()).inflate(R.layout.view_button_container, (ViewGroup) getRootView(), false);
        inflatedLayout.setOnClickListener(view -> { /*NONE*/ });

        AppCompatImageView keypadView = inflatedLayout.findViewById(R.id.keypadView);
        keypadView.setOnClickListener(this);

        micView = inflatedLayout.findViewById(R.id.micView);
        micView.setOnClickListener(this);
        speakerView = inflatedLayout.findViewById(R.id.speakerView);

        bottomContainer.addView(inflatedLayout);
        addView(bottomContainer);


        loadingView = new RelativeLayout(getContext());
        loadingView.setId(R.id.loadingView);
        loadingView.setVisibility(View.GONE);
        loadingView.setBackgroundColor(ContextCompat.getColor(getContext() , R.color.dqv_dim));
        ConstraintLayout.LayoutParams loadingViewParams = new ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        );
        loadingView.setLayoutParams(loadingViewParams);

        loadingImage = new LottieAnimationView(getContext());
        loadingImage.setAnimation(R.raw.v3_loading);
        loadingImage.setRepeatCount(ValueAnimator.INFINITE);
        RelativeLayout.LayoutParams loadingImageParams = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        loadingImageParams.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        loadingImage.setLayoutParams(loadingImageParams);
        loadingView.addView(loadingImage);
        addView(loadingView);
    }

    public void setLoginInfo(String... loginInfo) {
        this.loginInfo = loginInfo;
    }

    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public void clearStack() {
        int backStackEntry = fragmentManager.getBackStackEntryCount();
        if (backStackEntry > 0) {
            for (int i = 0; i < backStackEntry; i++) {
                fragmentManager.popBackStackImmediate();
            }
        }
        if (fragmentManager.getFragments().size() > 0) {
            List<Fragment> fragments = fragmentManager.getFragments();
            for (Fragment fragment : fragments) {
                if (fragment != null) {
                    fragmentManager.beginTransaction().remove(fragment).commit();
                }
            }
        }
    }

    private boolean hasFragment(String tag) {
        if(fragmentManager.getFragments().size() > 0) {
            for(Fragment fragment : fragmentManager.getFragments()) {
                if(fragment.getTag() != null && fragment.getTag().equals(tag)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void setWhiteStatusBarMode(Activity context, boolean onlyFlag) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!onlyFlag) {
                context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_main_theme));
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && context.getWindow() != null && context.getWindow().getInsetsController() != null) {
                context.getWindow().getInsetsController().setSystemBarsAppearance(
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                );
            } else {
                int systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    systemUiVisibility |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
                context.getWindow().getDecorView().setSystemUiVisibility(systemUiVisibility);
            }
        }
    }
}
