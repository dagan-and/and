package com.daquv.sdk.webview.action;

import org.json.JSONException;


public class DefaultAction extends BaseWebAction {

    public interface WebActionCallback {
        void event(WebActionInfo webActionInfo);
    }

    WebActionCallback callback;

    /**
     * 생성자
     * @param bridge WebActionBridge
     */
    public DefaultAction(WebActionBridge bridge , WebActionCallback callback ) {
        super(bridge);
        this.callback = callback;
    }

    /**
     *캡쳐 이미지 URL
     *
     * @throws JSONException
     */
    public void _webResultCapture_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }
    /**
     * 웹 화면 종료
     * window.BrowserBridge.iWebAction('{"_action_code":"closeWindow", "_data":"close"}');
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _closeWindow_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }
    /**
     * TTS 재생
     * window.BrowserBridge.iWebAction('{"_action_code":"webResultTTS","_action_data":{"_data":"거래처 350건 있습니다.","_call_back":""}}');
     * window.BrowserBridge.iWebAction('{"_action_code":"webResultTTS","_action_data":{"_data":"거래처 350건 있습니다.","_call_back":"startSTT"}}');
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _webResultTTS_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }
    /**
     * TTS 재생
     * DaquvInterface.postMessage("gostt","거래처 350건 있습니다")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gotts_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }
    /**
     * STT 실행
     * window.BrowserBridge.iWebAction('{"_action_code":"startSTT", "_data":"stt"}');
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _startSTT_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }
    /**
     * STT 실행
     * DaquvInterface.postMessage("gostt")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gostt_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }

    /**
     * STT 중지
     * window.BrowserBridge.iWebAction('{"_action_code":"stopSTT", "_data":"stt"}');
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _stopSTT_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }

    /**
     * 웹 화면 종료
     * DaquvInterface.postMessage("gohome")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gohome_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }

    /**
     * 설정화면 호출
     * DaquvInterface.postMessage("gosetting")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gosetting_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }

    /**
     * 전화걸기
     * DaquvInterface.postMessage("gocall","01012344321")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gocall_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }

    /**
     * 상담기록 화면 호출
     * DaquvInterface.postMessage("goconsult")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _goconsult_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }

    /**
     * 지도화면 호출 (현재 위치)
     * DaquvInterface.postMessage("gocurmap")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gocurmap_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }

    /**
     * 지도화면 호출 (특정 위치)
     * DaquvInterface.postMessage("gospcmap", "12.1212313","15.12312")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gospcmap_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }


    /**
     * 길찾기
     * DaquvInterface.postMessage("gonavi", "12.1212313","15.12312")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gonavi_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }

    /**
     * 다중 길찾기
     * DaquvInterface.postMessage("gomultinavi", "{ array data}")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gomultinavi_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }

    /**
     * 외부 브라우저 이동
     * DaquvInterface.postMessage("gobrowser", "http://asdad.das")
     * @param webActionInfo 웹액션 정보
     * @throws JSONException
     */
    public void _gobrowser_(WebActionInfo webActionInfo) throws JSONException {
        callback.event(webActionInfo);
    }
}
