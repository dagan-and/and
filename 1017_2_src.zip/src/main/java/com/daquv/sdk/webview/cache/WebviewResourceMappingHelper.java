package com.daquv.sdk.webview.cache;

import android.content.Context;
import android.text.TextUtils;
import android.webkit.WebResourceResponse;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.utils.Logger;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okio.BufferedSink;
import okio.Okio;


public class WebviewResourceMappingHelper {


    /** 확장자가 있는 파일 리소스 관리 */
    private final List<String> overridableExtensions = new ArrayList<>(Arrays.asList("css", "png", "jpg", "woff", "ttf", "eot", "ico","svg","woff2"));

    /** 확징자가 없는 파일 리소스 관리 */
    private final HashMap<String, String> overridableNonExtensions = new HashMap<>();

    private WebviewResourceMappingHelper(){
    }

    public static WebviewResourceMappingHelper getInstance() {
        return WebviewResourceMappingHelper.LazyHolder.INSTANCE;
    }

    private static class LazyHolder {
        private static final WebviewResourceMappingHelper INSTANCE = new WebviewResourceMappingHelper();
    }

    public String getLocalFilePath(String url){
        String localFilePath = "";
        String fileNameForUrl = getLocalFileNameForUrl(url);
        if(!TextUtils.isEmpty(fileNameForUrl) && fileExists(fileNameForUrl)){
            localFilePath = fileNameForUrl;
        }
        return localFilePath;
    }

    public String getLocalFilePathFromKey(String key){
        String localFilePath = "";
        if(fileExists(key)){
            localFilePath = key;
        }
        return localFilePath;
    }

    private boolean fileExists(String fileName){
        return DaquvSDK.getInstance().getLocalCacheData().get(fileName) != null;
    }

    public String getLocalFileNameForUrl(String url){
        String localFileName = "";
        String[] parts = url.split("/");
        if(parts.length > 0){
            localFileName = parts[parts.length-1];
        }
        return localFileName;
    }

    public String replaceUrlToFileName(String url){
        return url.replaceAll("[-+.^:,/@=;?]","");
    }

    public Observable<Object> saveWebResourceFile(String url) {
        return Observable.fromCallable(new Callable<Object>() {
                    @Override
                    public Object call() {
                        try {
                            OkHttpClient.Builder builder = new OkHttpClient.Builder();
                            builder.connectTimeout(15, TimeUnit.SECONDS);
                            builder.readTimeout(15, TimeUnit.SECONDS);

                            OkHttpClient httpClient = builder.build();
                            Request.Builder request = new Request.Builder();
                            request.url(url);
                            Response response = httpClient.newCall(request.build()).execute();

                            String path;
                            if(!TextUtils.isEmpty(url)) {
                                path = url;
                            } else {
                                path = getLocalFileNameForUrl(url);
                            }

                            if (response.body() != null) {
                                DaquvSDK.getInstance().getLocalCacheData().put(path, response.body().source().readByteArray());
                            }

                            if(!TextUtils.isEmpty(url)) {
                                overridableNonExtensions.put(url, url);
                            }
                            return url;
                        } catch (Exception e) {
                            Logger.error(e);
                        }
                        return "";
                    }
                }).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io());
    }

    public void loadWebResourceFile(String fileName ,String url) {
        if(!TextUtils.isEmpty(fileName)) {
            overridableNonExtensions.put(url, fileName);
        }
    }

    public List<String> getOverridableExtensions(){
        return overridableExtensions;
    }

    public HashMap<String , String> getOverridableNonExtensions() {
        return overridableNonExtensions;
    }

    public String getFileExt(String fileName) {
        return fileName.substring(fileName.lastIndexOf(".") + 1, fileName.length());
    }

    public String getMimeType(String fileExtension){
        String mimeType = "";
        switch (fileExtension){
            case "css" :
                mimeType = "text/css";
                break;
            case "js" :
                mimeType = "text/javascript";
                break;
            case "png" :
                mimeType = "image/png";
                break;
            case "jpg" :
                mimeType = "image/jpeg";
                break;
            case "woff" :
                mimeType = "font/woff";
                break;
            case "woff2" :
                mimeType = "font/woff2";
                break;
            case "ttf" :
                mimeType = "font/ttf";
                break;
            case "ico" :
                mimeType = "image/x-icon";
                break;
            case "svg" :
                mimeType = "image/svg+xml";
                break;
            default:
                mimeType =  "application/octet-stream";
                break;
        }
        return mimeType;
    }

    public WebResourceResponse getWebResourceResponseFromFile(String filePath, String mimeType, String encoding) throws FileNotFoundException {
        InputStream fileInputStream = new ByteArrayInputStream(DaquvSDK.getInstance().getLocalCacheData().get(filePath));
        int statusCode = 200;
        String reasonPhase = "OK";
        Map<String, String> responseHeaders = new HashMap<String, String>();
        responseHeaders.put("Access-Control-Allow-Origin","*");
        return new WebResourceResponse(mimeType, encoding, statusCode, reasonPhase, responseHeaders, fileInputStream);
    }

    private class LocalAssetMapModel{
        String url;
        String assetUrl;
    }
}
