package com.daquv.sdk.stt.itl;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.daquv.sdk.stt.itl.api.ItlController;


public class ITLModel {

    public static ITLModel getInstance() {
        return ITLModel.LazyHolder.INSTANCE;
    }

    private static class LazyHolder {
        private static final ITLModel INSTANCE = new ITLModel();
    }

    public enum STATUS {
        PARTIAL,
        FINAL
    }

    private static ItlController itlCtl = null;

    public void launchITLEngine(Context context, ItlController.OnResultListener listener) {
        if (itlCtl == null) {
            itlCtl = new ItlController(context);
        }
        itlCtl.setListener(listener);
    }

    public void startNetworkJob() {
        itlCtl.startDoNetworkJob();
    }

    public void startController() {
        if (itlCtl == null) return;

        itlCtl.startWakeUpWithSTT();
        startNetworkJob();
    }

    public void stopController() {
        if (itlCtl == null) return;

        itlCtl.stopWakeupWithSTT();
    }

    public void restartController() {
        stopController();
        startController();
    }
}
