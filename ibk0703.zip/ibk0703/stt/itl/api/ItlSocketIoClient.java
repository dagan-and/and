package com.daquv.sdk.stt.itl.api;


import android.os.Handler;
import android.os.Message;

import com.daquv.sdk.utils.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.Arrays;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class ItlSocketIoClient {
    private boolean mConnected = false;
    private final String mHost;
    private final int mPort;
    private final Handler mHandler;
    public static final int DISCONNECT =    3999;
    public static final int JSON_RESULT =   3000;
    public static final int ALERT =         3001;
    public static final int READY =         3002;
    public static final int TIMEOUT =       3003;
    public static final int SAVE_PCM =      3004;
    private Socket mSocket;
    private final Emitter.Listener connect = new Emitter.Listener() {
        public void call(Object... args) {
            Logger.dev("ITL{" + mHost + ":" +mPort + ":::::Connect}");
            ItlSocketIoClient.this.mSocket.emit("samplingRate", 16000);
        }
    };
    private final Emitter.Listener connectError = new Emitter.Listener() {
        public void call(Object... args) {
            Logger.dev("ITL{" + Arrays.toString(args) + ":::::Error}");
            ItlSocketIoClient.this.sendMsg(ALERT, "Socket connect error: " + Arrays.toString(args));
            ItlSocketIoClient.this.mSocket.disconnect();
        }
    };
    private final Emitter.Listener disconnect = new Emitter.Listener() {
        public void call(Object... args) {
            Logger.dev("ITL{=====Disconnect=====}");
            ItlSocketIoClient.this.mConnected = false;
            ItlSocketIoClient.this.sendMsg(DISCONNECT, "");
        }
    };
    private final Emitter.Listener response = new Emitter.Listener() {
        public void call(Object... args) {
            String json = null;
            try {
                json = args[0].toString();
                JSONObject jObj = new JSONObject(json);
                if (jObj.getString("status").equals("READY")) {
                    ItlSocketIoClient.this.mConnected = true;
                    ItlSocketIoClient.this.sendMsg(READY, json);
                } else {
                    ItlSocketIoClient.this.sendMsg(JSON_RESULT, json);
                }
                Logger.dev("ITL" + uniToKor(json));
            } catch (JSONException var5) {
                var5.printStackTrace();
            }

        }
    };

    public ItlSocketIoClient(String host, int port, Handler handler) {
        this.mHost = host;
        this.mPort = port;
        this.mHandler = handler;
    }

    private void sendMsg(int what, String str) {
        Message msg = Message.obtain();
        msg.what = what;
        msg.obj = str;
        this.mHandler.sendMessage(msg);
    }

    public boolean isConnected() {
        return this.mConnected;
    }

    public void connect() {
        try {
            IO.Options opts = new IO.Options();
            opts.transports = new String[]{"websocket"};
            this.mSocket = IO.socket(this.mHost + ":" + this.mPort, opts);
        } catch (URISyntaxException var3) {
            var3.printStackTrace();
            this.sendMsg(ALERT, "Unknown Host");
            return;
        }

        this.mSocket.on("connect", this.connect);
        this.mSocket.on("disconnect", this.disconnect);
        this.mSocket.on("connect_error", this.connectError);
        this.mSocket.on("response", this.response);

        try {
            this.mSocket.connect();
        } catch (Exception var2) {
            var2.printStackTrace();
            this.sendMsg(ALERT, "서버 접속 실패");
            this.disconnect();
        }

    }

    public void disconnect() {
        if (this.mConnected) {
            this.mSocket.disconnect();
        }
    }

    public void send(byte[] audio) {
        if (this.mConnected) {
            this.mSocket.emit("sendArrBuf", new Object[]{audio});
        }
    }

    public String uniToKor(String uni){
        StringBuffer result = new StringBuffer();

        for(int i=0; i<uni.length(); i++){
            if(uni.charAt(i) == '\\' &&  uni.charAt(i+1) == 'u'){
                Character c = (char)Integer.parseInt(uni.substring(i+2, i+6), 16);
                result.append(c);
                i+=5;
            }else{
                result.append(uni.charAt(i));
            }
        }
        return result.toString();
    }
}

