package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class CusInfoResponse implements Serializable {

    @SerializedName("cmunNm")
    private String cmunNm;

    @SerializedName("url")
    private String url;

    @SerializedName("companyId")
    private String companyId;

    @SerializedName("cunsultType")
    private ArrayList<FilterValue> type;

    public String getCmunNm() {
        return cmunNm;
    }

    public void setCmunNm(String cmunNm) {
        this.cmunNm = cmunNm;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public ArrayList<FilterValue> getType() {
        return type;
    }

    public void setType(ArrayList<FilterValue> type) {
        this.type = type;
    }
}
