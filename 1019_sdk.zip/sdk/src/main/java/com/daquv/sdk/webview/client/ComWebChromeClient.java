package com.daquv.sdk.webview.client;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.webkit.ConsoleMessage;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

import com.daquv.sdk.ui.comm.ComDialogBuilder;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.webview.ComWebView;


public class ComWebChromeClient extends WebChromeClient {

    private final ComWebView mWebView;

    /**
     * 생성자
     */
    public ComWebChromeClient(ComWebView webView) {
        mWebView = webView;
    }

    /**
     * Web Console 메시지 제어
     * @param consoleMessage 웹 콘솔 메시지
     * @return Client 에서 웹뷰 콘솔로그 출력 제어 여부 (true : 제어 / false : 제어하지 않음)
     */
    @Override
    public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
        if(mWebView != null && consoleMessage != null) {
            mWebView.onWebViewError(consoleMessage);
            Logger.web(consoleMessage);
        }
        return false;
    }

    /**
     * 웹 Alert 제어
     * @param view 웹뷰
     * @param url URL
     * @param message 메시지
     * @param result JsResult
     * @return 앱에서 Alert 처리 여부 (true : 앱에서 처리 / false : 웹에서 처리)
     */
    @Override
    public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
        Logger.info("url :: " + url);
        Logger.info("message :: " + message);

        ComDialogBuilder dialogBuilder = new ComDialogBuilder(view.getContext());
        dialogBuilder.showConfirm(new ComDialogBuilder.OnCommDlgClickListener() {
            @Override
            public void onLeftButton() {

            }

            @Override
            public void onRightButton() {

            }

            @Override
            public void onDismiss() {

            }
        }, message , "확인");

        result.cancel();
        return true;
    }

    /**
     * 웹 Confirm 처리
     * @param view 웹뷰
     * @param url URL
     * @param message 메시지
     * @param result JsResult
     * @return 앱에서 Confirm 처리 여부 (true : 앱에서 처리 / false : 웹에서 처리)
     */
    @Override
    public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
        Logger.info("url :: " + url);
        Logger.info("message :: " + message);

        ComDialogBuilder dialogBuilder = new ComDialogBuilder(view.getContext());
        dialogBuilder.showConfirm(new ComDialogBuilder.OnCommDlgClickListener() {
            @Override
            public void onLeftButton() {

            }

            @Override
            public void onRightButton() {

            }

            @Override
            public void onDismiss() {

            }
        }, message , "확인");

        result.cancel();
        return true;
    }

    /**
     * 웹 Prompt 처리
     * @param view 웹뷰
     * @param url URL
     * @param message 메시지
     * @param defaultValue Prompt 에 표시되는 기본값
     * @param result JsResult
     * @return 앱에서 Prompt 처리 여부 (true : 앱에서 처리 / false : 웹에서 처리)
     */
    @Override
    public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
        Logger.info("url :: " + url);
        Logger.info("message :: " + message);

        ComDialogBuilder dialogBuilder = new ComDialogBuilder(view.getContext());
        dialogBuilder.showConfirm(new ComDialogBuilder.OnCommDlgClickListener() {
            @Override
            public void onLeftButton() {

            }

            @Override
            public void onRightButton() {

            }

            @Override
            public void onDismiss() {

            }
        }, message , "확인");


        result.cancel();
        return true;
    }
}
