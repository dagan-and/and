package com.daquv.sdk.stt.inside.conf;

import android.Manifest;


public class InsideConfig {

    public static String clientId = "";
    public static String clientKey = "";
    public static String clientSecret = "";

    public static String userId = "";

    public static String serverIp = "";
    public static String grpcPort = "";
    public static String resetPort = "";

    /**
     * 서비스 별로 KT키를 다르게 가져가기 위한 값
     */
    public static String serviceId = "";

    /**
     * Inside SDK 모듈 초기화 정보 설정
     * <br><br>
     * - 기가지니 포탈에서 발급 : Client ID, Client Key, Client Secret <br>
     * - User ID : Third Party 에서 생성 <br>
     *
     * @param cId     Client ID
     * @param cKey    Client KEY
     * @param cSecret Client Secret
     * @param uId     Uer ID
     */
    public static void initInside(String cId, String cKey, String cSecret, String uId, String sID) {
        clientId = cId;
        clientKey = cKey;
        clientSecret = cSecret;
        userId = uId;
        serviceId = sID;
    }

    /**
     * 서버정보 초기화
     *
     * @param serverIp  연동 서버 IP
     * @param grpcPort  연동 서버 gRPC Port
     * @param resetPort 연동 서버 rest Port
     */
    public static void initServer(String serverIp, String grpcPort, String resetPort) {
        InsideConfig.serverIp = serverIp;
        InsideConfig.grpcPort = grpcPort;
        InsideConfig.resetPort = resetPort;
    }
}
