package com.daquv.sdk.stt.inside.conf;

import android.content.Context;

import com.daquv.sdk.R;


/**
 * 모듈 처리 관련 상수 정의
 **/
public class InsideConst {

    public enum Status {
        //Grpc 모듈 초기화
        INIT,
        // 음성인식 시작 (사용자 음성 발화 대기 시작)
        START_LISTEN,
        // 모듈 음성 인식 종료 (사용자 음성 발화 대기 종료)
        STOP_LISTEN,
        STOP,
        // 모듈 구동 중 오류 발생
        ERROR
    }

    public static class Error {

        // 모듈 초기화 오류
        public static final int CODE_FAIL_INIT = 90000;
        // 모듈에서 음성 인식 결과를 처리 불가능 에러
        public static final int CODE_FAIL_RECOG = 90001;
        // 모듈 파싱 오류
        public static final int CODE_FAIL_PARSING = 12345678;

        public static String getErrorMsg(Context ctx, int errCode) {
            String errMsg = "";

            switch (errCode) {
                case 601:
                    errMsg = ctx.getString(R.string.err_msg_inside_601);
                    break;
                case 602:
                    errMsg = ctx.getString(R.string.err_msg_inside_602);
                    break;
                case 603:
                    errMsg = ctx.getString(R.string.err_msg_inside_603);
                    break;
                case 900:
                    errMsg = ctx.getString(R.string.err_msg_inside_900);
                    break;
                case 901:
                    errMsg = ctx.getString(R.string.err_msg_inside_901);
                    break;
                case 902:
                    errMsg = ctx.getString(R.string.err_msg_inside_902);
                    break;
                case 903:
                    errMsg = ctx.getString(R.string.err_msg_inside_903);
                    break;
                case 910:
                    errMsg = ctx.getString(R.string.err_msg_inside_910);
                    break;
                case 911:
                    errMsg = ctx.getString(R.string.err_msg_inside_911);
                    break;
                case 912:
                    errMsg = ctx.getString(R.string.err_msg_inside_912);
                    break;
                case 920:
                    errMsg = ctx.getString(R.string.err_msg_inside_920);
                    break;
                case 921:
                    errMsg = ctx.getString(R.string.err_msg_inside_921);
                    break;
                case 930:
                    errMsg = ctx.getString(R.string.err_msg_inside_930);
                    break;
                case CODE_FAIL_INIT:
                    errMsg = ctx.getString(R.string.err_msg_inside_90000);
                    break;
                case CODE_FAIL_RECOG:
                    errMsg = ctx.getString(R.string.err_msg_inside_90001);
                    break;
                case CODE_FAIL_PARSING:
                    errMsg = ctx.getString(R.string.app_restart);
                    break;
                default:
                    errMsg = ctx.getString(R.string.err_msg_inside_903);
                    break;
            }
            return errMsg;
        }
    }
}