package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

public class TTSResponse {
    @SerializedName("binaryString")
    private String binaryString = "";

    @SerializedName("binaryResult")
    private String binaryResult = "";

    @SerializedName("outputStream")
    private String outputStream = "";

    @SerializedName("msg")
    private String msg = "";

    private String callBack = "";
    private int code = 0;

    // Constructor, getters, and setters

    public TTSResponse(String binaryResult, int code) {
        this.binaryResult = binaryResult;
        this.code = code;
    }

    public String getBinaryString() {
        return binaryString;
    }

    public void setBinaryString(String binaryString) {
        this.binaryString = binaryString;
    }

    public String getBinaryResult() {
        return binaryResult;
    }

    public void setBinaryResult(String binaryResult) {
        this.binaryResult = binaryResult;
    }

    public String getOutputStream() {
        return outputStream;
    }

    public void setOutputStream(String outputStream) {
        this.outputStream = outputStream;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getCallBack() {
        return callBack;
    }

    public void setCallBack(String callBack) {
        this.callBack = callBack;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
}
