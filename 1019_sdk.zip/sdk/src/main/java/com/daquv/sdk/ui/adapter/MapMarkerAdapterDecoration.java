package com.daquv.sdk.ui.adapter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;

public class MapMarkerAdapterDecoration extends RecyclerView.ItemDecoration {
    private Paint paint;
    private Context context;

    public MapMarkerAdapterDecoration(Context context) {
        this.context = context;
        this.paint = new Paint();
        this.paint.setColor(ContextCompat.getColor(context, R.color.dqv_line));
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        super.getItemOffsets(outRect, view, parent, state);
        outRect.bottom = (int) context.getResources().getDimension(R.dimen.map_line_height);
    }

    @Override
    public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
        int left = parent.getPaddingStart();
        int right = parent.getWidth() - parent.getPaddingEnd();

        for (int i = 0; i < parent.getChildCount() - 1; i++) {
            View child = parent.getChildAt(i);
            RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child.getLayoutParams();

            float top = child.getBottom() + params.bottomMargin;
            float bottom = top + (int) context.getResources().getDimension(R.dimen.map_line_height);

            c.drawRect(left, top, right, bottom, paint);
        }
    }
}
