
package com.daquv.sdk.utils.search;

import java.util.Iterator;

public final class KoreanTextMatcher {

    private final String _pattern;
    private final boolean _foundStartAnchor, _foundEndAnchor;

    /**
     * {@link KoreanTextMatcher} 클래스의 새 인스턴스를 초기화한다.
     *
     * 정규식 앵커 {@code ^}와 {@code $}를 사용하여 {@code pattern}의 위치를
     * 검색 대상 문자열의 시작과 끝으로 한정할 수 있다.
     *
     * @param pattern 검색할 패턴
     * @throws IllegalArgumentException {@code pattern}이 {@code null}일 때.
     */
    public KoreanTextMatcher(String pattern) {
        if (pattern == null)
            throw new IllegalArgumentException("pattern: null");

        if (pattern.length() == 0) {
            _foundStartAnchor = _foundEndAnchor = false;
            _pattern = pattern;
        } else {
            _foundStartAnchor = pattern.charAt(0) == '^';
            _foundEndAnchor = pattern.charAt(pattern.length() - 1) == '$';
            _pattern = stripAnchors(pattern);
        }
    }

    /**
     * 주어진 {@code text}에 대해 {@link #KoreanTextMatcher(String)}에서 지정해 둔
     * {@code pattern}의 첫번째 출현을 찾는다.
     *
     * {@code text} 내 검색 시작 위치를 지정하려면 {@link #match(String, int)}를 사용한다.
     *
     * @param text 검색 대상 문자열
     * @return 검색 결과를 담은 {@link KoreanTextMatch} 인스턴스.
     *         {@link KoreanTextMatch#success()}가 {@code true}일 때만 유효하다.
     *         검색이 실패하면 {@link KoreanTextMatch#EMPTY}를 리턴한다.
     * @throws IllegalArgumentException {@code text}가 {@code null}일 때.
     */
    public KoreanTextMatch match(String text) {
        return match(text, 0);
    }

    /**
     * 주어진 {@code text}에 대해 {@link #KoreanTextMatcher(String)}에서 지정해 둔
     * {@code pattern}의 첫번째 출현을 찾는다.
     *
     * @param text 검색 대상 문자열
     * @param startIndex 검색을 시작할 {@code text} 내 위치
     * @return 검색 결과를 담은 {@link KoreanTextMatch} 인스턴스.
     *         {@link KoreanTextMatch#success()}가 {@code true}일 때만 유효하다.
     *         검색이 실패하면 {@link KoreanTextMatch#EMPTY}를 리턴한다.
     * @throws IllegalArgumentException {@code text}가 {@code null}일 때,
     *         또는 {@code startIndex}가 {@code 0}보다 작거나
     *         {@link KoreanTextMatch#length() text.length()}보다 클 때.
     */
    public KoreanTextMatch match(String text, int startIndex) {
        if (text == null)
            throw new IllegalArgumentException("text: null");
        if (startIndex < 0)
            throw new IllegalArgumentException("startIndex: " + startIndex + " < 0");
        if (startIndex > text.length())
            throw new IllegalArgumentException(
                String.format("startIndex: %d > text.length(): %d", startIndex, text.length()));

        //
        // Optimization: narrow the range of text to be matched for pattern.
        //
        final long textRange = getTextRange(text, _pattern.length(), startIndex);
        if (textRange == -1)
            return KoreanTextMatch.EMPTY;
        // textRange is a tuple of (int startIndex, int length).
        final int startIndexOpt = (int)(textRange >> 32);
        final int length = (int)(textRange & 0xFFFFFFF);
        if (length == 0)
            return new KoreanTextMatch(this, text, 0, 0);

        return match(text, startIndexOpt, length);
    }

    /**
     * 주어진 {@code text}에 대해 {@link #KoreanTextMatcher(String)}에서 지정해 둔
     * {@code pattern}의 모든 출현을 찾는다.
     *
     * {@code text} 내 검색 시작 위치를 지정하려면 {@link #matches(String, int)}를
     * 사용한다.
     *
     * @param text 검색 대상 문자열
     * @return 검색 결과를 담은 {@code Iterable<KoreanTextMatch>} 인스턴스.
     *         찾은 것이 없으면 빈 리스트를 리턴한다. 
     * @throws IllegalArgumentException {@code text}가 {@code null}일 때.
     */
    public Iterable<KoreanTextMatch> matches(String text) {
        return matches(text, 0);
    }

    /**
     * 주어진 {@code text}에 대해 {@link #KoreanTextMatcher(String)}에서 지정해 둔
     * {@code pattern}의 모든 출현을 찾는다.
     *
     * @param text 검색 대상 문자열
     * @param startIndex 검색을 시작할 {@code text} 내 위치
     * @return 검색 결과를 담은 {@code Iterable<KoreanTextMatch>} 인스턴스.
     * @throws IllegalArgumentException {@code text}가 {@code null}일 때,
     *         또는 {@code startIndex}가 {@code 0}보다 작거나
     *         {@link KoreanTextMatch#length() text.length()}보다 클 때.
     */
    public Iterable<KoreanTextMatch> matches(final String text, final int startIndex) {
        return new Iterable<KoreanTextMatch>() {
            public Iterator<KoreanTextMatch> iterator() {
                return new Iterator<KoreanTextMatch>() {
                    KoreanTextMatch match = match(text, startIndex);

                    @Override
                    public boolean hasNext() {
                        return match.success();
                    }

                    @Override
                    public KoreanTextMatch next() {
                        KoreanTextMatch result = match;
                        match = match.nextMatch();
                        return result;
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }
        };
    }

    private KoreanTextMatch match(String text, int startIndex, int length) {
        if (_pattern.length() == 0)
            return new KoreanTextMatch(this, text, 0, 0);

        for (int i = startIndex; i < startIndex + length - _pattern.length() + 1; i++) {
            for (int j = 0; j < _pattern.length(); j++) {
                if (!KoreanCharApproxMatcher.isMatch(text.charAt(i + j), _pattern.charAt(j)))
                    break;

                if (j == _pattern.length() - 1)
                    return new KoreanTextMatch(this, text, i, _pattern.length());
            }
        }
        return KoreanTextMatch.EMPTY;
    }

    /**
     * 주어진 {@code text} 내에 주어진 {@code pattern}이 존재하는지 여부를 조사한다.
     *
     * 정규식 앵커 {@code ^}와 {@code $}를 사용하여 {@code pattern}의 위치를
     * 검색 대상 문자열의 시작과 끝으로 한정할 수 있다.
     *
     * @param text 검색 대상 문자열
     * @param pattern 검색할 패턴
     * @return {@code text} 내에 {@code pattern}이 존재하면 {@code true},
     *         그렇지 않으면 {@code false}.
     * @throws IllegalArgumentException {@code text} 또는 {@code pattern}이
     *         {@code null}일 때.
     */
    public static boolean isMatch(String text, String pattern) {
        return match(text, pattern).success();
    }

    /**
     * 주어진 {@code text} 내에서 주어진 {@code pattern}의 첫번째 출현을 찾는다.
     *
     * 모든 출현을 찾으려면 {@link #matches(String, String)}를 사용한다.
     *
     * 정규식 앵커 {@code ^}와 {@code $}를 사용하여 {@code pattern}의 위치를
     * 검색 대상 문자열의 시작과 끝으로 한정할 수 있다.
     *
     * @param text 검색 대상 문자열
     * @param pattern 검색할 패턴
     * @return 검색 결과를 담은 {@link KoreanTextMatch} 인스턴스.
     *         {@link KoreanTextMatch#success()}가 {@code true}일 때만 유효하다.
     *         검색이 실패하면 {@link KoreanTextMatch#EMPTY}를 리턴한다.
     * @throws IllegalArgumentException {@code text} 또는 {@code pattern}이
     *         {@code null}일 때.
     */
    public static KoreanTextMatch match(String text, String pattern) {
        return new KoreanTextMatcher(pattern).match(text);
    }

    /**
     * 주어진 {@code text} 내에서 주어진 {@code pattern}의 모든 출현을 찾는다.
     *
     * 첫번째 출현만 찾으려면 {@link #match(String, String)}를 사용한다.
     *
     * 정규식 앵커 {@code ^}와 {@code $}를 사용하여 {@code pattern}의 위치를
     * 검색 대상 문자열의 시작과 끝으로 한정할 수 있다.
     *
     * @param text 검색 대상 문자열
     * @param pattern 검색할 패턴
     * @return 검색 결과를 담은 {@code Iterable<KoreanTextMatch>} 인스턴스.
     * @throws IllegalArgumentException {@code text} 또는 {@code pattern}이
     *         {@code null}일 때.
     */
    public static Iterable<KoreanTextMatch> matches(String text, String pattern) {
        return new KoreanTextMatcher(pattern).matches(text);
    }

    private String stripAnchors(String pattern) {
        if (!_foundStartAnchor && !_foundEndAnchor)
            return pattern;

        int startIndex = _foundStartAnchor ? 1 : 0;
        int length = pattern.length() - (_foundStartAnchor ? 1 : 0) - (_foundEndAnchor ? 1 : 0);
        return pattern.substring(startIndex, startIndex + length);
    }

    private long getTextRange(String text, int hintLength, int startIndex) {
        final boolean trimStart = _foundEndAnchor, trimEnd = _foundStartAnchor;

        int index = startIndex;
        int length = text.length() - index;

        if (length < hintLength)
            return -1;

        if (trimStart && trimEnd) {
            if (text.length() != hintLength)
                return -1;
        } else if (trimStart) {
            index = text.length() - hintLength;
            length = hintLength;
        } else if (trimEnd) {
            if (index != 0)
                return -1;
            length = hintLength;
        }
        return (long)index << 32 | length;
    }
}
