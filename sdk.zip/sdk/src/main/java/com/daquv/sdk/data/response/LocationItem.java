package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

public class LocationItem {

    @SerializedName("company_id")
    private int companyId;

    @SerializedName("latitude")
    private double latitude;

    @SerializedName("longitude")
    private double longitude;

    @SerializedName("distance")
    private double distance;

    @SerializedName("company_nm")
    private String companyNm;

    @SerializedName("ceo_nm")
    private String ceoNm;

    @SerializedName("tel")
    private String tel;

    @SerializedName("address")
    private String address;

    private boolean selected;



    public LocationItem() {
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    public String getCeoNm() {
        return ceoNm;
    }

    public void setCeoNm(String ceoNm) {
        this.ceoNm = ceoNm;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public int getCompanyId() {
        return companyId;
    }

    public void setCompanyId(int companyId) {
        this.companyId = companyId;
    }
}
