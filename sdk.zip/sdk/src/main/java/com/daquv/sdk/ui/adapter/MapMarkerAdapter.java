package com.daquv.sdk.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.LocationItem;

import java.util.ArrayList;

public class MapMarkerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<LocationItem> datas = new ArrayList<>();
    private final Context context;

    public interface OnItemClickListener {
        void onItemClick(View v, LocationItem data);
    }

    private OnItemClickListener listener = null;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public MapMarkerAdapter(Context ctx) {
        context = ctx;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflateView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_map, parent, false);
        return new DataHolder(inflateView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        LocationItem items = datas.get(position);
        if (holder instanceof DataHolder) {
            DataHolder dataHolder = (DataHolder) holder;
            dataHolder.name.setText(items.getCompanyNm());
            if (items.isSelected()) {
                dataHolder.container.setBackgroundColor(ContextCompat.getColor(context, R.color.dqv_list_select));
            } else {
                dataHolder.container.setBackgroundColor(ContextCompat.getColor(context, R.color.dqv_white));
            }
            dataHolder.navi.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setTag("navi");
                    if (listener != null) {
                        listener.onItemClick(v, items);
                    }
                }
            });
            dataHolder.container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setTag("container");
                    if (listener != null) {
                        listener.onItemClick(v, items);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    public void setDatas(ArrayList<LocationItem> datas) {
        this.datas = datas;
    }

    static class DataHolder extends RecyclerView.ViewHolder {
        LinearLayoutCompat container;
        TextView name;
        AppCompatImageView navi;

        DataHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.container);
            name = itemView.findViewById(R.id.name);
            navi = itemView.findViewById(R.id.navi);
        }
    }
}
