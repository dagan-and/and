package com.daquv.sdk.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.ui.adapter.FilterAdapter;
import com.daquv.sdk.ui.adapter.MapMarkerAdapter;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;
import java.util.Collections;

public class FilterBottomSheetDialog extends BottomSheetDialogFragment {

    private final Context context;
    private final ArrayList<String> listItem;
    private final String currentItem;

    public interface OnItemClickListener {
        void onItemClick(String data);
    }

    private final OnItemClickListener listener;

    public FilterBottomSheetDialog(Context context , ArrayList<String> listItem, String currentItem, OnItemClickListener listener) {
        this.context = context;
        this.listItem = listItem;
        this.currentItem = currentItem;
        this.listener = listener;
    }

    @Override
    public int getTheme() {
        return R.style.Theme_NoWiredStrapInNavigationBar;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_filter_bottom_sheet, container , false);

        FilterAdapter adapter = new FilterAdapter();
        RecyclerView recyclerView = view.findViewById(R.id.recyclerview);

        adapter.setDatas(listItem);
        adapter.setCurrentData(currentItem);
        adapter.setOnItemClickListener(new FilterAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View v, String data) {
                listener.onItemClick(data);
                dismiss();
            }
        });
        recyclerView.setAdapter(adapter);

        return view;
    }



}
