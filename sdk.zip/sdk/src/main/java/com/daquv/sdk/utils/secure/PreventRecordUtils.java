package com.daquv.sdk.utils.secure;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioRecordingConfiguration;
import android.media.MediaRecorder;
import android.os.Build;
import android.view.WindowManager;

import androidx.core.app.ActivityCompat;

import java.util.List;

public class PreventRecordUtils {

    private AudioManager audioManager;
    private AudioManager.AudioRecordingCallback audioRecordingCallback;
    private Context context;

    private boolean isAudioRecording = false;

    /**
     * Singleton Instance 반환
     *
     * @return Instance
     */
    public static PreventRecordUtils getInstance() {
        return PreventRecordUtils.LazyHolder.INSTANCE;
    }

    private static class LazyHolder {
        private static final PreventRecordUtils INSTANCE = new PreventRecordUtils();
    }

    /**
     *  3rd Party 에서 녹음(마이크)를 사용중인지 체크
     */
    public void init(Context mContext) {
        context = mContext;
        audioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioRecordingCallback = new AudioManager.AudioRecordingCallback() {
                @Override
                public void onRecordingConfigChanged(List<AudioRecordingConfiguration> configs) {
                    super.onRecordingConfigChanged(configs);
                    isAudioRecording = !configs.isEmpty();
                }
            };
        }
    }

    /**
     *  녹음(마이크) 상태값을 받는 리스너 등록
     */
    public void registerMicrophoneListener() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioManager.registerAudioRecordingCallback(audioRecordingCallback, null);
        }
    }

    /**
     *   녹음(마이크) 상태값을 받는 리스너 해제
     */
    public void unregisterMicrophoneListener() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioManager.unregisterAudioRecordingCallback(audioRecordingCallback);
        }
    }

    /**
     *  해당 화면에서 녹화,캡처를 방지하는 Flag 추가
     * @param mActivity
     */
    public void setSecureFlag(Activity mActivity) {
        mActivity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    /**
     * 음성 녹음 중인지 확인하기
     */
    public boolean isAudioRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return isAudioRecording;
        } else {
            AudioRecord audioRecord = getAudioRecorder();
            if(audioRecord != null) {
                try {
                    audioRecord.startRecording();
                } catch (Exception e) {
                    return true;
                } finally {
                    audioRecord.release();
                }
            }
        }
        return false;
    }


    private AudioRecord getAudioRecorder() {
        final int[] sampleRateCandidates = new int[]{16000, 22050, 44100, 11025};
        final int CHANNEL = AudioFormat.CHANNEL_IN_MONO;
        final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;

        for (int sampleRate : sampleRateCandidates) {
            final int sizeInBytes = AudioRecord.getMinBufferSize(sampleRate, CHANNEL, ENCODING);
            if (sizeInBytes == AudioRecord.ERROR_BAD_VALUE) {
                continue;
            }
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                final AudioRecord audioRecord = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        sampleRate, CHANNEL, ENCODING, sizeInBytes);

                if (audioRecord.getState() == AudioRecord.STATE_INITIALIZED) {
                    return audioRecord;
                } else {
                    audioRecord.release();
                }
            }
        }
        return null;
    }
}
