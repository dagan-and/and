package com.daquv.sdk.presentation;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.airbnb.lottie.LottieAnimationView;
import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.webview.ComWebView;

public class VoiceFragment extends Fragment {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    DaquvEngine.Callback engineCallback;

    private TextView sttText;
    private LottieAnimationView icon;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_voice , container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sttText = view.findViewById(R.id.title);
        icon = view.findViewById(R.id.icon);
        listening();
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);

                if(code == DaquvConfig.CODE.API_NLU_FAIL ) {
                    sttText.setText((String) result);
                    sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
                    icon.setImageResource(R.drawable.img_error);
                }

                if(code == DaquvConfig.CODE.API_NLU_REASK) {
                    sttText.setText((String) result);
                    sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
                    icon.setImageResource(R.drawable.img_error_question);
                }

                if(code == DaquvConfig.CODE.API_ERROR) {
                    if(result instanceof ErrorData) {
                        Toast.makeText(getContext(), ((ErrorData) result).getMsg(), Toast.LENGTH_SHORT).show();
                    }
                }

                if(code == DaquvConfig.CODE.ENGINE_RUNNING_DATA) {
                    sttText.setText((String) result);
                }

                if(code == DaquvConfig.CODE.ENGINE_FINAL_DATA) {
                    sttText.setText((String) result);
                    sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_iris));
                    icon.setAnimation(R.raw.main_mic_complete);
                    icon.playAnimation();
                }

                if (code == DaquvConfig.CODE.ENGINE_START_VOICE) {
                    sttText.setText("");
                    sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
                }

                if(code == DaquvConfig.CODE.ENGINE_ERROR_VOICE) {
                    ErrorData errorData = (ErrorData) result;
                    Toast.makeText(requireContext(), errorData.getCode() + "::" + errorData.getMsg(), Toast.LENGTH_SHORT).show();
                }

                if(code == DaquvConfig.CODE.ENGINE_FINISH_TTS) {
                    if(result instanceof TTSResponse) {
                        if ((((TTSResponse) result).getCode() == DaquvConfig.CODE.API_NLU_FAIL)) {
                            listening();
                        }
                    }
                }
            }
        };
        DaquvSDK.getInstance().addCallBack(engineCallback);
    }

    private void listening() {
        sttText.setText(getContext().getString(R.string.stt_listening));
        sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
        icon.setAnimation(R.raw.main_mic);
        icon.playAnimation();
        DaquvSDK.getInstance().getEngine().startEngine();
    }

    @Override
    public void onStop() {
        DaquvSDK.getInstance().stopTTS();
        DaquvSDK.getInstance().getEngine().stopEngine();
        super.onStop();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        onBackPressedCallback.remove();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
    }
}
