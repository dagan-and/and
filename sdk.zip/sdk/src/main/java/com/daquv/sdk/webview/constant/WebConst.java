package com.daquv.sdk.webview.constant;

public class WebConst {

    public static class WebAction {

        /** JavascriptInterface Bridge 명 */
        public final static String INTERFACE_NAME = "BrowserBridge";

        // 공통 Action JSON KEY
        /** _action_code JSON KEY */
        public final static String KEY_ACTION_CODE	= "_action_code";
        /** _action_data JSON KEY */
        public final static String KEY_ACTION_DATA	= "_action_data";
        /** _action_uuid JSON KEY */
        public final static String KEY_ACTION_UUID = "_action_uuid";
    }
}
