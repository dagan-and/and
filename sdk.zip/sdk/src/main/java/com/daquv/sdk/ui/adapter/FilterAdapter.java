package com.daquv.sdk.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.LocationItem;

import java.util.ArrayList;

public class FilterAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {


    private ArrayList<String> datas = new ArrayList<>();
    private String currentData = null;

    public interface OnItemClickListener {
        void onItemClick(View v, String data);
    }

    private OnItemClickListener listener = null;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public FilterAdapter() {

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflateView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_filter, parent, false);
        return new DataHolder(inflateView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        String items = datas.get(position);
        if (holder instanceof DataHolder) {
            DataHolder dataHolder = (DataHolder) holder;
            dataHolder.name.setText(items);
            if (items.equals(currentData)) {
                dataHolder.check.setVisibility(View.VISIBLE);
            } else {
                dataHolder.check.setVisibility(View.INVISIBLE);
            }
            dataHolder.container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setTag("container");
                    if (listener != null) {
                        listener.onItemClick(v, items);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    public void setDatas(ArrayList<String> datas) {
        this.datas = datas;
    }

    public void setCurrentData(String currentData) {
        this.currentData = currentData;
    }

    static class DataHolder extends RecyclerView.ViewHolder {
        LinearLayoutCompat container;
        TextView name;
        AppCompatImageView check;

        DataHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.container);
            name = itemView.findViewById(R.id.name);
            check = itemView.findViewById(R.id.check);
        }
    }
}
