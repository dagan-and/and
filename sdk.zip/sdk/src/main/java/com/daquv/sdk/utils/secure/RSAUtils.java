package com.daquv.sdk.utils.secure;



import com.daquv.sdk.utils.Logger;

import org.jetbrains.annotations.NotNull;

import java.math.BigInteger;
import java.security.Key;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.KeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.util.Locale;

import javax.crypto.Cipher;

import kotlin.text.Charsets;


public class RSAUtils {

    private static String byteToHexString(byte[] byteArray) {
        StringBuilder sb = new StringBuilder(byteArray.length * 2);
        for (byte b : byteArray) {
            String var11 = String.format("%02x", b);
            sb.append(var11.toUpperCase(Locale.getDefault()));
        }
        return sb.toString();
    }

    public static String getEncryptRSA(@NotNull String mModulus, @NotNull String mExponent, @NotNull String encData) {

        try {
            String resData;
            BigInteger modulus = new BigInteger(mModulus, 16);
            BigInteger exponent = new BigInteger(mExponent, 16);
            RSAPublicKeySpec publicSpec = new RSAPublicKeySpec(modulus, exponent);
            PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic((KeySpec)publicSpec);
            String publicKeyModulus = publicSpec.getModulus().toString(16);
            String publicKeyExponent = publicSpec.getPublicExponent().toString(16);

            Logger.dev("publicKey: " + publicKey);
            Logger.dev("publicKeyModulus: " + publicKeyModulus);
            Logger.dev("publicKeyExponent: " + publicKeyExponent);
            byte[] vEncData = encryptHex(encData, publicKey);
            resData = byteToHexString(vEncData);
            Logger.dev("encData: " + resData);
            return resData;
        } catch (Exception var12) {
            Logger.error(var12);
            return null;
        }
    }

    private static byte[] encryptHex(String plaintext, PublicKey publicKey) {
        Cipher cipher = null;
        try {
            cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, (Key)publicKey);
            byte[] var10001 = plaintext.getBytes(Charsets.UTF_8);
            return cipher.doFinal(var10001);
        } catch (Exception e) {
            Logger.error(e);
        }
        return null;
    }
}
