package com.daquv.sdk.presentation;

import static android.content.Context.LOCATION_SERVICE;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.airbnb.lottie.LottieAnimationView;
import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.LocationItemResponse;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.ui.SpeakerView;
import com.daquv.sdk.utils.AudioFileRecorder;
import com.daquv.sdk.utils.AudioFileRecorder2;
import com.daquv.sdk.utils.DaquvUtil;

import java.util.List;
import java.util.Objects;

public class DaquvView extends ConstraintLayout implements View.OnClickListener {

    public DaquvView(@NonNull Context context) {
        super(context);
    }

    public DaquvView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public DaquvView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public DaquvView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    public interface ViewListener{
        void onAttached();
        void onDetached();
    }

    interface FragmentListener{
        void onBackPress();
        void addMainView();
        void addDataView();
        void addMapView(LocationItemResponse items);
        void addKeypadView();
        void showLoading();
        void hideLoading();
        void startSTT();
    }

    RelativeLayout loadingView;
    FrameLayout bottomContainer;
    FrameLayout mainView;
    FragmentManager fragmentManager;
    FragmentListener listener;
    DaquvEngine.Callback sdkCallback;
    LottieAnimationView micView;
    LottieAnimationView loadingImage;
    ViewListener viewListener;

    public void init(FragmentManager fragmentManager) {
        if(!DaquvSDK.getInstance().checkPermission(getContext())) {
            return;
        }
        this.fragmentManager = fragmentManager;

        initView();
        setVisibility(View.VISIBLE);
        setBackgroundColor(ContextCompat.getColor(getContext() ,R.color.dqv_white));

        DaquvSDK.getInstance().getAPI().getMainPage(DaquvUtil.getUrl("/webview/ibkCrm/v1/company/main"));

        sdkCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);
                if(code == DaquvConfig.CODE.API_MAIN_DATA) {
                    listener.addMainView();
                    if(viewListener != null) {
                        viewListener.onAttached();
                    }
                }

                if(code == DaquvConfig.CODE.API_NLU_SUCCESS) {
                    listener.hideLoading();
                    listener.addDataView();
                }

                if(code == DaquvConfig.CODE.API_NLU_FAIL) {
                    listener.hideLoading();
                }

                if(code == DaquvConfig.CODE.API_NLU_REASK) {
                    listener.hideLoading();
                }

                if(code == DaquvConfig.CODE.API_NLU_MAP) {
                    if(result instanceof LocationItemResponse &&
                            ((LocationItemResponse) result).getBody() != null &&
                            ((LocationItemResponse) result).getCount() > 0) {
                        listener.addMapView(((LocationItemResponse) result));
                    } else {
                        NLUResultResponse nluResultResponse = new NLUResultResponse();
                        nluResultResponse.setTts("조회 할 수 있는 기업이 없습니다.");
                        DaquvSDK.getInstance().getAPI().getFailPage(nluResultResponse);
                    }
                }

                if(code == DaquvConfig.CODE.ENGINE_FINAL_DATA) {
                    listener.showLoading();
                }

                if(code == DaquvConfig.CODE.ENGINE_START_VOICE) {
                    micView.setSpeed(2f);
                    micView.playAnimation();
                }

                if(code == DaquvConfig.CODE.ENGINE_STOP_VOICE) {
                    micView.setAnimation(R.raw.main_mic);
                    micView.pauseAnimation();
                }

                if(code == DaquvConfig.CODE.ENGINE_FINISH_TTS) {
                    if(result instanceof TTSResponse) {
                        if ((((TTSResponse) result).getCode() == DaquvConfig.CODE.API_NLU_REASK)) {
                            micView.callOnClick();
                        }
                    }
                }

                if(code == DaquvConfig.CODE.API_ERROR) {
                    if(result instanceof ErrorData) {
                        Toast.makeText(getContext(), ((ErrorData) result).getMsg(), Toast.LENGTH_SHORT).show();
                    }
                    listener.hideLoading();
                }
            }
        };

        listener = new FragmentListener() {
            @Override
            public void onBackPress() {
                if(fragmentManager.getFragments().size() > 1) {
                    fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
                } else if(!Objects.equals(fragmentManager.getFragments().get(0).getTag(), "Main")) {
                    addMainView();
                } else {
                    onDestroy();
                }
            }

            @Override
            public void addMainView() {
                MainFragment data = new MainFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(mainView.getId(), data, "Main")
                        .commitAllowingStateLoss();
                bottomContainer.setVisibility(View.VISIBLE);
            }

            @Override
            public void addDataView() {
                DataFragment data = new DataFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left, 0, 0);
                fragmentTransaction.replace(mainView.getId(), data , "Data")
                        .commitAllowingStateLoss();
            }

            @Override
            public void addMapView(LocationItemResponse response) {
                if(!Objects.equals(fragmentManager.getFragments().get(0).getTag(), "Map")) {
                    MapFragment data = new MapFragment();
                    data.setListener(listener);
                    data.setLocationItem(response.getBody());

                    Location location = new Location(DaquvSDK.getInstance().getLocation());
                    location.setLatitude(response.getLatitude());
                    location.setLongitude(response.getLongitude());
                    data.setLocation(location);

                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.setCustomAnimations(R.anim.slide_in_right, R.anim.slide_out_left, 0, 0);
                    fragmentTransaction.replace(mainView.getId(), data , "Map")
                            .commitAllowingStateLoss();
                    bottomContainer.setVisibility(View.GONE);
                }
            }

            @Override
            public void addKeypadView() {
                KeyPadFragment data = new KeyPadFragment();
                data.setListener(listener);

                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.setCustomAnimations(R.anim.keyapd_slide_up, R.anim.slide_out_left, 0, 0);
                fragmentTransaction.add(mainView.getId(), data, "KeyPad")
                        .addToBackStack(null)
                        .commitAllowingStateLoss();
            }

            @Override
            public void showLoading() {
                loadingView.setVisibility(View.VISIBLE);
                loadingImage.setAnimation(R.raw.v3_loading);
                loadingImage.playAnimation();
            }

            @Override
            public void hideLoading() {
                loadingView.setVisibility(View.GONE);
                loadingImage.pauseAnimation();
            }

            @Override
            public void startSTT() {
                micView.callOnClick();
            }
        };
        DaquvSDK.getInstance().addCallBack(sdkCallback);
    }

    public void setViewListener(ViewListener viewListener) {
        this.viewListener = viewListener;
    }


    public void onDestroy() {
        if(viewListener != null) {
            viewListener.onDetached();
        } else {
            clearStack();
            setVisibility(View.GONE);
        }
        DaquvSDK.getInstance().removeCallBack(sdkCallback);
    }

    AudioFileRecorder2 audioFileRecorder = new AudioFileRecorder2(getContext());

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.micView) {
            if(DaquvSDK.getInstance().getEngine().isRunning()) {
                DaquvSDK.getInstance().getEngine().stopEngine();
            } else {
                DaquvSDK.getInstance().getEngine().startEngine();
            }
        } else if(view.getId() == R.id.keypadView) {
            DaquvSDK.getInstance().getEngine().stopEngine();
            listener.addKeypadView();

            //지도기능 사용하는지 체크
            //getLocation 널체크
//            LocationManager locationManager = (LocationManager) getContext().getSystemService(LOCATION_SERVICE);
//            if(locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
//                DaquvSDK.getInstance().getAPI().getMapData(String.valueOf(DaquvSDK.getInstance().getLocation().getLatitude()),
//                        String.valueOf(DaquvSDK.getInstance().getLocation().getLongitude()),
//                        "10000");
//            } else {
//                Toast.makeText(getContext(), "GPS 기능을 활성화 해주세요.", Toast.LENGTH_SHORT).show();
//            }
//
//            if(audioFileRecorder.isRecording()) {
//                Toast.makeText(getContext(), "녹음종료", Toast.LENGTH_SHORT).show();
//                audioFileRecorder.stopRecording();
//            } else {
//                Toast.makeText(getContext(), "녹음시작", Toast.LENGTH_SHORT).show();
//                audioFileRecorder.startRecording();
//            }
        }
    }

    private void initView() {

        mainView = new FrameLayout(getContext());
        mainView.setId(R.id.mainView);
        ConstraintLayout.LayoutParams mainViewParams = new ConstraintLayout.LayoutParams(
                0, 0
        );
        mainViewParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        mainViewParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        mainViewParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        mainViewParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
        mainView.setLayoutParams(mainViewParams);
        addView(mainView);

        bottomContainer = new FrameLayout(getContext());
        bottomContainer.setId(R.id.bottom_container);
        ConstraintLayout.LayoutParams bottomContainerParams = new ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        bottomContainerParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomContainerParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomContainerParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        bottomContainerParams.setMargins(
                getResources().getDimensionPixelOffset(R.dimen.view_side_margin),
                0,
                getResources().getDimensionPixelOffset(R.dimen.view_side_margin),
                getResources().getDimensionPixelOffset(R.dimen.view_side_margin)
        );
        bottomContainer.setBackgroundResource(R.drawable.bottom_icon_background_on);
        bottomContainer.setLayoutParams(bottomContainerParams);
        addView(bottomContainer);

        ConstraintLayout bottomLayout = new ConstraintLayout(getContext());
        FrameLayout.LayoutParams bottomLayoutParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        bottomLayout.setPadding(
                0,
                0,
                0,
                0
        );
        bottomLayout.setLayoutParams(bottomLayoutParams);
        bottomContainer.addView(bottomLayout);

        micView = new LottieAnimationView(getContext());
        micView.setId(R.id.micView);
        micView.setAnimation(R.raw.main_mic);
        micView.setRepeatCount(ValueAnimator.INFINITE);
        micView.setVisibility(View.VISIBLE);
        ConstraintLayout.LayoutParams micViewParams = new ConstraintLayout.LayoutParams(
                DaquvUtil.convertDPtoPX(getContext(), 100),
                DaquvUtil.convertDPtoPX(getContext(), 100)
        );
        micViewParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        micViewParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        micViewParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        micViewParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
        micView.setLayoutParams(micViewParams);
        micView.setOnClickListener(this);
        bottomLayout.addView(micView);

        AppCompatImageView closeView = new AppCompatImageView(getContext());
        closeView.setId(R.id.closeView);
        closeView.setImageResource(R.drawable.btn_stt_close);
        closeView.setVisibility(View.GONE);
        ConstraintLayout.LayoutParams closeViewParams = new ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        closeViewParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        closeViewParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        closeViewParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        closeViewParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
        closeView.setLayoutParams(closeViewParams);
        closeView.setOnClickListener(this);
        bottomLayout.addView(closeView);

        AppCompatTextView keypadView = new AppCompatTextView(getContext());
        keypadView.setId(R.id.keypadView);
        keypadView.setText(R.string.button_keypad);
        keypadView.setTextColor(getResources().getColor(R.color.dqv_text_base));
        Drawable keypadDrawable = getResources().getDrawable(R.drawable.btn_main_keypad);
        keypadView.setCompoundDrawablesWithIntrinsicBounds(null, keypadDrawable, null, null);
        keypadView.setCompoundDrawablePadding(getResources().getDimensionPixelOffset(R.dimen.keypad_padding));
        ConstraintLayout.LayoutParams keypadViewParams = new ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        keypadViewParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        keypadViewParams.leftToRight = R.id.micView;
        keypadViewParams.rightToRight = ConstraintLayout.LayoutParams.PARENT_ID;
        keypadViewParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
        keypadView.setLayoutParams(keypadViewParams);
        keypadView.setOnClickListener(this);
        bottomLayout.addView(keypadView);

        SpeakerView speakerView = new SpeakerView(getContext());
        speakerView.setId(R.id.speakerView);
        ConstraintLayout.LayoutParams speakerViewParams = new ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        speakerViewParams.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        speakerViewParams.leftToLeft = ConstraintLayout.LayoutParams.PARENT_ID;
        speakerViewParams.rightToLeft = R.id.micView;
        speakerViewParams.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
        speakerView.setLayoutParams(speakerViewParams);
        bottomLayout.addView(speakerView);

        loadingView = new RelativeLayout(getContext());
        loadingView.setId(R.id.loadingView);
        loadingView.setVisibility(View.GONE);
        loadingView.setBackgroundColor(ContextCompat.getColor(getContext() , R.color.dqv_dim));
        ConstraintLayout.LayoutParams loadingViewParams = new ConstraintLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        );
        loadingView.setLayoutParams(loadingViewParams);

        loadingImage = new LottieAnimationView(getContext());
        loadingImage.setAnimation(R.raw.v3_loading);
        loadingImage.setRepeatCount(ValueAnimator.INFINITE);
        RelativeLayout.LayoutParams loadingImageParams = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        loadingImageParams.addRule(RelativeLayout.CENTER_IN_PARENT, RelativeLayout.TRUE);
        loadingImage.setLayoutParams(loadingImageParams);
        loadingView.addView(loadingImage);
        addView(loadingView);
    }

    public void clearStack() {
        int backStackEntry = fragmentManager.getBackStackEntryCount();
        if (backStackEntry > 0) {
            for (int i = 0; i < backStackEntry; i++) {
                fragmentManager.popBackStackImmediate();
            }
        }
        if (fragmentManager.getFragments().size() > 0) {
            List<Fragment> fragments = fragmentManager.getFragments();
            for (Fragment fragment : fragments) {
                if (fragment != null) {
                    fragmentManager.beginTransaction().remove(fragment).commit();
                }
            }
        }
    }
}
