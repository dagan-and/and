package com.daquv.sdk.data.request;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.utils.network.TranJson;

public class LoginRequest extends TranJson {

    public LoginRequest(String... info) {
        super();
        put("email", info[0]);
        if(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service) {
            put("emn", info[1]);
        } else {
            put("password", info[1]);
        }
        put("companyId", info[2]);

        if(DaquvConfig.SERVICE.POSCO == DaquvConfig.service) {
            put("empId", info[3]);
        }
    }
}