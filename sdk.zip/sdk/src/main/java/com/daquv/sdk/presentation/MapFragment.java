package com.daquv.sdk.presentation;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.data.response.LocationItemResponse;
import com.daquv.sdk.ui.FilterBottomSheetDialog;
import com.daquv.sdk.ui.MapBottomSheetView;
import com.daquv.sdk.utils.Logger;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.geometry.LatLngBounds;
import com.naver.maps.map.CameraPosition;
import com.naver.maps.map.MapView;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.NaverMapOptions;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.Overlay;
import com.naver.maps.map.overlay.OverlayImage;
import com.naver.maps.map.util.MarkerIcons;

import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class MapFragment extends Fragment implements OnMapReadyCallback, Overlay.OnClickListener {

    DaquvEngine.Callback engineCallback;
    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;

    private String currentRadius;
    private String currentType = "전체";
    private final ArrayList<String> radius = new ArrayList<>();
    private final ArrayList<String> type = new ArrayList<>();
    private final ArrayList<Marker> markers = new ArrayList<>();
    private ArrayList<LocationItem> locationItem;
    private Location location;
    private NaverMap naverMap;
    private MapView mapView;
    private Marker positionMarker;
    private Marker selectMarker;
    private View bottomSheetContainer;
    private MapBottomSheetView bottomSheetView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_map, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        bottomSheetContainer = view.findViewById(R.id.bottom_sheet);

        NaverMapOptions options = new NaverMapOptions()
                .camera(new CameraPosition(new LatLng(location.getLatitude(), location.getLongitude()), DaquvConfig.defaultZoom))
                .mapType(NaverMap.MapType.Basic);

        FrameLayout mapContainer = view.findViewById(R.id.map_container);
        mapView = new MapView(requireContext(), options);
        mapContainer.addView(mapView);

        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);
        setBottomSheetView();

        radius.addAll(DaquvConfig.appConfig.mapInfo.filterRadius);
        type.addAll(DaquvConfig.appConfig.mapInfo.filterType);
        currentRadius = DaquvConfig.searchRadius;
    }

    public void setLocationItem(ArrayList<LocationItem> item) {
        this.locationItem = item;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);
                if (code == DaquvConfig.CODE.API_NLU_MAP) {
                    if (result instanceof LocationItemResponse &&
                            ((LocationItemResponse) result).getBody() != null &&
                            ((LocationItemResponse) result).getCount() > 0) {

                        setLocationItem(((LocationItemResponse) result).getBody());

                        Location location = new Location(DaquvSDK.getInstance().getLocation());
                        location.setLatitude(((LocationItemResponse) result).getLatitude());
                        location.setLongitude(((LocationItemResponse) result).getLongitude());
                        setLocation(location);

                        initMarker();
                    } else {
                        locationItem.clear();
                        initMarker();
                    }
                }
            }
        };

        DaquvSDK.getInstance().addCallBack(engineCallback);

        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
        onBackPressedCallback.remove();
    }


    public boolean runKakaoMap(LocationItem data) {
        try {
            String scheme = DaquvConfig.appConfig.mapInfo.scheme.kakao;
            scheme = scheme.replace("$latitude", String.valueOf(data.getLatitude()));
            scheme = scheme.replace("$longitude", String.valueOf(data.getLongitude()));
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            startActivity(intent);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean runTMap(LocationItem data) {
        try {
            String scheme = DaquvConfig.appConfig.mapInfo.scheme.tmap;
            scheme = scheme.replace("$latitude", String.valueOf(data.getLatitude()));
            scheme = scheme.replace("$longitude", String.valueOf(data.getLongitude()));
            scheme = scheme.replace("$title", data.getCompanyNm());
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            startActivity(intent);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean runNaverMap(LocationItem data) {
        try {
            String str = URLEncoder.encode(data.getCompanyNm(), "UTF-8");
            String scheme = DaquvConfig.appConfig.mapInfo.scheme.naver;
            scheme = scheme.replace("$latitude", String.valueOf(data.getLatitude()));
            scheme = scheme.replace("$longitude", String.valueOf(data.getLongitude()));
            scheme = scheme.replace("$title", str);
            scheme = scheme.replace("$package", requireContext().getPackageName());
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            startActivity(intent);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    @Override
    public boolean onClick(Overlay p0) {
        //기존에 선택한 마커 초기화
        for(Marker marker : markers) {
            marker.setIcon(OverlayImage.fromResource(R.drawable.default_marker));
            marker.setIconTintColor(Color.TRANSPARENT);
        }

        //선택한 마커 포커스 및 설정
        Marker marker = (Marker) p0;
        marker.setIcon(MarkerIcons.BLACK);
        marker.setIconTintColor(Color.RED);

        selectMarker = marker;

        bottomSheetView.setSelectItem((int) p0.getTag());
        return false;
    }

    @Override
    public void onMapReady(NaverMap naverMap) {
        this.naverMap = naverMap;
        Logger.dev("onMapReady");

        //맵 Zoom Level 지정
        naverMap.setMinZoom(DaquvConfig.minZoom);
        naverMap.setMaxZoom(DaquvConfig.maxZoom);

        //맵 범위 지정
        double bundary = 0.1;
        naverMap.setExtent(new LatLngBounds(
                new LatLng(cutplaces(location.getLatitude()) - bundary, cutplaces(location.getLongitude()) - bundary),
                new LatLng(cutplaces(location.getLatitude()) + bundary, cutplaces(location.getLongitude()) + bundary)
        ));

        //지도뷰 선택 리스너
        naverMap.addOnCameraChangeListener(new NaverMap.OnCameraChangeListener() {
            @Override
            public void onCameraChange(int i, boolean b) {
                if (bottomSheetView.isStateExpanded()) {
                    bottomSheetView.collapseView();
                }
            }
        });

        //카메라 전환 리스너 등록
        naverMap.addOnCameraIdleListener(new NaverMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {

                positionMarker.setPosition(new LatLng(naverMap.getCameraPosition().target.latitude,
                        naverMap.getCameraPosition().target.longitude));

                DaquvSDK.getInstance().getAPI().getMapData(String.valueOf(naverMap.getCameraPosition().target.latitude),
                        String.valueOf(naverMap.getCameraPosition().target.longitude),
                        currentRadius);
            }
        });

        //맵 중앙 위치 표시
        positionMarker = new Marker();
        positionMarker.setPosition(new LatLng(location.getLatitude(), location.getLongitude()));
        positionMarker.setIcon(OverlayImage.fromResource(R.drawable.position_marker));
        positionMarker.setMap(naverMap);

        initMarker();
    }

    public void initMarker() {
        if (markers.size() > 0) {
            for (Marker marker : markers) {
                marker.setMap(null);
            }
        }
        markers.clear();

        boolean containSelectMarker = false;
        for (LocationItem item : locationItem) {
            if (item.getLatitude() > 10 && item.getLongitude() > 10) {
                Marker marker = new Marker();
                if (selectMarker != null && selectMarker.getTag() != null &&
                        selectMarker.getTag().equals(item.getCompanyId())) {
                    marker.setIcon(MarkerIcons.BLACK);
                    marker.setIconTintColor(Color.RED);
                    item.setSelected(true);
                    containSelectMarker = true;
                } else {
                    marker.setIcon(OverlayImage.fromResource(R.drawable.default_marker));
                    marker.setIconTintColor(Color.TRANSPARENT);
                    item.setSelected(false);
                }

                marker.setPosition(new LatLng(item.getLatitude(), item.getLongitude()));
                marker.setCaptionText(item.getCompanyNm());
                marker.setMap(naverMap);
                marker.setTag(item.getCompanyId());
                marker.setOnClickListener(this);
                markers.add(marker);
            }
        }
        if(!containSelectMarker) {
            selectMarker = null;
        }
        bottomSheetView.updateItem(locationItem, currentRadius, currentType);
    }

    public double cutplaces(double number) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        String formattedNumber = decimalFormat.format(number);
        return Double.parseDouble(formattedNumber);
    }

    private void setBottomSheetView() {
        bottomSheetView = new MapBottomSheetView(requireContext(),
                bottomSheetContainer,
                locationItem,
                currentRadius,
                currentType,
                new MapBottomSheetView.OnStateListener() {
                    @Override
                    public void onStateChanged(int newState) {
                        Logger.dev("onStateChanged::" + newState);
                    }

                    @Override
                    public void onItemClick(String tag, LocationItem data) {
                        if (tag.equals("navi")) {
                            if (!runTMap(data)) {
                                if (!runNaverMap(data)) {
                                    if (!runKakaoMap(data)) {
                                        Toast.makeText(requireContext(), "네비게이션을 실행할 앱이 없습니다.", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        } else if (tag.equals("container")) {
                            //답변화면 이동
                            Toast.makeText(getContext(), "기업정보 화면으로 이동 개발중", Toast.LENGTH_SHORT).show();
                        } else if (tag.equals("Radius")) {
                            bottomSheetView.collapseView();
                            FilterBottomSheetDialog bottomSheetFragment = new FilterBottomSheetDialog(getContext(),
                                    radius,
                                    currentRadius,
                                    data1 -> {
                                        currentRadius = data1;
                                        DaquvSDK.getInstance().getAPI().getMapData(String.valueOf(naverMap.getCameraPosition().target.latitude),
                                                String.valueOf(naverMap.getCameraPosition().target.longitude),
                                                currentRadius);
                                    });
                            bottomSheetFragment.show(getParentFragmentManager(), "Filter");
                        } else if  (tag.equals("Type")) {
                            bottomSheetView.collapseView();
                            FilterBottomSheetDialog bottomSheetFragment = new FilterBottomSheetDialog(getContext(),
                                    type,
                                    currentType,
                                    data1 -> {
                                        currentRadius = data1;
                                        DaquvSDK.getInstance().getAPI().getMapData(String.valueOf(naverMap.getCameraPosition().target.latitude),
                                                String.valueOf(naverMap.getCameraPosition().target.longitude),
                                                currentRadius);
                                    });
                            bottomSheetFragment.show(getParentFragmentManager(), "Filter");
                        }
                    }
                });
    }

    @Override
    public void onStart() {
        super.onStart();
        mapView.onStart();
    }


    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    public void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }


}
