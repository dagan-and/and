package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class LoginTokenResponse  implements Serializable {

    @SerializedName("userInfo")
    private UserInfo userInfo;

    @SerializedName("companyInfoDto")
    private CompanyInfo companyInfo;

    @SerializedName("email")
    private String email;

    @SerializedName("companyId")
    private String companyId;

    @SerializedName("cmmncId")
    private String cmmncId;

    @SerializedName("emn")
    private String emn;

    @SerializedName("pnmnBrcd")
    private String pnmnBrcd;

    @SerializedName("jwtToken")
    private String token;


    public UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public CompanyInfo getCompanyInfo() {
        return companyInfo;
    }

    public void setCompanyInfo(CompanyInfo companyInfo) {
        this.companyInfo = companyInfo;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCmmncId() {
        return cmmncId;
    }

    public void setCmmncId(String cmmncId) {
        this.cmmncId = cmmncId;
    }

    public String getEmn() {
        return emn;
    }

    public void setEmn(String emn) {
        this.emn = emn;
    }

    public String getPnmnBrcd() {
        return pnmnBrcd;
    }

    public void setPnmnBrcd(String pnmnBrcd) {
        this.pnmnBrcd = pnmnBrcd;
    }
}
