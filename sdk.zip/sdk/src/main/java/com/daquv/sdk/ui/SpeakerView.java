package com.daquv.sdk.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.SharedPref;

public class SpeakerView extends AppCompatTextView {
    private long mLastClickTime = 0L;

    public SpeakerView(Context context) {
        super(context);
        init();
    }

    public SpeakerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setGravity(Gravity.CENTER);
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f);
        setCompoundDrawablePadding(DaquvUtil.convertDPtoPX(getContext(), 8));
        updateView();
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (SystemClock.elapsedRealtime() - mLastClickTime > 500) {
                    toggle();
                }
                mLastClickTime = SystemClock.elapsedRealtime();
            }
        });

        setOnLongClickListener(new OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                String message = getContext().getString(R.string.tts_on_stop);
                updateView();
                Toast.makeText(v.getContext(), message, Toast.LENGTH_SHORT).show();
                DaquvSDK.getInstance().stopTTS();
                return true;
            }
        });
    }

    public void toggle() {
        boolean isSpeaker = SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, true);
        String message = isSpeaker ? getContext().getString(R.string.tts_on_voice) : getContext().getString(R.string.tts_on_speaker);

        SharedPref.getInstance().put(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, !isSpeaker);
        DaquvSDK.getInstance().setSpeakerMode(!isSpeaker);
        updateView();
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }

    public void updateView() {
        boolean isSpeaker = SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, true);
        if (isSpeaker) {
            setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.btn_main_speaker_on, 0, 0);
            setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_iris));
            setText(getContext().getString(R.string.tts_speaker));
            setTypeface(null, Typeface.BOLD);
        } else {
            setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.btn_main_speaker_off, 0, 0);
            setTextColor(ContextCompat.getColor(getContext(), R.color.dqv_off));
            setText(getContext().getString(R.string.tts_voice));
            setTypeface(null, Typeface.NORMAL);
        }
    }
}
