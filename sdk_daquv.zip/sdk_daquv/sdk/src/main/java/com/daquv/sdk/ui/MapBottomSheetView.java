package com.daquv.sdk.ui;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.ui.adapter.MapMarkerAdapter;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.util.ArrayList;
import java.util.Collections;

public class MapBottomSheetView {
    public interface OnStateListener {
        void onStateChanged(int newState);
        void onItemClick(String tag, LocationItem data);
    }

    private final Context context;
    private ArrayList<LocationItem> listItem;
    private final OnStateListener listener;
    private final LockableBottomSheetBehavior<View> bottomSheetView;
    private final MapMarkerAdapter adapter;
    private final RecyclerView recyclerView;
    private final TextView filter;

    public MapBottomSheetView(Context context,
                              View view,
                              ArrayList<LocationItem> listItem,
                              OnStateListener listener) {
        this.context = context;
        this.listItem = listItem;
        this.listener = listener;

        bottomSheetView = (LockableBottomSheetBehavior<View>) LockableBottomSheetBehavior.from(view);
        adapter = new MapMarkerAdapter(context);
        this.recyclerView = view.findViewById(R.id.recyclerview);
        this.filter = view.findViewById(R.id.filter);


        init();
    }

    private void init() {
        bottomSheetView.setPeekHeight((int) context.getResources().getDimension(R.dimen.map_sheet_peek_height));
        bottomSheetView.setState(BottomSheetBehavior.STATE_COLLAPSED);
        bottomSheetView.setFitToContents(true);
        bottomSheetView.setSkipCollapsed(true);
        bottomSheetView.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(View bottomSheet, int newState) {
                if (listener != null) {
                    listener.onStateChanged(newState);
                }
            }

            @Override
            public void onSlide(View bottomSheet, float slideOffset) {
                //onSlide
            }
        });

        adapter.setDatas(listItem);
        adapter.setOnItemClickListener(new MapMarkerAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View v, LocationItem data) {
                if (listener != null) {
                    listener.onItemClick(v.getTag().toString(), data);
                }
            }
        });
        recyclerView.setAdapter(adapter);

        this.filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    listener.onItemClick("Filter", null);
                }
            }
        });
    }

    public void updateItem(ArrayList<LocationItem> listItem) {
        Collections.sort(listItem, (data1, data2) -> Boolean.compare(data2.isSelected(), data1.isSelected()));
        this.listItem = listItem;
        adapter.setDatas(listItem);
        adapter.notifyDataSetChanged();
    }

    public void setSelectItem(int index) {
        int position = 0;
        for (int i = 0; i < listItem.size(); i++) {
            if (listItem.get(i).getCompanyId() == index) {
                listItem.get(i).setSelected(true);
                position = i;
            } else {
                listItem.get(i).setSelected(false);
            }
        }
        Collections.swap(listItem, 0, position);

        adapter.setDatas(listItem);
        adapter.notifyDataSetChanged();
    }

    public boolean isStateExpanded() {
        return bottomSheetView.getState() == BottomSheetBehavior.STATE_EXPANDED ||
                bottomSheetView.getState() == BottomSheetBehavior.STATE_HALF_EXPANDED;
    }

    public void expandView() {
        bottomSheetView.setState(BottomSheetBehavior.STATE_EXPANDED);
    }

    public void collapseView() {
        bottomSheetView.setState(BottomSheetBehavior.STATE_COLLAPSED);
    }

    public void setSwipeEnabled(boolean set) {
        bottomSheetView.setSwipeEnabled(set);
    }
}
