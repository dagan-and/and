package com.daquv.sdk.ui;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.ui.adapter.FilterAdapter;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;

public class FilterBottomSheetDialog extends BottomSheetDialogFragment {


    private final ArrayList<AppConfig.Filter> filters;
    private final int sheetHeight;

    public interface OnItemClickListener {
        void onItemClick(String data);
    }

    private final OnItemClickListener listener;

    public FilterBottomSheetDialog(int height ,ArrayList<AppConfig.Filter> filters, OnItemClickListener listener) {
        this.sheetHeight = height;
        this.filters = filters;
        this.listener = listener;
    }

    @Override
    public int getTheme() {
        return R.style.Theme_NoWiredStrapInNavigationBar;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), getTheme());
        dialog.setCancelable(false);
        return dialog;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_filter_bottom_sheet, container , false);

        ArrayList<AppConfig.Filter> dummy = new ArrayList<>();
        dummy.addAll(filters);

        filters.addAll(dummy);

        FilterAdapter adapter = new FilterAdapter(filters);

        RecyclerView recyclerView = view.findViewById(R.id.filter_recyclerview);
        recyclerView.setAdapter(adapter);



        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getView().post(() -> {
            View parent = (View) view.getParent();
            CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) (parent).getLayoutParams();
            CoordinatorLayout.Behavior behavior = params.getBehavior();
            BottomSheetBehavior bottomSheetBehavior = (BottomSheetBehavior) behavior;
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            bottomSheetBehavior.setFitToContents(true);
            bottomSheetBehavior.setSkipCollapsed(true);
        });
    }
}
