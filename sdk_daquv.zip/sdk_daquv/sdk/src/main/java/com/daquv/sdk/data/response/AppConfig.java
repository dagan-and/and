package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.HashMap;

public class AppConfig {

    @SerializedName("site_url")
    public String siteUrl;

    @SerializedName("engine")
    public String engine;

    @SerializedName("service")
    public String service;

    @SerializedName("reaskCount")
    public int reaskCount;

    @SerializedName("mainPage")
    public String mainPage;

    @SerializedName("available_service")
    public boolean availableService;

    @SerializedName("available_act")
    public String availableAct;

    @SerializedName("program_ver")
    public String programVer;

    @SerializedName("minimum_ver")
    public String minimumVer;

    @SerializedName("update_act")
    public String updateAct;

    @SerializedName("appstore_url")
    public String appstoreUrl;

    @SerializedName("register_pass")
    public boolean registerPass;

    @SerializedName("notice_yn")
    public boolean noticeYn;

    @SerializedName("notice_act")
    public NoticeAction noticeAction;

    @SerializedName("intent_code")
    public IntentCodes intentCodes;

    @SerializedName("entity_code")
    public EntityCodes entityCodes;

    @SerializedName("map_info")
    public MapInfo mapInfo;

    @SerializedName("service_resource")
    public ArrayList<ServiceResource> serviceResources;

    @SerializedName("argm_list")
    public ArrayList<Argument> argmList;

    @SerializedName("policy_list")
    public ArrayList<Argument> policyList;

    @SerializedName("inside_info")
    public ArrayList<InsideInfo> insideInfoList;

    @SerializedName("local_cache")
    public ArrayList<WebResourceResponse> localCaches;


    public static class NoticeAction {
        @SerializedName("c_act_url")
        public String cActUrl;

        @SerializedName("c_act")
        public String cAct;
    }

    public static class IntentCodes {
        @SerializedName("call")
        public String call;

        @SerializedName("sms")
        public String sms;

        @SerializedName("decision")
        public String decision;

        @SerializedName("turn")
        public String turn;

        @SerializedName("map")
        public String map;
    }

    public static class EntityCodes {
        @SerializedName("call")
        public String call;

        @SerializedName("sms")
        public String sms;
    }

    public static class MapInfo {
        @SerializedName("max_zoom")
        public int maxZoom;

        @SerializedName("min_zoom")
        public int minZoom;

        @SerializedName("default_zoom")
        public int defaultZoom;

        @SerializedName("scheme")
        public MapScheme scheme;

        @SerializedName("filter")
        public ArrayList<Filter> filter;
    }

    public static class MapScheme {
        @SerializedName("kakao")
        public String kakao;

        @SerializedName("naver")
        public String naver;

        @SerializedName("tmap")
        public String tmap;
    }

    public static class Filter {
        @SerializedName("category")
        public String category;

        @SerializedName("type")
        public String type;

        @SerializedName("search")
        public String search;

        @SerializedName("name")
        public String name;

        @SerializedName("value")
        public ArrayList<String> value;

        public String selected;
    }

    public static class ServiceResource {
        @SerializedName("name")
        public String name;

        @SerializedName("icon")
        public String icon;

        @SerializedName("ci")
        public String ci;
    }

    public static class Argument {
        @SerializedName("argm_nm")
        public String argmNm;

        @SerializedName("argm_url")
        public String argmUrl;
    }


    public static class InsideInfo {
        @SerializedName("client_id")
        public String clientId;

        @SerializedName("client_key")
        public String clientKey;

        @SerializedName("client_secret")
        public String clientSecret;

        @SerializedName("client_uid")
        public String clientUid;

        @SerializedName("server_ip")
        public String serverIp;

        @SerializedName("server_port")
        public int serverPort;

        @SerializedName("server_reset_port")
        public int serverResetPort;
    }
}