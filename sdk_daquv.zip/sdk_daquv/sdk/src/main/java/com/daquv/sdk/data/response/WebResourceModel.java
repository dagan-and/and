package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class WebResourceModel {
    @SerializedName("version")
    private int version = 0;

    @SerializedName("resource")
    private ArrayList<WebResourceResponse> resource = new ArrayList<>();

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public ArrayList<WebResourceResponse> getResource() {
        return resource;
    }

    public void setResource(ArrayList<WebResourceResponse> resource) {
        this.resource = resource;
    }
}
