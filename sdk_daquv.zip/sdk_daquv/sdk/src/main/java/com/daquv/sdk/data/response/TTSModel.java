package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

public class TTSModel  {
    @SerializedName("status")
    private String status = "000";

    @SerializedName("success")
    private boolean success;

    @SerializedName("message")
    private String message = "";

    @SerializedName("detailMsg")
    private String detailMsg = "";

    @SerializedName("error_code")
    private String errorCode = "";

    @SerializedName("error_message")
    private String errorMessage = "";

    @SerializedName("body")
    private TTSResponse items;

    // Constructor, getters, and setters

    public TTSModel(boolean success, TTSResponse items) {
        this.success = success;
        this.items = items;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetailMsg() {
        return detailMsg;
    }

    public void setDetailMsg(String detailMsg) {
        this.detailMsg = detailMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public TTSResponse getItems() {
        return items;
    }

    public void setItems(TTSResponse items) {
        this.items = items;
    }
}
