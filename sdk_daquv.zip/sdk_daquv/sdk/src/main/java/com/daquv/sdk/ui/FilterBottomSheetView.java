package com.daquv.sdk.ui;

import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.ui.adapter.FilterAdapter;
import com.daquv.sdk.ui.adapter.MapMarkerAdapter;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.util.ArrayList;
import java.util.Collections;

public class FilterBottomSheetView {
    public interface OnStateListener {
        void onStateChanged(int newState);
        void onItemClick(String tag, AppConfig.Filter data);
    }

    private final Context context;
    private ArrayList<AppConfig.Filter> listItem;
    private final OnStateListener listener;
    private final BottomSheetBehavior<View> bottomSheetView;
    private final RecyclerView recyclerView;

    public FilterBottomSheetView(Context context,
                                 View view,
                                 ArrayList<AppConfig.Filter> listItem,
                                 OnStateListener listener) {
        this.context = context;
        this.listItem = listItem;
        this.listener = listener;

        bottomSheetView = BottomSheetBehavior.from(view);
        this.recyclerView = view.findViewById(R.id.filter_recyclerview);


        init();
    }

    private void init() {
        bottomSheetView.setState(BottomSheetBehavior.STATE_COLLAPSED);
        bottomSheetView.setHideable(true);
        bottomSheetView.setSkipCollapsed(true);
        bottomSheetView.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(View bottomSheet, int newState) {
                if (listener != null) {
                    listener.onStateChanged(newState);
                }
            }

            @Override
            public void onSlide(View bottomSheet, float slideOffset) {
                //onSlide
            }
        });

        ArrayList<AppConfig.Filter> dummy = new ArrayList<>();
        for(int i = 0 ; i<30 ; i++) {
            dummy.add(listItem.get(0));
        }

        listItem.addAll(dummy);

        FilterAdapter adapter = new FilterAdapter(listItem);
        adapter.setOnItemClickListener(new FilterAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(View v, AppConfig.Filter data) {
                if (listener != null) {
                    listener.onItemClick(v.getTag().toString(), data);
                }
            }
        });
        recyclerView.setAdapter(adapter);
    }


    public boolean isStateExpanded() {
        return bottomSheetView.getState() == STATE_EXPANDED ||
                bottomSheetView.getState() == BottomSheetBehavior.STATE_HALF_EXPANDED;
    }

    public void expandView() {
        bottomSheetView.setState(STATE_EXPANDED);
    }

    public void collapseView() {
        bottomSheetView.setState(BottomSheetBehavior.STATE_COLLAPSED);
    }
}
