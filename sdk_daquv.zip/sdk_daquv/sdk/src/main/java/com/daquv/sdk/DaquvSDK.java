package com.daquv.sdk;

import static android.content.Context.LOCATION_SERVICE;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.LruCache;
import android.webkit.ValueCallback;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.daquv.sdk.core.DaquvAPI;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.data.response.WebResourceModel;
import com.daquv.sdk.tts.media.MediaPlayerHelper;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.secure.PreventRecordUtils;
import com.daquv.sdk.webview.cache.ResourceManager;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.webkit.CookieManager;


public class DaquvSDK {

    private DaquvAPI daquvAPI;
    private DaquvEngine daquvEngine;
    private MediaPlayerHelper daquvMediaPlayer;
    private final LruCache<String, byte[]> localCacheData = new LruCache<>(DaquvConfig.RESOURCE_MAX_CACHE_SIZE);

    private LocationManager locationManager;
    private LocationListener locationListener;
    private Location location;

    private boolean isLogin = false;

    public static DaquvSDK getInstance() {
        return DaquvSDK.LazyHolder.INSTANCE;
    }

    private static class LazyHolder {
        private static final DaquvSDK INSTANCE = new DaquvSDK();
    }

    /**
     * SDK 초기화
     */
    public void init(Context context, DaquvEngine.Callback callback) {
        onClearCookie();
        SharedPref.initialize(context);
        PreventRecordUtils.getInstance().init(context);
        PreventRecordUtils.getInstance().registerMicrophoneListener();
        Logger.setEnable(BuildConfig.DEBUG);
        DaquvConfig.dirPath = context.getFilesDir().getAbsolutePath();

        DaquvConfig.appConfig = getAppConfig(context);
        WebResourceModel resourceModel = new WebResourceModel();
        resourceModel.setResource(DaquvConfig.appConfig.localCaches);
        ResourceManager resourceManager = new ResourceManager();
        resourceManager.initWebResource(context, resourceModel);

        DaquvConfig.defaultZoom = DaquvConfig.appConfig.mapInfo.defaultZoom;

        getLocation(context);

        if (daquvEngine == null) {
            daquvEngine = new DaquvEngine(context);
        }
        daquvEngine.clearCallBack();
        daquvEngine.addCallBack(new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);
                if (code == DaquvConfig.CODE.ENGINE_FINAL_DATA) {
                    DaquvSDK.getInstance().getEngine().stopEngine();
                    daquvAPI.getNLUData(String.valueOf(result));
                } else if (code == DaquvConfig.CODE.ENGINE_START_VOICE) {
                    stopTTS();
                } else if (code == DaquvConfig.CODE.ENGINE_FINISH_TTS) {
                    File mp3File = new File(DaquvConfig.dirPath + "/temp.mp3");
                    if (mp3File.exists()) {
                        mp3File.delete();
                    }
                }
            }
        });
        if (callback != null) {
            daquvEngine.addCallBack(callback);
        }

        if (daquvAPI == null) {
            daquvAPI = new DaquvAPI(context, new DaquvAPI.APICallback() {
                @Override
                public void onAPIResult(int code, Object result) {
                    super.onAPIResult(code, result);
                    daquvEngine.onAPIResult(code, result);

                    if (code == DaquvConfig.CODE.API_LOGIN) {
                        isLogin = true;

                        daquvEngine.initEngine();

                        //TODO 로그인 맵뷰 테스트를 위해 임시코드
//                        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                LocationManager locationManager = (LocationManager) context.getSystemService(LOCATION_SERVICE);
//                                if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
//                                    DaquvSDK.getInstance().getAPI().getMapData(String.valueOf(DaquvSDK.getInstance().getLocation().getLatitude()),
//                                            String.valueOf(DaquvSDK.getInstance().getLocation().getLongitude()),
//                                            DaquvConfig.appConfig.mapInfo.filter.get(0).value.get(0));
//                                } else {
//                                    Toast.makeText(context, "GPS 기능을 활성화 해주세요.", Toast.LENGTH_SHORT).show();
//                                }
//                            }
//                        }, 1500);
                    } else if (code == DaquvConfig.CODE.API_NLU) {
                        NLUResultResponse response = (NLUResultResponse) result;

                        if (!TextUtils.isEmpty(response.getIntent()) &&
                                response.getIntent().equals(DaquvConfig.appConfig.intentCodes.turn)) {
                            daquvAPI.getTURNData(response);
                            return;
                        }

                        if (!TextUtils.isEmpty(response.getIntent()) &&
                                response.getIntent().equals(DaquvConfig.appConfig.intentCodes.map)) {
                            LocationManager locationManager = (LocationManager) context.getSystemService(LOCATION_SERVICE);
                            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                                DaquvSDK.getInstance().getAPI().getMapData(String.valueOf(DaquvSDK.getInstance().getLocation().getLatitude()),
                                        String.valueOf(DaquvSDK.getInstance().getLocation().getLongitude()),
                                        DaquvConfig.appConfig.mapInfo.filter.get(0).value.get(0));
                            } else {
                                Toast.makeText(context, "GPS 기능을 활성화 해주세요.", Toast.LENGTH_SHORT).show();
                            }
                            return;
                        }

                        if (!TextUtils.isEmpty(response.getTail()) &&
                                response.getTail().equals("Y")) {
                            daquvAPI.getReAskPage(response);
                            return;
                        }

                        if (!TextUtils.isEmpty(response.getTail()) &&
                                !TextUtils.isEmpty(response.getUrl()) &&
                                response.getTail().equals("N")) {
                            daquvEngine.resetFailCount();
                            daquvAPI.getResultPage(response);
                            return;
                        }

                        if (TextUtils.isEmpty(response.getTail()) || TextUtils.isEmpty(response.getUrl())) {
                            daquvAPI.getFailPage(response);
                        }
                    } else if (code == DaquvConfig.CODE.API_TTS) {
                        TTSResponse response = (TTSResponse) result;

                        daquvEngine.onAPIResult(DaquvConfig.CODE.ENGINE_START_TTS, response.getCode());
                        daquvMediaPlayer.startWav(response.getBinaryResult(), new MediaPlayerHelper.OnMediaCallbackListener() {
                            @Override
                            public void onFinish() {
                                daquvEngine.onAPIResult(DaquvConfig.CODE.ENGINE_FINISH_TTS, response);
                            }
                        });
                    }
                }
            });
        }
        if (daquvMediaPlayer == null) {
            daquvMediaPlayer = new MediaPlayerHelper(context);
        }
    }

    public void addCallBack(DaquvEngine.Callback callback) {
        if (daquvEngine == null || callback == null) {
            return;
        }
        daquvEngine.addCallBack(callback);
    }

    public void removeCallBack(DaquvEngine.Callback callback) {
        if (daquvEngine == null || callback == null) {
            return;
        }
        daquvEngine.removeCallBack(callback);
    }

    public void stopTTS() {
        if (daquvMediaPlayer.isPlaying()) {
            daquvMediaPlayer.stop();
            daquvEngine.onAPIResult(DaquvConfig.CODE.ENGINE_FINISH_TTS, null);
        }
    }

    public DaquvAPI getAPI() {
        return daquvAPI;
    }

    public DaquvEngine getEngine() {
        return daquvEngine;
    }

    public LruCache<String, byte[]> getLocalCacheData() {
        return localCacheData;
    }

    public Location getLocation() {
        return location;
    }


    public void onDestroy() {
        PreventRecordUtils.getInstance().unregisterMicrophoneListener();
        if (locationListener != null && locationManager != null) {
            locationManager.removeUpdates(locationListener);
        }
    }

    public void onClearCookie() {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.removeAllCookies(null);
        cookieManager.flush();
    }

    public void setSpeakerMode(Boolean isSpeaker) {
        SharedPref.getInstance().put(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, isSpeaker);
        if (daquvMediaPlayer.isPlaying()) {
            daquvMediaPlayer.updateStreamMode();
        }
    }

    public boolean getSpeakerMode() {
        return SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_VOICE_SPEAKER, true);
    }

    public void setUseTTS(Boolean use) {
        SharedPref.getInstance().put(DaquvConfig.Preference.KEY_PREF_USE_TTS, use);
    }

    public boolean getUseTTS() {
        return SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_USE_TTS, true);
    }

    public boolean isLogin() {
        return isLogin;
    }

    public String getSiteUrl() {
        if (DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service) {
            return DaquvConfig.crmUrl;
        } else {
            return DaquvConfig.hubUrl;
        }
    }

    private AppConfig getAppConfig(Context context) {
        String jsonString = null;
        try {
            InputStream inputStream = context.getAssets().open("daquv_ibkcrm_v_100.json");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while (true) {
                line = bufferedReader.readLine();
                if (line == null) {
                    break;
                }
                stringBuilder.append(line);
            }
            jsonString = stringBuilder.toString();
            bufferedReader.close();
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (!TextUtils.isEmpty(jsonString)) {
            return new Gson().fromJson(jsonString, AppConfig.class);
        }
        return null;
    }

    /*
     * 최근 위치값을 우선적으로 획득한 후
     * 현재 기준 위치값으로 갱신
     */
    private void getLocation(Context context) {
        locationManager = (LocationManager) context.getSystemService(LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setSpeedRequired(false);
        criteria.setCostAllowed(true);
        criteria.setPowerRequirement(Criteria.POWER_LOW);
        String mProvider = locationManager.getBestProvider(criteria, true);

        //최근 위치값 설정
        try {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (location == null) {
                    location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        //현재 위치값 갱신
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location current) {
                location = current;
                Logger.dev("onLocationChanged");
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                //onStatusChanged
            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {
                //onProviderEnabled
            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {
                //onProviderDisabled
            }
        };

        // Request location updates
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60 * 1000, 10.0f, locationListener);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 60 * 1000, 10.0f, locationListener);
        }
    }

    public boolean checkPermission(Context context) {
        int permissionMicrophone = 0;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            permissionMicrophone = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO);
        }
        if (permissionMicrophone == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            Toast.makeText(context, "다큐브SDK 실행을 위해선 오디오 권한이 필요합니다.", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

}
