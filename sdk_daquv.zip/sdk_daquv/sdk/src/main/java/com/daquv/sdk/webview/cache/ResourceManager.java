package com.daquv.sdk.webview.cache;

import android.content.Context;
import android.util.Log;
import android.util.LruCache;

import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.data.response.WebResourceModel;
import com.daquv.sdk.data.response.WebResourceResponse;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;


public class ResourceManager {
    private static final String TAG = "ResourceManager";

    /**
     * 웹뷰 케싱(CSS,폰트..) 파일 다운로드
     * Firebase RemoteConfig 사용해서 버전관리 및 파일 리스트 관리
     */
    public void initWebResource(Context context, WebResourceModel webResourceModel) {
        downLoadResource(context, DaquvSDK.getInstance().getSiteUrl(), webResourceModel);
    }

    /**
     * 리소스 관리 API 를 통해서 업데이트 하기
     */
    private final CompositeDisposable compositeDisposable = new CompositeDisposable();

    public void downLoadResource(Context context, String url, WebResourceModel model) {
        List<Observable<Object>> observables = new ArrayList<>();
        WebviewResourceMappingHelper helper = WebviewResourceMappingHelper.getInstance();
        for (WebResourceResponse resourceData : model.getResource()) {
            if (resourceData.getUrl().contains("http") || resourceData.getUrl().contains("https")) {
                observables.add(helper.saveWebResourceFile(context, resourceData.getFilename(), resourceData.getUrl()));
            } else {
                observables.add(helper.saveWebResourceFile(context, resourceData.getFilename(), url + resourceData.getUrl()));
            }
        }
        compositeDisposable.add(Observable.merge(observables)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(eachResult -> Log.d(TAG, "Complete::" + eachResult.toString())));
    }


    public void loadResource(Context context, String url, WebResourceModel model) {
        WebviewResourceMappingHelper helper = WebviewResourceMappingHelper.getInstance();
        for (WebResourceResponse resourceData : model.getResource()) {
            if (resourceData.getUrl().contains("http") || resourceData.getUrl().contains("https")) {
                helper.loadWebResourceFile(resourceData.getFilename(), resourceData.getUrl());
            } else {
                helper.loadWebResourceFile(resourceData.getFilename(), url + resourceData.getUrl());
            }
        }
    }
}
