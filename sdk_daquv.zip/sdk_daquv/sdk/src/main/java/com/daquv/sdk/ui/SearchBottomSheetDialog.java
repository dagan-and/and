package com.daquv.sdk.ui;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatEditText;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.utils.search.KoreanTextMatch;
import com.daquv.sdk.utils.search.KoreanTextMatcher;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.ArrayList;

public class SearchBottomSheetDialog extends BottomSheetDialogFragment {


    private final ArrayList<String> values;

    public interface OnItemClickListener {
        void onItemClick(String data);
    }

    private final OnItemClickListener listener;

    public SearchBottomSheetDialog(ArrayList<String> values, OnItemClickListener listener) {

        this.values = values;
        this.listener = listener;
    }

    @Override
    public int getTheme() {
        return R.style.Theme_NoWiredStrapInNavigationBar;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext(), getTheme());
        FrameLayout bottomSheet = dialog.findViewById (com.google.android.material.R.id.design_bottom_sheet);
        BottomSheetBehavior behavior = BottomSheetBehavior.from (bottomSheet);
        behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        behavior.setFitToContents(true);
        behavior.setSkipCollapsed(true);
        dialog.setCancelable(false);
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialogInterface, int keyCode, KeyEvent keyEvent) {
                if (keyCode == KeyEvent.KEYCODE_BACK && keyEvent.getAction() == KeyEvent.ACTION_DOWN ) {
                    behavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                    return true;
                }
                return false;
            }
        });
        return dialog;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.view_search_bottom_sheet, container , false);


        AppCompatEditText editText = view.findViewById(R.id.editText);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //NONE
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                ArrayList<String> filter = new ArrayList<>();
                KoreanTextMatcher matcher = new KoreanTextMatcher(charSequence.toString());
                for (String data : values) {
                    KoreanTextMatch match = matcher.match(data);
                    if (match.success()) {
                        filter.add(data);
                    }
                }

                for (String data2 : filter) {
                    Log.d("DDDDD", data2);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //NONE
            }
        });

        return view;
    }




}
