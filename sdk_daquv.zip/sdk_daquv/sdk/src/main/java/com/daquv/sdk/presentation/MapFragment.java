package com.daquv.sdk.presentation;

import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_HIDDEN;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.data.response.LocationItemResponse;
import com.daquv.sdk.network.ETagCache;
import com.daquv.sdk.network.HttpClient;
import com.daquv.sdk.ui.FilterBottomSheetView;
import com.daquv.sdk.ui.MapBottomSheetView;
import com.daquv.sdk.utils.Logger;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.geometry.LatLngBounds;
import com.naver.maps.map.CameraPosition;
import com.naver.maps.map.MapView;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.NaverMapOptions;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.UiSettings;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.Overlay;
import com.naver.maps.map.overlay.OverlayImage;
import com.naver.maps.map.overlay.PathOverlay;
import com.naver.maps.map.util.MarkerIcons;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.Callable;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;
import okhttp3.JavaNetCookieJar;
import okhttp3.Response;

public class MapFragment extends Fragment implements OnMapReadyCallback, Overlay.OnClickListener {

    DaquvEngine.Callback engineCallback;
    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;

    private final ArrayList<AppConfig.Filter> filters = new ArrayList<>();
    private final ArrayList<Marker> markers = new ArrayList<>();
    private ArrayList<LocationItem> locationItem= new ArrayList<>();
    private Location location;
    private NaverMap naverMap;
    private MapView mapView;
    private Marker positionMarker;
    private Marker selectMarker;
    private View dataSheetContainer;
    private View filterSheetContainer;
    private MapBottomSheetView dataSheetView;
    private FilterBottomSheetView filterSheetView;
    private CompositeDisposable disposable;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_map, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        disposable = new CompositeDisposable();
        dataSheetContainer = view.findViewById(R.id.data_sheet);
        filterSheetContainer = view.findViewById(R.id.filter_sheet);

        NaverMapOptions options = new NaverMapOptions()
                .camera(new CameraPosition(new LatLng(location.getLatitude(), location.getLongitude()), DaquvConfig.defaultZoom))
                .mapType(NaverMap.MapType.Basic);

        FrameLayout mapContainer = view.findViewById(R.id.map_container);
        mapView = new MapView(requireContext(), options);
        mapContainer.addView(mapView);

        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);


        filters.addAll(DaquvConfig.appConfig.mapInfo.filter);
        filterSheetContainer.setVisibility(View.GONE);

        setDataSheetView();
        setFilterSheetView();

    }

    public void setLocationItem(ArrayList<LocationItem> item) {
        this.locationItem = item;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);
                if (code == DaquvConfig.CODE.API_NLU_MAP) {
                    if (result instanceof LocationItemResponse &&
                            ((LocationItemResponse) result).getBody() != null &&
                            ((LocationItemResponse) result).getCount() > 0) {

                        setLocationItem(((LocationItemResponse) result).getBody());

                        Location location = new Location(DaquvSDK.getInstance().getLocation());
                        location.setLatitude(((LocationItemResponse) result).getLatitude());
                        location.setLongitude(((LocationItemResponse) result).getLongitude());
                        setLocation(location);

                        initMarker();
                    } else {
                        locationItem.clear();
                        initMarker();
                    }
                }
            }
        };

        DaquvSDK.getInstance().addCallBack(engineCallback);

        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
        onBackPressedCallback.remove();
    }


    public boolean runKakaoMap(LocationItem data) {
        try {
            String scheme = DaquvConfig.appConfig.mapInfo.scheme.kakao;
            scheme = scheme.replace("$latitude", String.valueOf(data.getLatitude()));
            scheme = scheme.replace("$longitude", String.valueOf(data.getLongitude()));
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            startActivity(intent);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean runTMap(LocationItem data) {
        try {
            String scheme = DaquvConfig.appConfig.mapInfo.scheme.tmap;
            scheme = scheme.replace("$latitude", String.valueOf(data.getLatitude()));
            scheme = scheme.replace("$longitude", String.valueOf(data.getLongitude()));
            scheme = scheme.replace("$title", data.getCompanyNm());
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            startActivity(intent);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean runNaverMap(LocationItem data) {
        try {
            String str = URLEncoder.encode(data.getCompanyNm(), "UTF-8");
            String scheme = DaquvConfig.appConfig.mapInfo.scheme.naver;
            scheme = scheme.replace("$latitude", String.valueOf(data.getLatitude()));
            scheme = scheme.replace("$longitude", String.valueOf(data.getLongitude()));
            scheme = scheme.replace("$title", str);
            scheme = scheme.replace("$package", requireContext().getPackageName());
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            startActivity(intent);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    @Override
    public boolean onClick(Overlay p0) {
        //기존에 선택한 마커 초기화
        for(Marker marker : markers) {
            marker.setIcon(OverlayImage.fromResource(R.drawable.default_marker));
            marker.setIconTintColor(Color.TRANSPARENT);
        }

        //선택한 마커 포커스 및 설정
        Marker marker = (Marker) p0;
        marker.setIcon(MarkerIcons.BLACK);
        marker.setIconTintColor(Color.RED);

        selectMarker = marker;

        dataSheetView.setSelectItem((int) p0.getTag());
        return false;
    }

    @Override
    public void onMapReady(NaverMap naverMap) {
        this.naverMap = naverMap;
        Logger.dev("onMapReady");

        //맵 Zoom Level 지정
        naverMap.setMinZoom(DaquvConfig.minZoom);
        naverMap.setMaxZoom(DaquvConfig.maxZoom);

        UiSettings uiSettings = naverMap.getUiSettings();
        uiSettings.setLogoGravity(Gravity.LEFT|Gravity.TOP);
        uiSettings.setLogoMargin(10,10,10,10);

        //맵 범위 지정
        double bundary = 0.1;
        naverMap.setExtent(new LatLngBounds(
                new LatLng(cutplaces(location.getLatitude()) - bundary, cutplaces(location.getLongitude()) - bundary),
                new LatLng(cutplaces(location.getLatitude()) + bundary, cutplaces(location.getLongitude()) + bundary)
        ));

        //지도뷰 선택 리스너
        naverMap.addOnCameraChangeListener(new NaverMap.OnCameraChangeListener() {
            @Override
            public void onCameraChange(int i, boolean b) {
                if (dataSheetView.isStateExpanded()) {
                    dataSheetView.collapseView();
                }
            }
        });

        //카메라 전환 리스너 등록
        naverMap.addOnCameraIdleListener(new NaverMap.OnCameraIdleListener() {
            @Override
            public void onCameraIdle() {

                positionMarker.setPosition(new LatLng(naverMap.getCameraPosition().target.latitude,
                        naverMap.getCameraPosition().target.longitude));

                DaquvSDK.getInstance().getAPI().getMapData(String.valueOf(naverMap.getCameraPosition().target.latitude),
                        String.valueOf(naverMap.getCameraPosition().target.longitude),
                        filters.get(0).value.get(0));

                //getRoute();
            }
        });

        //맵 중앙 위치 표시
        positionMarker = new Marker();
        positionMarker.setPosition(new LatLng(location.getLatitude(), location.getLongitude()));
        positionMarker.setIcon(OverlayImage.fromResource(R.drawable.position_marker));
        positionMarker.setMap(naverMap);



        initMarker();
    }

    public void initMarker() {
        if (markers.size() > 0) {
            for (Marker marker : markers) {
                marker.setMap(null);
            }
        }
        markers.clear();

        boolean containSelectMarker = false;
        if(locationItem != null && !locationItem.isEmpty()) {
            for (LocationItem item : locationItem) {
                if (item.getLatitude() > 10 && item.getLongitude() > 10) {
                    Marker marker = new Marker();
                    if (selectMarker != null && selectMarker.getTag() != null &&
                            selectMarker.getTag().equals(item.getCompanyId())) {
                        marker.setIcon(MarkerIcons.BLACK);
                        marker.setIconTintColor(Color.RED);
                        item.setSelected(true);
                        containSelectMarker = true;
                    } else {
                        marker.setIcon(OverlayImage.fromResource(R.drawable.default_marker));
                        marker.setIconTintColor(Color.TRANSPARENT);
                        item.setSelected(false);
                    }

                    marker.setPosition(new LatLng(item.getLatitude(), item.getLongitude()));
                    marker.setCaptionText(item.getCompanyNm());
                    marker.setMap(naverMap);
                    marker.setTag(item.getCompanyId());
                    marker.setOnClickListener(this);
                    markers.add(marker);
                }
            }
            if(!containSelectMarker) {
                selectMarker = null;
            }
        }
        dataSheetView.updateItem(locationItem);
    }

    public double cutplaces(double number) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        String formattedNumber = decimalFormat.format(number);
        return Double.parseDouble(formattedNumber);
    }

    private void setDataSheetView() {
        dataSheetView = new MapBottomSheetView(requireContext(),
                dataSheetContainer,
                locationItem,
                new MapBottomSheetView.OnStateListener() {
                    @Override
                    public void onStateChanged(int newState) {
                        Logger.dev("onStateChanged::" + newState);
                    }

                    @Override
                    public void onItemClick(String tag, LocationItem data) {
                        if (tag.equals("navi")) {
                            if (!runTMap(data)) {
                                if (!runNaverMap(data)) {
                                    if (!runKakaoMap(data)) {
                                        Toast.makeText(requireContext(), "네비게이션을 실행할 앱이 없습니다.", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        } else if (tag.equals("container")) {
                            //답변화면 이동
                            Toast.makeText(getContext(), "기업정보 화면으로 이동 개발중", Toast.LENGTH_SHORT).show();
                        } else if (tag.equals("Filter")) {
                            dataSheetView.collapseView();
                            dataSheetView.setSwipeEnabled(false);
                            filterSheetContainer.setVisibility(View.VISIBLE);
                            filterSheetView.expandView();
                        }
                    }
                });
    }


    private void setFilterSheetView() {
        filterSheetView = new FilterBottomSheetView(requireContext(),
                filterSheetContainer,
                filters,
                new FilterBottomSheetView.OnStateListener() {
                    @Override
                    public void onStateChanged(int newState) {
                        Logger.dev("onStateChanged::" + newState);
                        if(newState == STATE_HIDDEN) {
                            dataSheetView.setSwipeEnabled(true);
                        }
                    }

                    @Override
                    public void onItemClick(String tag, AppConfig.Filter data) {

                    }
                });
    }


    private void getRoute() {
        Callable<Response> callable = () -> {

            HashMap<String, String> header = new HashMap<>();
            header.put("X-NCP-APIGW-API-KEY-ID","d8fdey46it");
            header.put("X-NCP-APIGW-API-KEY","AO9jektWNuoJAsOBIjLTEYcYgf55NBiE6s9rDeqK");

            HashMap<String, String> parameter = new HashMap<>();
            parameter.put("start","126.9248321385,37.524305253");
            parameter.put("waypoints","126.914731126,37.513532691|126.90010394096251,37.510207140894518|126.895327105,37.5133379252");
            parameter.put("goal","126.89646640880619,37.51746124013443");


            HttpClient client = new HttpClient.Builder()
                    .setUrl("https://naveropenapi.apigw.ntruss.com/map-direction/v1/driving")
                    .isPost(false)
                    .addJWTToken(false)
                    .isLogging(true)
                    .setCookie(new JavaNetCookieJar(new java.net.CookieManager()))
                    .setCache(new ETagCache())
                    .setHeader(header)
                    .setParameter(parameter)
                    .builder();
            return client.getCall().execute();
        };

        disposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        try {
                            String data = response.body().string();
                            Log.d("DDDDD", data);

                            JSONObject jsonObject = new JSONObject(data);
                            JSONObject route = jsonObject.getJSONObject("route");
                            JSONArray traoptimal = route.getJSONArray("traoptimal");
                            JSONObject optimal = (JSONObject) traoptimal.get(0);
                            JSONArray path = optimal.getJSONArray("path");

                            Log.d("DDDDD", "path" + path.length());

                            PathOverlay pathOverlay = new PathOverlay();
                            ArrayList<LatLng> coords = new ArrayList<>();

                            for(int i = 0 ; i < path.length(); i++) {
                                JSONArray object =  (JSONArray)  path.get(i);
                                coords.add(new LatLng((double) object.get(1),(double)object.get(0)));
                            }
                            pathOverlay.setCoords(coords);
                            pathOverlay.setColor(Color.CYAN);
                            pathOverlay.setMap(naverMap);

                        } catch (Exception e) {
                            Log.d("DDDDD",e.getLocalizedMessage());
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.d("DDDDD",throwable.getLocalizedMessage());
                    }
                }));


    }

    @Override
    public void onStart() {
        super.onStart();
        mapView.onStart();
    }


    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    public void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }


}
