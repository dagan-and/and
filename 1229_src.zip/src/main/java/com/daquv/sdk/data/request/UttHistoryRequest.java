package com.daquv.sdk.data.request;

import android.text.TextUtils;

import com.daquv.sdk.data.response.Entities;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.network.TranJson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class UttHistoryRequest extends TranJson {

    public UttHistoryRequest(String utterance, String intentCode, ArrayList<Entities> entities, String emn, String ldinSe) {
        super();
        put("utterance",utterance);
        put("intent_code", TextUtils.isEmpty(intentCode) ? "" : intentCode);

        JSONArray jsonArray = new JSONArray();
        if (entities != null && !entities.isEmpty()) {
            for (int i = 0; i < entities.size(); i++) {
                Entities entity = entities.get(i);
                JSONObject object = new JSONObject();
                try {
                    object.put("entity", entity.getEntity());
                    object.put("value", entity.getValue());
                } catch (JSONException e) {
                    Logger.error(e);
                }
                jsonArray.put(object);
            }
        }
        put("entities", jsonArray);
        put("emn", emn);
        put("ldinSe", ldinSe);
    }
}