package com.daquv.sdk.presentation;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.LoginTokenResponse;
import com.daquv.sdk.ui.component.BasicButtonView;
import com.daquv.sdk.ui.component.BasicSwitch;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.secure.PreventRecordUtils;

public class SettingFragment extends Fragment implements View.OnClickListener {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    DaquvEngine.Callback engineCallback;
    LoginTokenResponse loginTokenResponse;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        PreventRecordUtils.getInstance().setSecureFlag(requireActivity());
        return inflater.inflate(R.layout.fragment_daquv_setting, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*NONE*/
            }
        });
        view.findViewById(R.id.setting_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onBackPress(SettingFragment.this);
            }
        });

        ((TextView) view.findViewById(R.id.setting_name)).setText(loginTokenResponse.getEmm());
        ((TextView) view.findViewById(R.id.setting_emn)).setText("("+loginTokenResponse.getEmn()+")");
        ((TextView) view.findViewById(R.id.setting_company)).setText(loginTokenResponse.getPnmnBrn());
        ((TextView) view.findViewById(R.id.setting_pnmn)).setText(loginTokenResponse.getPnmnBrcd());
        ((TextView) view.findViewById(R.id.setting_argument_date)).setText(loginTokenResponse.getAggrRegDt());
        ((TextView) view.findViewById(R.id.setting_policy_date)).setText(loginTokenResponse.getAggrRegDt());

        FrameLayout ttsSwitchLayout = view.findViewById(R.id.tts_setting_switch_container);
        BasicSwitch ttsSwitch = view.findViewById(R.id.tts_setting_switch);

        ttsSwitch.setChecked(DaquvSDK.getInstance().getUseTTS());
        ttsSwitchLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ttsSwitch.setChecked(!ttsSwitch.isChecked());
            }
        });

        ttsSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                DaquvSDK.getInstance().setUseTTS(isChecked);
                listener.updateSpeaker();
            }
        });

        view.findViewById(R.id.btn_setting_argument).setOnClickListener(this);
        view.findViewById(R.id.setting_argument_container).setOnClickListener(this);
        view.findViewById(R.id.btn_setting_policy).setOnClickListener(this);
        view.findViewById(R.id.setting_policy_container).setOnClickListener(this);
        view.findViewById(R.id.btn_setting_faq).setOnClickListener(this);
        view.findViewById(R.id.setting_faq_container).setOnClickListener(this);
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }
    public void setLoginTokenResponse(LoginTokenResponse loginTokenResponse) {
        this.loginTokenResponse = loginTokenResponse;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress(SettingFragment.this);
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);


            }
        };
        DaquvSDK.getInstance().addCallBack(engineCallback);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        onBackPressedCallback.remove();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == R.id.btn_setting_argument ||
            view.getId() == R.id.setting_argument_container) {
            listener.addHTMLView(getString(R.string.dqv_argument_msg),
                    DaquvUtil.getUrl("/webview/ibkCrm/v1/cmn/agree1"),
                    null);
        }
        if(view.getId() == R.id.btn_setting_policy ||
                view.getId() == R.id.setting_policy_container) {
            listener.addHTMLView(getString(R.string.dqv_policy_msg),
                    DaquvUtil.getUrl("/webview/ibkCrm/v1/cmn/agree2"),
                    null);
        }
        if(view.getId() == R.id.btn_setting_faq ||
                view.getId() == R.id.setting_faq_container) {
            listener.addHTMLView("",
                    DaquvUtil.getUrl("/webview/ibkCrm/v1/cmn/getFaqList"),
                    null);
        }
    }


}
