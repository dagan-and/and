package com.daquv.sdk.presentation;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.secure.PreventRecordUtils;
import com.daquv.sdk.webview.ComWebView;

import java.util.ArrayList;

public class DataFragment extends Fragment {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    DaquvEngine.Callback engineCallback;
    ComWebView webView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        PreventRecordUtils.getInstance().setSecureFlag(requireActivity());
        return inflater.inflate(R.layout.fragment_daquv_data , container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        webView = view.findViewById(R.id.data_view);
        webView.loadDataPage();
        webView.addListener(new ComWebView.OnWebActionListener() {
            @Override
            public void onShortCut(String utterance) {
                listener.showLoading();
                DaquvSDK.getInstance().getAPI().getNLUData(utterance);
            }

            @Override
            public void onClose() {
                listener.onBackPress();
            }

            @Override
            public void onSTT(boolean start) {
                if(start) {
                    listener.addVoiceView();
                } else {
                    listener.removeVoiceView();
                }
            }

            @Override
            public void onHome() {
                listener.onBackPress();
            }

            @Override
            public void onSetting() {
                listener.addSettingView();
            }

            @Override
            public void onConsult() {
                listener.addConsultView();
            }

            @Override
            public void onMap(String lat , String lon) {
                if(lat != null && lon != null) {
                    DaquvSDK.getInstance().getAPI().getMapData(lat, lon ,
                            DaquvConfig.appConfig.mapInfo.filter.get(0).value.get(0) );
                } else {
                    DaquvSDK.getInstance().getAPI().getMapData(String.valueOf(DaquvSDK.getInstance().getLocation().getLatitude()),
                            String.valueOf(DaquvSDK.getInstance().getLocation().getLongitude()),
                            DaquvConfig.appConfig.mapInfo.filter.get(0).value.get(0));
                }
            }

            @Override
            public void onNavi(ArrayList<LocationItem> items) {
                if(items.size() == 1) {
                    if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_tmap))) {
                        DaquvUtil.runTMap(requireContext(), items);
                    } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_kakao))) {
                        DaquvUtil.runKakaoMap(requireContext(), items);
                    } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(getString(R.string.map_naver))) {
                        DaquvUtil.runNaverMap(requireContext(), items);
                    }
                } else {
                    if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(getString(R.string.map_tmap))) {
                        DaquvUtil.runTMap(requireContext(), items);
                    } else if(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(getString(R.string.map_naver))) {
                        DaquvUtil.runNaverMap(requireContext(), items);
                    }
                }
            }

            @Override
            public void onCall(String number) {
                Intent tt = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
                startActivity(tt);
            }

            @Override
            public void onBrowser(String url) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(browserIntent);
            }

            @Override
            public void onCapture() {
                //지원하지 않음
            }
        });
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                webView.onBackPress();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);

                if (code == DaquvConfig.CODE.ENGINE_FINISH_TTS) {
                    if(result instanceof TTSResponse) {
                        String callBack = ((TTSResponse) result).getCallBack();
                        if (!TextUtils.isEmpty(callBack) && ("startSTT".equalsIgnoreCase(callBack) || "Y".equalsIgnoreCase(callBack))) {
                            listener.addVoiceView();
                        }
                    }
                }
                if (code == DaquvConfig.CODE.API_NLU_TURN) {
                    listener.hideLoading();
                    String value = (String) result;
                    String count = value.substring(0, value.indexOf("번"));
                    webView.loadUrl("javascript:callCompanyInfo(" + count + ")");
                }

            }
        };
        DaquvSDK.getInstance().addCallBack(engineCallback);
    }

    @Override
    public void onStop() {
        DaquvSDK.getInstance().stopTTS();
        DaquvSDK.getInstance().getEngine().stopEngine();
        super.onStop();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        onBackPressedCallback.remove();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
        DaquvSDK.getInstance().getAPI().ttsDispose();
    }
}
