package com.daquv.sdk.utils.secure;

import static android.content.Context.MODE_PRIVATE;
import static android.media.AudioAttributes.ALLOW_CAPTURE_BY_NONE;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.AudioRecordingConfiguration;
import android.media.MediaRecorder;
import android.os.Build;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.view.WindowManager;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;

import com.daquv.sdk.utils.Logger;

import java.util.List;

public class PreventRecordUtils {

    private AudioManager audioManager;
    private AudioManager.AudioRecordingCallback audioRecordingCallback;
    private Context context;

    private boolean isAudioRecording = false;

    /**
     * Singleton Instance 반환
     *
     * @return Instance
     */
    public static PreventRecordUtils getInstance() {
        return PreventRecordUtils.LazyHolder.INSTANCE;
    }

    private static class LazyHolder {
        private static final PreventRecordUtils INSTANCE = new PreventRecordUtils();
    }

    /**
     *  3rd Party 에서 녹음(마이크)를 사용중인지 체크
     */
    public void init(Context mContext) {
        context = mContext;
        audioManager = (AudioManager) mContext.getSystemService(Context.AUDIO_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            audioManager.setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_SYSTEM);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioRecordingCallback = new AudioManager.AudioRecordingCallback() {
                @Override
                public void onRecordingConfigChanged(List<AudioRecordingConfiguration> configs) {
                    super.onRecordingConfigChanged(configs);
                    isAudioRecording = !configs.isEmpty();
                }
            };
        }

        //알림 접근 허용 권한 요청
//        if(!isNotificationPermissionGranted(mContext)) {
//            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
//            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            mContext.startActivity(intent);
//        }
    }

    /**
     *  녹음(마이크) 상태값을 받는 리스너 등록
     */
    public void registerMicrophoneListener() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioManager.registerAudioRecordingCallback(audioRecordingCallback, null);
        }
    }

    /**
     *   녹음(마이크) 상태값을 받는 리스너 해제
     */
    public void unregisterMicrophoneListener() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            audioManager.unregisterAudioRecordingCallback(audioRecordingCallback);
        }
    }

    /**
     *  해당 화면에서 녹화,캡처를 방지하는 Flag 추가
     * @param mActivity
     */
    public void setSecureFlag(Activity mActivity) {
        mActivity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
    }

    /**
     * 음성 녹음 중인지 확인하기
     */
    public boolean isAudioRecording() {

        SharedPreferences preferences = context.getSharedPreferences("NotificationListener", MODE_PRIVATE);
        if(preferences.getBoolean("capture", false)) {
            return true;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return isAudioRecording;
        } else {
            AudioRecord audioRecord = getAudioRecorder();
            if(audioRecord != null) {
                try {
                    audioRecord.startRecording();
                } catch (Exception e) {
                    return true;
                } finally {
                    audioRecord.release();
                }
            }
        }
        return false;
    }


    private AudioRecord getAudioRecorder() {
        final int[] sampleRateCandidates = new int[]{16000, 22050, 44100, 11025};
        final int CHANNEL = AudioFormat.CHANNEL_IN_MONO;
        final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;

        for (int sampleRate : sampleRateCandidates) {
            final int sizeInBytes = AudioRecord.getMinBufferSize(sampleRate, CHANNEL, ENCODING);
            if (sizeInBytes == AudioRecord.ERROR_BAD_VALUE) {
                continue;
            }
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                final AudioRecord audioRecord = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        sampleRate, CHANNEL, ENCODING, sizeInBytes);

                if (audioRecord.getState() == AudioRecord.STATE_INITIALIZED) {
                    return audioRecord;
                } else {
                    audioRecord.release();
                }
            }
        }
        return null;
    }

//    private boolean isNotificationPermissionGranted(Context context) {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
//            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
//            return notificationManager.isNotificationListenerAccessGranted(new ComponentName(context.getApplicationContext(), NotificationListener.class));
//        } else {
//            return NotificationManagerCompat.getEnabledListenerPackages(context.getApplicationContext()).contains(context.getPackageName());
//        }
//    }
}
