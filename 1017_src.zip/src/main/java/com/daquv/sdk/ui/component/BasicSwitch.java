package com.daquv.sdk.ui.component;

import android.content.Context;
import android.util.AttributeSet;
import androidx.appcompat.widget.SwitchCompat;
import com.daquv.sdk.R;

public class BasicSwitch extends SwitchCompat {

    public BasicSwitch(Context context) {
        super(context);
        init();
    }

    public BasicSwitch(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BasicSwitch(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setTrackResource(R.drawable.basic_switch_track_none);
        setThumbResource(R.drawable.basic_switch_thumb);
    }

    public void onStatePress() {
        setTrackResource(R.drawable.basic_switch_track_on_act);
    }

    public void onStateON() {
        setTrackResource(R.drawable.basic_switch_track_on);
    }

    public void onStateOFF() {
        setTrackResource(R.drawable.basic_switch_track_off);
    }

    public void onStateNone() {
        setTrackResource(R.drawable.basic_switch_track_none);
    }

    @Override
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        if (isPressed()) {
            onStatePress();
        } else {
            if (isChecked()) {
                onStateON();
            } else {
                onStateOFF();
            }
        }
    }
}