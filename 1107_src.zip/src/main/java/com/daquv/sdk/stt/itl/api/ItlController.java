package com.daquv.sdk.stt.itl.api;


import android.os.CountDownTimer;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.text.TextUtils;


import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.stt.itl.ITLModel;
import com.daquv.sdk.utils.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class ItlController {
    private final ItlSocketIoClient stt;
    private final MicInputHandler mic;
    private Boolean started = false;
    private List<byte[]> micq = null;
    private static final int MAX_MICQ = 200;
    private final ItlController.OnResultListener mListener;
    private Thread startWakeUpWithSTTThread = null;
    private CountDownTimer countDownTimer;
    private static final long MILLIS_IN_FUTURE = 5000L;
    private static final long COUNT_DOWN_INTERVAL = 1000L;
    private boolean isTimerRunning = false;
    private Disposable backgroundTask;
    private final Handler mHandler = new Handler(Looper.myLooper()) {
        public void handleMessage(Message msg) {
            if (ItlController.this.mListener != null) {
                ItlController.this.mListener.onResult(msg);
            }

        }
    };
    private final Handler sttResultHandler = new Handler(Looper.myLooper()) {
        public void handleMessage(Message inputMessage) {
            String msg = (String)inputMessage.obj;
            switch (inputMessage.what) {
                case ItlSocketIoClient.JSON_RESULT:
                    try {
                        String result;
                        String status;

                        JSONObject jObj = new JSONObject(msg);
                        result = jObj.getJSONArray("results")
                                .getJSONObject(0)
                                .getString("sentence").trim();
                        status = jObj.getString("status");

                        JSONObject resultObject = new JSONObject();
                        resultObject.put("sentence", result);
                        resultObject.put("return", "SUCCESS");
                        resultObject.put("status", status);

                        ItlController.this.sendSentenceToMainActivity(resultObject.toString());
                        if (status.equals(ITLModel.STATUS.PARTIAL.name())) {
                            ItlController.this.startCountDownTimer(result);
                        }
                    } catch (JSONException e) {
                        Logger.error(e);
                    }
                    break;
                case ItlSocketIoClient.ALERT:
                    ItlController.this.sendAlertToMainActivity(msg);
                    break;
                case ItlSocketIoClient.READY:
                    ItlController.this.sendReadyToMainActivity();
                    ItlController.this.startCountDownTimer(null);
                default:
                    break;
            }

        }
    };

    private void sendAlertToMainActivity(String alert) {
        Message msg = this.mHandler.obtainMessage();
        msg.what = ItlSocketIoClient.ALERT;
        msg.obj = alert;
        this.mHandler.sendMessage(msg);
    }

    private void sendSentenceToMainActivity(String sentence) {
        Message msg = this.mHandler.obtainMessage();
        msg.what = ItlSocketIoClient.JSON_RESULT;
        msg.obj = sentence;
        this.mHandler.sendMessage(msg);
    }

    private void sendReadyToMainActivity() {
        Message msg = this.mHandler.obtainMessage();
        msg.what = ItlSocketIoClient.READY;
        this.mHandler.sendMessage(msg);
    }

    private void sendTimeOutToMainActivity() {
        Message msg = this.mHandler.obtainMessage();
        msg.what = ItlSocketIoClient.TIMEOUT;
        this.mHandler.sendMessage(msg);
    }

    public ItlController(ItlController.OnResultListener listener) {
        this.mListener = listener;
        this.micq = Collections.synchronizedList(new LinkedList());
        this.mic = new MicInputHandler();
        this.mic.setOnProcessMicData(new MicInputHandler.OnProcessMicData() {
            public void onProcessMicData(byte[] audio) {
                if (ItlController.this.micq.size() == MAX_MICQ) {
                    Logger.info("micq full");
                    ItlController.this.micq.clear();
                } else {
                    ItlController.this.micq.add(audio);
                }
            }
        });
        String mHost = DaquvConfig.sttUrl;
        int mPort = DaquvConfig.sttPort;
        this.stt = new ItlSocketIoClient(mHost, mPort, this.sttResultHandler);
    }

    public void pauseMic() {
        this.mic.pause();
    }

    public void resumeMic() {
        this.mic.resume();
    }

    public void startWakeUpWithSTT() {
        if (!this.started) {
            this.mic.start();
            this.started = true;
            this.startWakeUpWithSTTThread = new Thread(new Runnable() {
                public void run() {
                    ItlController.this.wakeUpWithSTT();
                }
            });
            if (this.startWakeUpWithSTTThread != null) {
                try {
                    this.startWakeUpWithSTTThread.start();
                } catch (Exception var2) {
                    Logger.error(var2);
                }
            }

        }
    }



    public void stopWakeupWithSTT() {
        if (this.started) {
            this.started = false;

            try {
                if (this.startWakeUpWithSTTThread != null) {
                    this.startWakeUpWithSTTThread.join();
                    this.startWakeUpWithSTTThread = null;
                }
            } catch (InterruptedException var2) {
                Logger.error(var2);
            }

            this.mic.stop();
            if (this.stt.isConnected()) {
                this.stt.disconnect();
            }

            this.stopCountDownTimer();
        }
    }

    private void wakeUpWithSTT() {
        while(this.started) {
            int mSleepTimeInMs = 10;
            if (this.micq.size() <= 0) {
                SystemClock.sleep(mSleepTimeInMs);
            } else {
                byte[] audio = this.micq.remove(0);
                if (audio != null && audio.length != 0) {
                    if (this.stt.isConnected()) {
                        this.stt.send(audio);
                    }
                } else {
                    SystemClock.sleep(mSleepTimeInMs);
                }
            }
        }

    }

    public void startDoNetworkJob() {
        backgroundTask();
    }

    private void backgroundTask() {
        backgroundTask = Observable.fromCallable(() -> {
                    stt.connect();
                    return false;
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((result) -> {
                    backgroundTask.dispose();

                });
    }

    private void startCountDownTimer(String partialData) {
        if (this.isTimerRunning) {
            this.stopCountDownTimer();
        }

        this.countDownTimer = (new CountDownTimer(MILLIS_IN_FUTURE, COUNT_DOWN_INTERVAL) {
            public void onTick(long l) {
                ItlController.this.isTimerRunning = true;
            }

            public void onFinish() {
                if(!TextUtils.isEmpty(partialData)) {
                    try {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("sentence", partialData);
                        jsonObject.put("return", "SUCCESS");
                        jsonObject.put("status", "FINAL");

                        String jsonString = jsonObject.toString();
                        ItlController.this.sendSentenceToMainActivity(jsonString);
                        ItlController.this.isTimerRunning = false;
                    } catch (JSONException e) {
                        Logger.error(e);
                        ItlController.this.sendTimeOutToMainActivity();
                        ItlController.this.isTimerRunning = false;
                    }
                } else {
                    ItlController.this.sendTimeOutToMainActivity();
                    ItlController.this.isTimerRunning = false;
                }
            }
        }).start();
    }

    private void stopCountDownTimer() {
        if (this.countDownTimer != null) {
            this.countDownTimer.cancel();
            this.isTimerRunning = false;
        }
    }

    public interface OnResultListener {
        void onResult(Message var1);
    }
}
