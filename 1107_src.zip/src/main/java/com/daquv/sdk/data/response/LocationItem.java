package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

public class LocationItem {

    @SerializedName("company_id")
    private String companyId;

    @SerializedName("latitude")
    private double latitude;

    @SerializedName("longitude")
    private double longitude;

    @SerializedName("distance")
    private double distance;

    @SerializedName("company_nm")
    private String companyNm;

    @SerializedName("ceo_nm")
    private String ceoNm;

    @SerializedName("tel")
    private String tel;

    @SerializedName("address")
    private String address;

    @SerializedName("ibtr_yn")
    private String ibtrYN;

    @SerializedName("ibk_kcis_enin_bal")
    private int ibkKcisEninBal;

    @SerializedName("ano_kcis_enin_bal")
    private int anoKcisEninBal;

    private boolean selected;


    public LocationItem() {
    }

    public LocationItem(String companyNm, double latitude , double longitude) {
        this.companyNm = companyNm;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public String getCompanyNm() {
        return companyNm;
    }

    public void setCompanyNm(String companyNm) {
        this.companyNm = companyNm;
    }

    public String getCeoNm() {
        return ceoNm;
    }

    public void setCeoNm(String ceoNm) {
        this.ceoNm = ceoNm;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getIbtrYN() {
        return ibtrYN;
    }

    public void setIbtrYN(String ibtrYN) {
        this.ibtrYN = ibtrYN;
    }

    public int getIbkKcisEninBal() {
        return ibkKcisEninBal;
    }

    public void setIbkKcisEninBal(int ibkKcisEninBal) {
        this.ibkKcisEninBal = ibkKcisEninBal;
    }

    public int getAnoKcisEninBal() {
        return anoKcisEninBal;
    }

    public void setAnoKcisEninBal(int anoKcisEninBal) {
        this.anoKcisEninBal = anoKcisEninBal;
    }
}
