package com.daquv.sdk.presentation;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.ui.component.BasicButtonView;
import com.daquv.sdk.ui.component.BasicSwitch;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.secure.PreventRecordUtils;

public class SettingFragment extends Fragment {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    DaquvEngine.Callback engineCallback;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        PreventRecordUtils.getInstance().setSecureFlag(requireActivity());
        return inflater.inflate(R.layout.fragment_daquv_setting, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ((ImageView) view.findViewById(R.id.setting_close)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onBackPress();
            }
        });



        ((TextView) view.findViewById(R.id.setting_name)).setText("김큐브");
        ((TextView) view.findViewById(R.id.setting_company)).setText("(000지점)");
        ((TextView) view.findViewById(R.id.setting_emn)).setText("000100");

        FrameLayout ttsSwitchLayout = view.findViewById(R.id.tts_setting_switch_container);
        BasicSwitch ttsSwitch = view.findViewById(R.id.tts_setting_switch);

        ttsSwitch.setChecked(DaquvSDK.getInstance().getUseTTS());
        ttsSwitchLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ttsSwitch.setChecked(!ttsSwitch.isChecked());
            }
        });

        ttsSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                DaquvSDK.getInstance().setUseTTS(isChecked);
            }
        });

        ((ImageView) view.findViewById(R.id.btn_setting_argument)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.addHTMLView(getString(R.string.dqv_argument_msg),
                        "https://daquv.com/policy/service",
                        null);
            }
        });

        ((ImageView) view.findViewById(R.id.btn_setting_policy)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.addHTMLView(getString(R.string.dqv_argument_msg),
                        "https://daquv.com/policy/privacy",
                        null);
            }
        });
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);


            }
        };
        DaquvSDK.getInstance().addCallBack(engineCallback);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        onBackPressedCallback.remove();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
    }
}
