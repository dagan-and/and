package com.daquv.sdk.data.request;

import com.daquv.sdk.utils.network.TranJson;

public class NLURequest extends TranJson {

    public NLURequest(String utterance) {
        super();
        put("utterance", utterance);
    }
}