package com.daquv.sdk.ui.comm;


import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.res.ResourcesCompat;

import com.daquv.sdk.R;
import com.daquv.sdk.ui.component.BasicButtonView;


public class ComDialogBuilder implements DialogInterface.OnCancelListener {
    private AlertDialog.Builder mBuilder;
    private AlertDialog mDlg;
    private View mLayout;
    private TextView mTitle;
    private TextView mMessage;
    private BasicButtonView mButtonLeft;
    private BasicButtonView mButtonRight;
    private OnCommDlgClickListener mCallback;

    public interface OnCommDlgClickListener {
        void onLeftButton();
        void onRightButton();
        void onDismiss();
    }

    public ComDialogBuilder(Context context) {
        init(context);
    }

    private void init(Context context) {
        mLayout = View.inflate(context, R.layout.layout_comm_dialog, null);
        mTitle = mLayout.findViewById(R.id.dialog_title);
        mMessage = mLayout.findViewById(R.id.dialog_message);
        mButtonLeft = mLayout.findViewById(R.id.button_left);
        mButtonRight = mLayout.findViewById(R.id.button_right);
        mBuilder = new AlertDialog.Builder(context);
        mBuilder.setView(mLayout);
        setCancelable(true);
    }


    public void showAlert(OnCommDlgClickListener callback, String title, String message, String button, String button2) {
        mTitle.setVisibility(View.VISIBLE);
        mTitle.setText(title);
        mMessage.setText(message);
        mButtonLeft.setText(button);
        mButtonLeft.setOnClickListener(view -> {
            mDlg.dismiss();
            if (mCallback != null) {
                mCallback.onLeftButton();
            }
        });
        mButtonRight.setText(button2);
        mButtonRight.setOnClickListener(view -> {
            mDlg.dismiss();
            if (mCallback != null) {
                mCallback.onRightButton();
            }
        });
        show(callback);
    }

    public void showAlert(OnCommDlgClickListener callback, String message, String button, String button2) {
        mMessage.setText(message);
        mButtonLeft.setText(button);
        mButtonLeft.setOnClickListener(view -> {
            mDlg.dismiss();
            if (mCallback != null) {
                mCallback.onLeftButton();
            }
        });
        mButtonRight.setText(button2);
        mButtonRight.setOnClickListener(view -> {
            mDlg.dismiss();
            if (mCallback != null) {
                mCallback.onRightButton();
            }
        });
        show(callback);
    }

    public void showConfirm(OnCommDlgClickListener callback, String message, String button) {
        mMessage.setText(message);
        mButtonLeft.setVisibility(View.GONE);
        mButtonRight.setText(button);
        mButtonRight.setOnClickListener(view -> {
            mDlg.dismiss();
            if (mCallback != null) {
                mCallback.onRightButton();
            }
        });
        show(callback);
    }

    public AlertDialog show(OnCommDlgClickListener callback) {
        mCallback = callback;
        mDlg = mBuilder.create();
        mDlg.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                if (mCallback != null) {
                    mCallback.onDismiss();
                }
            }
        });
        mDlg.show();
        mDlg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        return mDlg;
    }

    public ComDialogBuilder setCancelable(boolean isCancelable) {
        mBuilder.setCancelable(isCancelable);
        return this;
    }

    public void dismiss() {
        if (mDlg != null && mDlg.isShowing()) {
            mDlg.dismiss();
        }
    }

    @Override
    public void onCancel(DialogInterface p0) {
        if (mCallback == null) return;
        mCallback.onDismiss();
    }
}