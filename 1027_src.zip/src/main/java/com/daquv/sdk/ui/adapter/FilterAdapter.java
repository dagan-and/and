package com.daquv.sdk.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.appcompat.widget.SwitchCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.data.response.MapFilterResponse;
import com.daquv.sdk.data.response.MapFilterValue;
import com.daquv.sdk.ui.component.BasicSwitch;

import java.util.ArrayList;

public class FilterAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_SELECT = 0;
    private static final int TYPE_SWITCH = 1;
    private static final int TYPE_MULTI = 2;

    private ArrayList<MapFilterResponse> filters;

    public interface OnItemClickListener {
        void onItemClick(View v, MapFilterResponse data);
    }

    private OnItemClickListener listener = null;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public FilterAdapter(ArrayList<MapFilterResponse> filters) {
        this.filters = filters;
    }

    @Override
    public int getItemViewType(int position) {
        if("select".equals(filters.get(position).getType())) {
            return TYPE_SELECT;
        } else if("switch".equals(filters.get(position).getType())) {
            return TYPE_SWITCH;
        } else if("multi".equals(filters.get(position).getType())) {
            return TYPE_MULTI;
        } else {
            return super.getItemViewType(position);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflateView;
        if(viewType == TYPE_SELECT || viewType == TYPE_MULTI) {
            inflateView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_filter_select, parent, false);
            return new SelectHolder(inflateView);
        } else if(viewType == TYPE_SWITCH) {
            inflateView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_filter_switch, parent, false);
            return new SwitchHolder(inflateView);
        } else {
            inflateView = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_filter, parent, false);
            return new SelectHolder(inflateView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MapFilterResponse items = filters.get(position);
        if (holder instanceof SelectHolder) {
            SelectHolder dataHolder = (SelectHolder) holder;
            dataHolder.name.setText(items.getName());
            if(getItemViewType(position) == TYPE_MULTI && items.selected.size() >= 2) {
                dataHolder.contents.setText(items.selected.get(0).getName() + "외 " + items.selected.size() + "개");
            } else {
                dataHolder.contents.setText(items.selected.get(0).getName());
            }
            dataHolder.box.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setTag("container");
                    if (listener != null) {
                        listener.onItemClick(v, items);
                    }
                }
            });
        }
        if (holder instanceof SwitchHolder) {
            SwitchHolder dataHolder = (SwitchHolder) holder;
            dataHolder.name.setText(items.getName());
            dataHolder.basicSwitch.setChecked(items.selected.get(0).equals("Y"));
            dataHolder.basicSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    items.selected.clear();
                    if(b) {
                        items.selected.add(new MapFilterValue("Y","Y"));
                    } else {
                        items.selected.add(new MapFilterValue("N","N"));
                    }
                }
            });
            dataHolder.container.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dataHolder.basicSwitch.setChecked(!dataHolder.basicSwitch.isChecked());
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return filters.size();
    }

    public ArrayList<MapFilterResponse> getFilters() {
        return filters;
    }

    public void setFilters(ArrayList<MapFilterResponse> filters) {
        this.filters = filters;
        notifyDataSetChanged();
    }

    static class SelectHolder extends RecyclerView.ViewHolder {
        ConstraintLayout container;
        TextView name;
        LinearLayoutCompat box;
        TextView contents;

        SelectHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.container);
            name = itemView.findViewById(R.id.item_name);
            box = itemView.findViewById(R.id.item_box);
            contents = itemView.findViewById(R.id.item_contents);
        }
    }

    static class SwitchHolder extends RecyclerView.ViewHolder {
        ConstraintLayout container;
        TextView name;
        BasicSwitch basicSwitch;

        SwitchHolder(View itemView) {
            super(itemView);
            container = itemView.findViewById(R.id.container);
            name = itemView.findViewById(R.id.item_name);
            basicSwitch = itemView.findViewById(R.id.item_switch);
        }
    }
}
