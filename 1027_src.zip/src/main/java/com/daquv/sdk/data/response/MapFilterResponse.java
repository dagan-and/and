package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class MapFilterResponse implements Serializable {

    @SerializedName("category")
    private String category;

    @SerializedName("type")
    private String type;

    @SerializedName("search")
    private String search;

    @SerializedName("name")
    private String name;

    @SerializedName("value")
    private ArrayList<MapFilterValue> value;

    public ArrayList<MapFilterValue> selected = new ArrayList<>();

    public MapFilterResponse() {
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<MapFilterValue> getValue() {
        return value;
    }

    public void setValue(ArrayList<MapFilterValue> value) {
        this.value = value;
    }

    public ArrayList<MapFilterValue> getSelected() {
        return selected;
    }

    public void setSelected(ArrayList<MapFilterValue> selected) {
        this.selected = selected;
    }
}
