package com.daquv.sdk.stt.inside;

import com.daquv.sdk.stt.inside.conf.InsideConst;
import com.kt.gigagenie.inside.network.grpc.model.Payload;

import org.json.JSONObject;

public interface OnInsideListener {
    /**
     * GPlugin 모듈 구동 상태 변경 Callback
     *
     * @param status GPlugin 모듈 구동 상태 코드
     */
    void onChangeStatus(InsideConst.Status status);

    /**
     * 음성인식 텍스트 결과 Callback
     *
     * @param result 음성인식 텍스트
     */
    void onVoiceResult(String result);

    /**
     * GPlugin 모듈 에러 Callback
     *
     * @param errCode 에러코드
     * @param errMsg  에러메시지
     */
    void onError(int errCode, String errMsg);

    /**
     * GPlugin 모듈 인식 결과 반환
     *
     * @param intent  인식 결과 Dialog Response - Intent 정보
     * @param appInfo 인식 결과 Dialog Response - appInfo 정보
     * @param sysMsg  인식 결과 Dialog Response - appInfo 정보
     */
    void onCommand(Payload payload, String intent, JSONObject appInfo, String sysMsg);

    /**
     * 음성인식 Buffer Callback
     * @param data  음성 Buffer 데이터
     * @param size  음성 Buffer 사이즈
     */
    void onVoice(short[] data, int size);
}


