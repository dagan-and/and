package com.daquv.sdk.stt.inside.utils;

import android.annotation.SuppressLint;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import androidx.annotation.NonNull;

import com.daquv.sdk.utils.Logger;


public class VoiceRecorder {

    private int[] sampleRateCandidates = new int[0];

    private static final int CHANNEL = AudioFormat.CHANNEL_IN_MONO;
    private static final int ENCODING = AudioFormat.ENCODING_PCM_16BIT;

    private static final int AMPLITUDE_THRESHOLD = 1500;
    private static final int MAX_SPEECH_LENGTH_MILLIS = 15 * 1000;
    private static boolean mIsRecording = false;

    public static class Callback {
        public void onVoiceStart() {
            /*
             * 음성 시작
             */
        }

        public void onVoice(short[] data, int size) {
            /*
             * 음성 데이터 전송
             */
        }

        public void onVoiceEnd() {
            /*
             * 음성 종료
             */
        }
    }

    private final Callback mCallback;

    private AudioRecord mAudioRecord;

    private Thread mThread;

    private short[] mBuffer;

    private final Object mLock = new Object();

    private long mLastVoiceHeardMillis = Long.MAX_VALUE;
    private long mVoiceStartedMillis;

    public VoiceRecorder(@NonNull Callback callback) {
        mCallback = callback;
        /* 모바일과 스크린의 샘플레이트 우선순위 설정 */
//        if (BuildConfig.FLAVOR == "mobile") {
//            SAMPLE_RATE_CANDIDATES = new int[]{16000, 22050, 44100, 11025};
//        } else {
//            SAMPLE_RATE_CANDIDATES = new int[]{44100, 22050, 16000, 11025};
//        }
        sampleRateCandidates = new int[]{16000, 22050, 44100, 11025};
    }

    public void start() {
        // Stop recording if it is currently ongoing.
        stop();
        // Try to create a new recording session.
        mAudioRecord = createAudioRecord();
        if (mAudioRecord == null) {
            return;
        }
        // Start recording.
        try {
            mAudioRecord.startRecording();
        } catch (IllegalStateException e) {
            Logger.error(e);
        }

        // Start processing the captured audio.
        mThread = new Thread(new ProcessVoice());
        mThread.start();
        mIsRecording = true;
    }

    public void stop() {
        mIsRecording = false;
        synchronized (mLock) {
            if (mThread != null) {
                mThread.interrupt();
                mThread = null;
            }
            if (mAudioRecord != null) {
                try {
                    mAudioRecord.stop();
                } catch (Exception ignore) {
                    Logger.error(ignore);
                } finally {
                    mAudioRecord.release();
                    mAudioRecord = null;
                }
            }
            mBuffer = null;
        }
    }

    public void dismiss() {
        if (mLastVoiceHeardMillis != Long.MAX_VALUE) {
            mLastVoiceHeardMillis = Long.MAX_VALUE;
            mCallback.onVoiceEnd();
        }
    }

    /**
     * sampleRate 취득
     *
     * @return
     */
    public int getSampleRate() {
        if (mAudioRecord != null) {
            return mAudioRecord.getSampleRate();
        }
        return 0;
    }

    public int isWakeupVoiceRecorder() {
        if (mAudioRecord != null) {
            return mAudioRecord.getRecordingState();
        }
        return 0;
    }

    @SuppressLint("MissingPermission")
    private AudioRecord createAudioRecord() {
        if (mAudioRecord != null) {

            mAudioRecord.release();
            return mAudioRecord;
        }
        for (int sampleRate : sampleRateCandidates) {
            final int sizeInBytes = AudioRecord.getMinBufferSize(sampleRate, CHANNEL, ENCODING);
            if (sizeInBytes == AudioRecord.ERROR_BAD_VALUE) {
                continue;
            }
            final AudioRecord audioRecord = new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    sampleRate, CHANNEL, ENCODING, sizeInBytes);

            if (audioRecord.getState() == AudioRecord.STATE_INITIALIZED) {

                mBuffer = new short[sizeInBytes];
                return audioRecord;
            } else {

                audioRecord.release();
            }
        }
        return null;
    }


    private class ProcessVoice implements Runnable {
        @Override
        public void run() {
            while (mIsRecording) {
                synchronized (mLock) {
                    if (Thread.currentThread().isInterrupted()) {
                        break;
                    }
                    if(mBuffer == null) {
                        return;
                    }
                    final int size = mAudioRecord.read(mBuffer, 0, mBuffer.length);
                    final long now = System.currentTimeMillis();
                    if (isHearingVoice(mBuffer, size)) {
                        if (mLastVoiceHeardMillis == Long.MAX_VALUE) {
                            mVoiceStartedMillis = now;
                            mCallback.onVoiceStart();
                        }
                        mCallback.onVoice(mBuffer, size);
                        mLastVoiceHeardMillis = now;
                        if (now - mVoiceStartedMillis > MAX_SPEECH_LENGTH_MILLIS) {
                            mCallback.onVoiceEnd();
                        }
                    } else if (mLastVoiceHeardMillis != Long.MAX_VALUE) {
                        if (mIsRecording) {
                            mCallback.onVoice(mBuffer, size);
                        }
                    }
                }
            }
        }

        private boolean isHearingVoice(short[] buffer, int size) {
            for (int i = 0; i < size - 1; i += 2) {
                // The buffer has LINEAR16 in little endian.
                int s = buffer[i + 1];
                if (s < 0) s *= -1;
                s <<= 8;
                s += Math.abs(buffer[i]);
                if (s > AMPLITUDE_THRESHOLD) {
                    return true;
                }
            }
            return false;
        }
    }
}