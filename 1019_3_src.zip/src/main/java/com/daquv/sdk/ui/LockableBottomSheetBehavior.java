package com.daquv.sdk.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

public class LockableBottomSheetBehavior<V extends View> extends BottomSheetBehavior<V> {

    private boolean swipeEnabled = true;

    public LockableBottomSheetBehavior() {
        super();
    }

    public LockableBottomSheetBehavior(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setSwipeEnabled(boolean swipeEnabled) {
        this.swipeEnabled = swipeEnabled;
    }

    @Override
    public boolean onInterceptTouchEvent(CoordinatorLayout parent, V child, MotionEvent event) {
        return swipeEnabled ? super.onInterceptTouchEvent(parent, child, event) : false;
    }

    @Override
    public boolean onTouchEvent(CoordinatorLayout parent, V child, MotionEvent event) {
        return swipeEnabled ? super.onTouchEvent(parent, child, event) : false;
    }

    @Override
    public boolean onStartNestedScroll(
            CoordinatorLayout coordinatorLayout,
            V child,
            View directTargetChild,
            View target,
            int axes,
            int type
    ) {
        return swipeEnabled ? super.onStartNestedScroll(coordinatorLayout, child, directTargetChild, target, axes, type) : false;
    }

    @Override
    public void onNestedPreScroll(
            CoordinatorLayout coordinatorLayout,
            V child,
            View target,
            int dx,
            int dy,
            int[] consumed,
            int type
    ) {
        if (swipeEnabled) {
            super.onNestedPreScroll(coordinatorLayout, child, target, dx, dy, consumed, type);
        }
    }

    @Override
    public void onStopNestedScroll(
            CoordinatorLayout coordinatorLayout,
            V child,
            View target,
            int type
    ) {
        if (swipeEnabled) {
            super.onStopNestedScroll(coordinatorLayout, child, target, type);
        }
    }

    @Override
    public boolean onNestedPreFling(
            CoordinatorLayout coordinatorLayout,
            V child,
            View target,
            float velocityX,
            float velocityY
    ) {
        return swipeEnabled ? super.onNestedPreFling(coordinatorLayout, child, target, velocityX, velocityY) : false;
    }
}
