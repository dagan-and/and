package com.daquv.sdk.stt.inside;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.stt.inside.conf.InsideConfig;
import com.daquv.sdk.stt.inside.conf.InsideConst;
import com.daquv.sdk.stt.inside.utils.VoiceRecorder;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.kt.gigagenie.inside.api.Inside;
import com.kt.gigagenie.inside.api.InsideListener;
import com.kt.gigagenie.inside.network.grpc.model.Payload;
import com.kt.gigagenie.inside.network.grpc.model.SubCmdopt;

import org.json.JSONObject;

/**
 * Genie Inside (GInside) 관리
 *
 */
public class RegisterInsideSDK implements InsideListener {
    private static final String TAG = RegisterInsideSDK.class.getSimpleName();

    private Context mContext;
    private RegisterInsideSDK mInstance;
    private static OnInsideListener mCallback;
    private InsideConst.Status mStatus;

    private Inside insideSDK = null;

    private boolean mIsRecording = false;

    // VoiceRecorder
    private VoiceRecorder mVoiceRecorder;

    // 인식 타입
    private static RecognizeType mRecogType = RecognizeType.RECOGNIZE_DLG_RES;

    /**
     * 인식 타입 코드
     **/
    public enum RecognizeType {
        /**
         * Dialog Response
         */
        RECOGNIZE_DLG_RES,
        // 음성 인식
        RECOGNIZE_SPEECH_TEXT
    }

    /**
     * Singleton Instance 반환
     *
     * @return Instance
     */
    public static RegisterInsideSDK getInstance() {
        return LazyHolder.INSTANCE;
    }

    private static class LazyHolder {
        private static final RegisterInsideSDK INSTANCE = new RegisterInsideSDK();
    }

    public void setConfig(Context context) {
        String id = null;
        String key = null;
        String secret = null;
        String serverIp = null;
        String service = null;
        int grpcPort = 0;
        int resetPort = 0;

        for (AppConfig.InsideInfo info : DaquvConfig.appConfig.insideInfoList) {
            if(info.clientUid.equals(DaquvConfig.insideKey.name())) {
                service = info.clientId;
                id = info.clientId;
                key = info.clientKey;
                secret = info.clientSecret;
                serverIp = info.serverIp;
                grpcPort = info.serverPort;
                resetPort = info.serverResetPort;
                break;
            }
        }

        InsideConfig.initInside(
                id,
                key,
                secret,
                DaquvUtil.getUserKey(context),
                service
        );
        InsideConfig.initServer(
                serverIp,
                String.valueOf(grpcPort),
                String.valueOf(resetPort)
        );
    }


    /**
     * Singleton Instance 반환
     *
     * @param context  Context
     * @param callback Inside Event Callback Listener
     * @return Instance
     */
    @SuppressLint("MissingPermission")
    public void init(Context context, OnInsideListener callback) {
        mContext = context;
        mCallback = callback;

        setConfig(context);

        // try reset before init
        resetInsideSDK(false);

        Inside.agent_setServerInfo(InsideConfig.serverIp, InsideConfig.grpcPort, InsideConfig.resetPort);

        insideSDK = new Inside(mContext, this);

        try {
            String ret = insideSDK.agent_register(InsideConfig.clientId, InsideConfig.clientKey, InsideConfig.clientSecret, InsideConfig.userId);
            Logger.dev(TAG + " registerInsideSDK agent_register ret : " + ret);

            JSONObject jsonObject = new JSONObject(ret);
            int rc = jsonObject.getInt("rc");
            String rcmsg = jsonObject.getString("rcmsg");

            if (rc == 200) {
                initInsideSDK(jsonObject.getString("uuid"));
            } else {
                // 케이스별로 처리 필요
                Logger.error("insideSDK agent_register fail : " + rcmsg);
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(mContext, "INSIDE::" + rcmsg, Toast.LENGTH_SHORT).show();
                    }
                });
                resetInsideSDK(true);
            }
        } catch (Exception e) {
            Logger.error("insideSDK agent_register fail :" + e);
            resetInsideSDK(true);
        }
    }

    /**
     * registerInsideSDK : get UUID
     */
    private RegisterInsideSDK() {

    }

    public boolean isRecording() {
        return mIsRecording;
    }

    /**
     * check UUID is valid
     */
    private void initInsideSDK(String uuid) {

        try {
            String ret = insideSDK.agent_init(InsideConfig.clientId, InsideConfig.clientKey, InsideConfig.clientSecret, uuid);
            Log.d(TAG, "initInsideSDK: " + InsideConfig.clientId +"//"+ InsideConfig.clientKey +"//"+ InsideConfig.clientSecret +"//"+ uuid);
            JSONObject jsonObject = new JSONObject(ret);
            int rc = jsonObject.getInt("rc");
            String rcmsg = jsonObject.getString("rcmsg");

            if (rc == 200) initInsideSDKSuccess(uuid);
            else {
                // init fail
                resetInsideSDK(true);
                // 저장된 UUID 가지고 실패했을 경우
                if (rc == 404) {
                    Logger.dev("insideSDK initInsideSDK invalied UUID --> clear UUID! try retry...");
                    new RegisterInsideSDK();
                } else {
                    Logger.dev("insideSDK initInsideSDK server not working...");
                }
            }
            Log.d(TAG, "initInsideSDK uuid: " + uuid + "/" + rcmsg);
        } catch (Exception e) {
            Logger.info("insideSDK initInsideSDK Exception.. plz retry : " + e);
        }
    }

    private void initInsideSDKSuccess(String uuid) {
        SharedPreferences prefs  = mContext.getSharedPreferences("INSIDE", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("inside_uuid", uuid);
        editor.apply();
        Logger.info("insideSDK initInsideSDK SUCCESS");
    }

    public Inside getInsideSDK() {
        return insideSDK;
    }

    /**
     * insideSDK 를 초기화한다.
     */
    private void resetInsideSDK(boolean isUnregister) {
        // insideSDK 초기화
        if (insideSDK != null) insideSDK.agent_reset();
        insideSDK = null;
        // 음성녹음 해제
        mIsRecording = false;
        stopVoiceRecord();
        // 필요 시 저장된 UUID 삭제
        if (isUnregister) {
            SharedPreferences prefs  = mContext.getSharedPreferences("INSIDE", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.remove("inside_uuid");
        }
    }

    public String getUUID()  {
        SharedPreferences prefs  = mContext.getSharedPreferences("INSIDE", Context.MODE_PRIVATE);
        return prefs.getString("inside_uuid", "");
    }


    public void onPause() {
        if (insideSDK != null && mIsRecording) voiceStop();
        mIsRecording = false;
        setStatus(InsideConst.Status.STOP);
    }

    private void setStatus(InsideConst.Status status) {
        Logger.dev("setStatus() >> Curr Status :: " + mStatus);
        Logger.dev("setStatus() >> status :: " + status);

        onChangeStatus(status);
    }

    @Override
    public void agent_onCommand(String actionType, String json) {
        Logger.dev(TAG + " agent_onCommand actionType : " + actionType + "/ json : " + json);

        // Debugmode 로그용 - 시작
        if (actionType.equals("log_res")) {
            Logger.dev("log_res >> payload : " + json);
            Payload payload = new Gson().fromJson(json, Payload.class);
            if (null != payload.cmdOpt)
                onVoiceResult(payload.cmdOpt.uword);
            return;
        } else if (actionType.equals("log_req")) {
            Logger.dev("log_req >> payload : " + json);
            return;
        }
        // Debugmode 로그용 - 끝

        try {
            Payload payload = new Gson().fromJson(json, Payload.class);

            Logger.dev(TAG + " agent_onCommand" + "and payload : " + payload.toString());
            if (actionType != null) {
                switch (actionType) {
                    case "start_voice":
                        // Mic On 후 음성인식 시작
                        // 여기 들어올 때 미디어가 재생중이라면 pause 시켜준다.
                        mIsRecording = true;
                        startVoiceRecord();

                        setStatus(InsideConst.Status.START_LISTEN);
                        break;
                    case "stop_voice":
                        // 음성인식 중지 (화면이 있는 경우 uword로 전달되는 음성인식 결과를 화면에 노출할 수 있음)
                        Logger.dev(TAG + " agent_onCommand stop_voice!!! uword : " + payload.cmdOpt.uword);

                        mIsRecording = false;
                        stopVoiceRecord();

                        setStatus(InsideConst.Status.STOP_LISTEN);
                        break;
                    case "exec_dialogkit":
                        if (mRecogType == RecognizeType.RECOGNIZE_SPEECH_TEXT) {
                            onCommand(null, null, null, null);
                            break;
                        }

                        // 개발자센터 사이트의 DialogKit에 등록한 정보를 전달하며, payload를 파싱하여 시나리오에 맞게 단말 특화 대화 처리.
                        JsonObject dssMsg = payload.cmdOpt.execOpt.dssMsg;
                        String intent = dssMsg.get("Intent").getAsString();
                        JsonObject appInfo = dssMsg.getAsJsonObject("appInfo");
                        String sysMsg = dssMsg.has("__systemMesg") ? dssMsg.get("__systemMesg").getAsString() : "";
                        JSONObject jobjInfo = new JSONObject();
                        if (appInfo != null && !TextUtils.isEmpty(appInfo.toString())) jobjInfo = new JSONObject(appInfo.toString());

                        onCommand(payload, intent, jobjInfo, sysMsg);
                        break;
                    case "play_media":
                        // TTS 재생의 경우 TTS 메시지 정보와 다른 미디어에 대한 제어 정보 등 전달 (실제 TTS mediastream 정보는 이어서 media_data로 전달)
                        // URL 재생의 경우 재생할 미디어의 URL 정보와 다른 미디어에 대한 제어 정보 등 전달
                        insideSDK.agent_updateMediaStatus(payload.cmdOpt.channel, Inside.MEDIA_STOPPED, 0);
//                        mMediaPlayerHelper.start(payload);
                        break;
                    case "media_data":

                        // TTS mediastream 정보가 전달되며, mediastream값을 base64 decoding하여 재생
//                        mMediaPlayerHelper.startWav(payload);
                        if (mRecogType == RecognizeType.RECOGNIZE_SPEECH_TEXT) {
                            onCommand(null, null, null, null);
                        } else {
                            onError(InsideConst.Error.CODE_FAIL_RECOG, InsideConst.Error.getErrorMsg(mContext, InsideConst.Error.CODE_FAIL_RECOG));
                        }
                        break;
                    default:
                        setStatus(InsideConst.Status.ERROR);
                        onError(InsideConst.Error.CODE_FAIL_RECOG, InsideConst.Error.getErrorMsg(mContext, InsideConst.Error.CODE_FAIL_RECOG));
                        break;
                }
            }
        } catch (Exception e) {
            Logger.info(TAG + " agent_onCommand Exception : " + e);
        }
    }

    @Override
    public void agent_onEvent(int evt, String opt) {
        Logger.dev(TAG + " agent_onEvent evt : " + evt);
        Logger.dev(TAG + " agent_onEvent opt : " + opt);

        switch (evt) {
            case Inside.SERVER_ERROR:
                // 에러코드에 맞게 재시도 또는 클라이언트 초기화 후 재시도
                Logger.dev(TAG + " agent_onEvent SERVER_ERROR opt : " + opt);
                new Handler(Looper.getMainLooper()).post(() -> {
                    SubCmdopt subCmdopt;

                    mIsRecording = false;
                    stopVoiceRecord();

                    try {
                        subCmdopt = new Gson().fromJson(opt, SubCmdopt.class);
                        setStatus(901 == subCmdopt.errorCode ? InsideConst.Status.STOP : InsideConst.Status.ERROR);
                        onError(subCmdopt.errorCode, InsideConst.Error.getErrorMsg(mContext, subCmdopt.errorCode));
                    } catch (Exception e) {
                        onError(InsideConst.Error.CODE_FAIL_PARSING, InsideConst.Error.getErrorMsg(mContext, InsideConst.Error.CODE_FAIL_PARSING));
                    }
                });
                break;
            case Inside.GO_TO_STANDBY:
                //음성명령 대기상태로 전환, 미디어 서비스 상태는 유지
                Logger.dev(TAG + " GO_TO_STANDBY");
                new Handler(Looper.getMainLooper()).post(() -> {
                    try {
                        SubCmdopt subCmdopt;
                        subCmdopt = new Gson().fromJson(opt, SubCmdopt.class);
                        onError(subCmdopt.errorCode, InsideConst.Error.getErrorMsg(mContext, subCmdopt.errorCode));
                    } catch (Exception e) {
                        onError(InsideConst.Error.CODE_FAIL_PARSING, InsideConst.Error.getErrorMsg(mContext, InsideConst.Error.CODE_FAIL_PARSING));
                    }
                });
                break;
            case Inside.GRPC_INIT_SUCCESS:
                // gRPC 연결 성공 (필요에 따라 메시지 출력)
                Logger.dev(TAG + " agent_onEvent GRPC_INIT_SUCCESS");
                if (mCallback != null)
                    mCallback.onChangeStatus(InsideConst.Status.INIT);
                break;
            case Inside.GRPC_INIT_FAIL:
                // gRPC 연결 실패 --> 연결 재시도
                Logger.dev(TAG + " agent_onEvent GRPC_INIT_FAIL");
                break;
            case Inside.GRPC_DISCONNECTED:
                // gRPC 연결 끊김 (필요에 따라 메시지 출력)
                // TODO 앱 종료
                Logger.dev(TAG + " agent_onEvent GRPC_DISCONNECTED opt : " + opt);
                break;
            default:
                Logger.dev(TAG + " agent_onEvent evt : " + evt);
                break;
        }
    }

    public void onChangeStatus(InsideConst.Status status) {
        // 이전 상태와 다른 경우 (상태가 변경된 경워) 에만 Callback
        new Handler(Looper.getMainLooper()).post(() -> {
            if (mStatus != status && mCallback != null)
                mCallback.onChangeStatus(status);
            mStatus = status;
        });
    }

    /**
     * 음성인식 텍스트 결과 Callback
     *
     * @param result 음성인식 텍스트
     */
    public void onVoiceResult(String result) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (mCallback != null && null != result)
                mCallback.onVoiceResult(result);
        });
    }

    /**
     * GPlugin 모듈 에러 Callback
     *
     * @param errCode 에러코드
     * @param errMsg  에러메시지
     */
    public void onError(int errCode, String errMsg) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (mCallback != null)
                mCallback.onError(errCode, errMsg);
        });
    }

    /**
     * GPlugin 모듈 인식 결과 반환
     *
     * @param intent  인식 결과 Dialog Response - Intent 정보
     * @param appInfo 인식 결과 Dialog Response - appInfo 정보
     * @param sysMsg  인식 결과 Dialog Response - appInfo 정보
     */
    public void onCommand(Payload payload, String intent, JSONObject appInfo, String sysMsg) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (mCallback != null)
                mCallback.onCommand(payload, intent, appInfo, sysMsg);
        });

    }

    /**
     * 음성인식 시작 요청
     */
    public void voiceStart() {
        if(insideSDK == null) {
            Toast.makeText(mContext, "음성 모듈 초기화에 실패했습니다.", Toast.LENGTH_SHORT).show();
            return;
        }
        voiceStart(false);
    }

    /**
     * 음성인식 시작 요청
     */
    public void voiceStart(boolean isNative) {
        mRecogType = isNative ? RecognizeType.RECOGNIZE_SPEECH_TEXT : RecognizeType.RECOGNIZE_DLG_RES;

        // 기존에 음성녹음중이라면 멈춘다.
        stopVoiceRecord();
        // 음성시작 요청한다.
        insideSDK.agent_startVoice();
    }

    /**
     * 음성인식 중지 요청
     */
    public void voiceStop() {
        // 녹음 모듈 초기화
        stopVoiceRecord();
        // 음성인식 중이었다면, 중지 요청한다.
        if (mIsRecording) insideSDK.agent_stopVoice();
    }

    /**
     * 텍스트 인식 요청
     */
/*    private void sendText(String msg) {
        voiceStop();
        insideSDK.agent_sendText(msg);
    }*/

    /**
     * 음성인식 시작
     */
    private void startVoiceRecord() {

        stopVoiceRecord();

        mVoiceRecorder = new VoiceRecorder(mVoiceCallback);
        mVoiceRecorder.start();
    }

    /**
     * 음성인식 progress bar 없애고, 음성녹음모듈 초기화한다.
     */
    private void stopVoiceRecord() {
        if (mVoiceRecorder != null) {
            mVoiceRecorder.stop();
            mVoiceRecorder = null;
        }
    }

    /**
     * 음성인식 시 callback
     */
    private final VoiceRecorder.Callback mVoiceCallback = new VoiceRecorder.Callback() {
        @Override
        public void onVoiceStart() {
            Logger.dev(TAG + " mVoiceCallback onVoiceStart 프로파일 생성");
        }

        @Override
        public void onVoice(short[] data, int size) {
            int total = 0;
            for (int i = 0; i < 160; ++i) {
                total += Math.abs(data[i]);
            }
            float average = (float) (total / 160) / 100 - 3;
            if (average < 0) average = 0.0f;
            else if (average > 10) average = 10.0f;

            try {
                mCallback.onVoice(data, size);
                insideSDK.agent_sendVoice(data, size);
            } catch (Exception e) {
                Logger.info(TAG + " agent_sendVoice Exception : " + e);
            }
        }

        @Override
        public void onVoiceEnd() {
            Logger.dev(TAG + " mVoiceCallback onVoiceEnd");
        }
    };

    private void agentReset() {
        resetInsideSDK(false);
    }

    /**
     * Singleton Instance 반환
     *
     * @return Instance
     */
    public RegisterInsideSDK isRemainInstance() {
        return  mInstance;
    }

    public void onDestroy() {
        mInstance = null;
        agentReset();
    }

    public void removeSdk() {
        mInstance = null;
    }
}