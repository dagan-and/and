package com.daquv.sdk.network;

import android.text.TextUtils;
import android.util.Log;

import com.daquv.sdk.DaquvConfig;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.logging.HttpLoggingInterceptor;

public class HttpClient {

    private final Call call;

    public static class Builder {

        private final OkHttpClient.Builder okhttpBuilder;
        private CookieJar cookie;
        private String url;
        private boolean addJWTToken = true;
        private boolean addIBKToken = false;
        private String jsonData = "";
        private boolean isPost = true;
        private boolean isLogging = false;
        private RequestBody requestBody = null;
        private HashMap<String, String> setParameter = null;
        private HashMap<String, String> setHeader = null;
        private ETagCache cache;
        private int timeout = 15;


        public Builder() {
            this.okhttpBuilder = new OkHttpClient.Builder();
        }

        public Builder setCookie(CookieJar cookie) {
            this.cookie = cookie;
            return this;
        }

        public Builder setUrl(String url) {
            this.url = url;
            return this;
        }

        public Builder addJWTToken(boolean addToken) {
            this.addJWTToken = addToken;
            return this;
        }

        public Builder addIBKToken(boolean addToken) {
            this.addIBKToken = addToken;
            return this;
        }

        public Builder setJsonData(String data) {
            this.jsonData = data;
            return this;
        }

        public Builder isPost(boolean isPost) {
            this.isPost = isPost;
            return this;
        }

        public Builder isLogging(boolean isLogging) {
            this.isLogging = isLogging;
            return this;
        }

        public Builder setBody(RequestBody body) {
            this.requestBody = body;
            return this;
        }

        public Builder setParameter(HashMap<String, String> parameter) {
            this.setParameter = parameter;
            return this;
        }

        public Builder setHeader(HashMap<String, String> parameter) {
            this.setHeader = parameter;
            return this;
        }

        public Builder setCache(ETagCache cache) {
            this.cache = cache;
            return this;
        }

        public Builder setTimeout(int timeout) {
            this.timeout = timeout;
            return this;
        }

        public HttpClient builder() {
            return new HttpClient(this);
        }

    }

    public HttpClient(Builder builder) {
        builder.okhttpBuilder.connectTimeout(builder.timeout, TimeUnit.SECONDS);
        builder.okhttpBuilder.readTimeout(builder.timeout, TimeUnit.SECONDS);
        builder.okhttpBuilder.writeTimeout(builder.timeout, TimeUnit.SECONDS);
        builder.okhttpBuilder.callTimeout(builder.timeout ,TimeUnit.SECONDS);
        builder.okhttpBuilder.cookieJar(builder.cookie);
        builder.okhttpBuilder.retryOnConnectionFailure(false);

        Request.Builder request = new Request.Builder();
        RequestBody body = null;
        if(DaquvConfig.isDebug) {
            if(builder.isLogging) {
                builder.okhttpBuilder.addInterceptor(httpLoggingInterceptor(HttpLoggingInterceptor.Level.BODY));
            } else {
                builder.okhttpBuilder.addInterceptor(httpLoggingInterceptor(HttpLoggingInterceptor.Level.HEADERS));
            }
        }
        OkHttpClient okHttpClient = builder.okhttpBuilder.build();

        request.url(builder.url);

        if(builder.addIBKToken &&  !TextUtils.isEmpty(DaquvConfig.ibkToken)) {
            request.addHeader("JWT_TOKEN",DaquvConfig.ibkToken);
        } else {
            if(builder.addJWTToken) {
                request.addHeader("JWT_TOKEN",DaquvConfig.jwtToken);
            }
        }
        request.addHeader("User-Agent","AOS");

        if(builder.setHeader != null) {
            for(String key : builder.setHeader.keySet() ) {
                request.addHeader(key, Objects.requireNonNull(builder.setHeader.get(key)));
            }
        }

        if(!TextUtils.isEmpty(builder.jsonData)) {
            body = RequestBody.create(builder.jsonData, MediaType.parse("application/json"));
        }
        if(builder.requestBody != null) {
            body = builder.requestBody;
        }
        if(builder.isPost && body != null) {
            request.post(body);
        } else {
            HttpUrl.Builder urlBuilder = Objects.requireNonNull(HttpUrl.parse(builder.url)).newBuilder();
            if(builder.setParameter != null) {
                for(String key : builder.setParameter.keySet() ) {
                    urlBuilder.addQueryParameter(key, builder.setParameter.get(key));
                }
            }
            if(!TextUtils.isEmpty(builder.cache.get(urlBuilder.build().toString()))) {
                request.addHeader("If-None-Match", builder.cache.get(urlBuilder.build().toString()));
            }
            request.url(urlBuilder.build());
            request.get();
        }
        call = okHttpClient.newCall(request.build());
    }

    public Call getCall() {
        return call;
    }


    private HttpLoggingInterceptor httpLoggingInterceptor(HttpLoggingInterceptor.Level level) {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor(new HttpLoggingInterceptor.Logger() {
            @Override
            public void log(@NotNull String s) {
                Log.d("DAQUV_API",s);
            }
        });
        return interceptor.setLevel(level);
    }
}
