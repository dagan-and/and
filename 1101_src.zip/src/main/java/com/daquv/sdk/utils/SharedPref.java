package com.daquv.sdk.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;

public class SharedPref {

    /** SharedPreference Instance */
    private static SharedPref mInstance;
    /** SharedPreferences */
    private static SharedPreferences mPref;

    /**
     * 초기화
     * @param context Context
     */
    public static void initialize (Context context) {
        if(mPref == null) {
            mPref = context.getSharedPreferences("DAQUV", Context.MODE_PRIVATE);
        }
    }

    /**
     * SharedPref Instance 생성, 반환 <br>
     * @return SharedPref Single Instance
     */
    public static SharedPref getInstance() {
        if (mInstance == null) {
            mInstance = new SharedPref();
        }
        return mInstance;
    }



    /**
     * 데이터 저장
     * @param key 데이터 Key
     * @param val 데이터
     */
    public void put ( String key, String val) {
        mPref.edit().putString(key, val).apply();
    }

    /**
     * String 데이터 반환
     * @param key 데이터 Key
     * @return 데이터 (Key 에 해당하는 데이터가 없는 경우 "" 반환)
     */
    public String getString( String key) {
        if(mPref == null) {
            return "";
        }
        return mPref.getString(key, "");
    }

    /**
     * 데이터 저장
     * @param key 데이터 Key
     * @param val 데이터
     */
    public void put ( String key, int val) {
        mPref.edit().putInt(key, val).apply();
    }

    /**
     * int 데이터 반환
     * @param key 데이터 Key
     * @return 데이터 (Key 에 해당하는 데이터가 없는 경우 0 반환)
     */
    public int getInt( String key) {
        if(mPref == null) {
            return 0;
        }
        return mPref.getInt(key, 0);
    }

    /**
     * 데이터 저장
     * @param key 데이터 Key
     * @param val 데이터
     */
    public void put ( String key, long val) {
        mPref.edit().putLong(key, val).apply();
    }

    /**
     * long 데이터 반환
     * @param key 데이터 Key
     * @return 데이터 (Key 에 해당하는 데이터가 없는 경우 0 반환)
     */
    public long getLong( String key) {
        if(mPref == null) {
            return 0;
        }
        return mPref.getLong(key, 0);
    }

    /**
     * 데이터 저장
     * @param key 데이터 Key
     * @param val 데이터
     */
    public void put ( String key, float val) {
        mPref.edit().putFloat(key, val).apply();
    }

    /**
     * float 데이터 반환
     * @param key 데이터 Key
     * @return 데이터 (Key 에 해당하는 데이터가 없는 경우 0 반환)
     */
    public float getFloat( String key) {
        if(mPref == null) {
            return 0;
        }
        return mPref.getFloat(key, 0);
    }

    /**
     * 데이터 저장
     * @param key 데이터 Key
     * @param val 데이터
     */
    public void put ( String key, boolean val) {
        mPref.edit().putBoolean(key, val).apply();
    }

    /**
     * boolean 데이터 반환
     * @param key 데이터 Key
     * @return 데이터 (Key 에 해당하는 데이터가 없는 경우 false 반환)
     */
    public boolean getBoolean( String key) {
        if(mPref == null) {
            return false;
        }
        return mPref.getBoolean(key, false);
    }

    public boolean getBoolean( String key, Boolean defaultValue) {
        if(mPref == null) {
            return false;
        }
        return mPref.getBoolean(key, defaultValue);
    }

    /**
     * 데이터 Key 존재 여부 반환
     * @param key 데이터 Key
     * @return 데이터 Key 존재 여부 (true : 데이터 Key 존재 / false : 데이터 Key 미존재)
     */
    public boolean contains( String key) {
        return mPref.contains(key);
    }

    /**
     * Preference 해당 KEY-Value 삭제 <br>
     */
    @SuppressLint("CommitPrefEdits")
    public void remove( String key) {
        mPref.edit().remove(key).apply();
    }

    /**
     * Preference Data 전체 삭제 <br>
     */
    @SuppressLint("CommitPrefEdits")
    public void clear() {
        mPref.edit().clear().apply();
    }

}
