package com.daquv.sdk.webview;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.daquv.sdk.BuildConfig;
import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.data.response.StopoverList;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.network.JSONHelper;
import com.daquv.sdk.webview.action.DefaultAction;
import com.daquv.sdk.webview.action.WebActionBridge;
import com.daquv.sdk.webview.action.WebActionInfo;
import com.daquv.sdk.webview.client.ComWebChromeClient;
import com.daquv.sdk.webview.client.ComWebClient;
import com.daquv.sdk.webview.constant.WebConst;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;

public class ComWebView extends WebView {


    OnWebActionListener onWebActionListener;
    String blurCSS;

    public ComWebView(Context context) {
        super(context);
        initialize();
    }

    public ComWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    public ComWebView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initialize();
    }

    public interface OnWebActionListener {
        void onShortCut(String utterance);
        void onClose();
        void onSTT(boolean start);
        void onHome();
        void onSetting();
        void onConsult(String companyId , String companyNm);
        void onMap(String companyNm, String lat , String lon);
        void onNavi(ArrayList<LocationItem> items);
        void onCall(String number);
        void onBrowser(String url);
        void onDataPage(String json);
        void onCapture();
        void onBottomView(boolean isVisible);
        void onPageLoad(boolean loading);
    }



    @SuppressLint("SetJavaScriptEnabled")
    private void initialize() {
        setWebViewClient(new ComWebClient(this));
        setWebChromeClient(new ComWebChromeClient(this));

        setWebContentsDebuggingEnabled(DaquvConfig.isDebug);
        setLayerType(LAYER_TYPE_HARDWARE, null);


        WebSettings webSettings = getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true); // 자바스크립트가 window.open()을 사용가능
        webSettings.setSupportMultipleWindows(true); // 다중 윈도우 허용(팝업을 위해 추가)

        setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webSettings.setSupportZoom(false);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setTextZoom(100);

        // UserAgent 설정
        String userAgent = webSettings.getUserAgentString();
        Logger.dev("Default userAgent :: " + userAgent);
        try {
            Map<String, Object> deviceInfo = JSONHelper.toHashMap(DaquvUtil.getDeviceInfo(getContext()));
            Set<String> keySet = deviceInfo.keySet();
            for (String key : keySet) {
                userAgent += ";" + key + "=" + deviceInfo.get(key);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Logger.dev("Custom userAgent :: " + userAgent);
        webSettings.setUserAgentString(userAgent);

        // net::ERR_CACHE_MISS 이슈 수정을 위한 캐시 모드 설정
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        initBridge(new WebActionBridge());

        //===== 롱클릭 방지 =====
        setOnLongClickListener(new OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return true;
            }
        });
        setLongClickable(false);
        setHapticFeedbackEnabled(false);
        //===================
    }

    public void addListener(OnWebActionListener listener) {
        this.onWebActionListener = listener;
    }

    public void loadMainPage() {
        loadDataWithBaseURL(DaquvSDK.getInstance().getAPI().getMainUrl(),
                DaquvSDK.getInstance().getAPI().getMainData(),
                "text/html", "UTF-8", null);
    }

    public void loadDataPage() {
        loadDataWithBaseURL(DaquvSDK.getInstance().getAPI().getResultUrl(),
                DaquvSDK.getInstance().getAPI().getResultData(),
                "text/html", "UTF-8", null);
    }

    public void onPageStarted() {
        onWebActionListener.onPageLoad(true);
        Logger.dev("onPageStarted");
    }

    public void onPageFinished() {
        onWebActionListener.onPageLoad(false);
        Logger.dev("onPageFinished");
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        onDestroy();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
    }



    /**
     * WebView Destroy
     */
    public void onDestroy() {
        Logger.info("destroyWebView () call");
        clearCache(true);
        clearHistory();
        removeJavascriptInterface(WebConst.WebAction.HUB_INTERFACE_NAME);
        removeJavascriptInterface(WebConst.WebAction.SDK_INTERFACE_NAME);
        stopLoading();
        removeAllViews();
        destroy();
    }

    public void onWebViewError(ConsoleMessage consoleMessage) {
        // 콘솔 로그를 크래시 리포트에 저장
        String[] webCallStack = {consoleMessage.sourceId(), String.valueOf(consoleMessage.lineNumber())};
        String[] callStack = new String[webCallStack.length];
        System.arraycopy(webCallStack, 0, callStack, 0, webCallStack.length);
        if (consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.WARNING ||
                consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
            Logger.web(consoleMessage);
        }
    }

    public void initBridge(WebActionBridge bridge) {
        addJavascriptInterface(bridge, WebConst.WebAction.HUB_INTERFACE_NAME);
        addJavascriptInterface(bridge, WebConst.WebAction.SDK_INTERFACE_NAME);
        bridge.loadAction(new DefaultAction(bridge, new DefaultAction.WebActionCallback() {
            @Override
            public void event(WebActionInfo webActionInfo) {
                String actionCode = webActionInfo.getActionCode();
                if ("webResultTTS".equals(actionCode) || "gotts".equals(actionCode)) {
                    if (SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_USE_TTS, true)) {
                        JSONObject actionDataJson = webActionInfo.getActionData();
                        String data = actionDataJson.optString("_data");
                        String callback = "";
                        if(actionDataJson.has("_call_back")) {
                            callback = actionDataJson.optString("_call_back");
                        }
                        if(actionDataJson.has("_data2")) {
                            callback = actionDataJson.optString("_data2");
                        }
                        if(!TextUtils.isEmpty(data)) {
                            DaquvSDK.getInstance().getAPI().getTTSBinary(data, callback, DaquvConfig.CODE.API_NLU_SUCCESS);
                        }
                        if(onWebActionListener != null) {
                            onWebActionListener.onBottomView(TextUtils.isEmpty(callback) || (!"startSTT".equalsIgnoreCase(callback) && !"Y".equalsIgnoreCase(callback)));
                        }
                    }
                }

                if("loading".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        JSONObject actionDataJson = webActionInfo.getActionData();
                        String data = actionDataJson.optString("_data");
                        if(data.equalsIgnoreCase("Y")) {
                            onWebActionListener.onPageLoad(true);
                        } else {
                            onWebActionListener.onPageLoad(false);
                        }
                    }
                }

                if ("startSTT".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        onWebActionListener.onSTT(true);
                    }
                }

                if ("stopSTT".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        onWebActionListener.onSTT(false);
                    }
                }

                // 질의로 바로 이동하기
                if ("stttext".equals(actionCode)) {
                    DaquvSDK.getInstance().getEngine().cleanState();
                    JSONObject actionDataJson = webActionInfo.getActionData();
                    String data = actionDataJson.optString("stt");
                    if(onWebActionListener != null) {
                        onWebActionListener.onShortCut(data);
                    }
                }

                // 질의로 바로 이동하기
                if ("gonlu".equals(actionCode)) {
                    DaquvSDK.getInstance().getEngine().cleanState();
                    JSONObject actionDataJson = webActionInfo.getActionData();
                    String data = actionDataJson.optString("_data");
                    if(onWebActionListener != null) {
                        onWebActionListener.onShortCut(data);
                    }
                }

                // 화면 종료하기
                if ("closeWindow".equals(actionCode) || "goclose".equals(actionCode) || "godismiss".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        onWebActionListener.onClose();
                    }
                }

                // 메인화면으로 이동
                if("gohome".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        onWebActionListener.onHome();
                    }
                }

                // 설정화면으로 이동
                if("gosetting".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        onWebActionListener.onSetting();
                    }
                }

                // 전화 걸기
                if("gocall".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        JSONObject actionDataJson = webActionInfo.getActionData();
                        String data = actionDataJson.optString("_data");
                        onWebActionListener.onCall(data);
                    }
                }

                // 상담화면 이동
                if("goconsult".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        JSONObject actionDataJson = webActionInfo.getActionData();
                        String data = actionDataJson.optString("_data");
                        String data2 = actionDataJson.optString("_data2");
                        onWebActionListener.onConsult(data , data2);
                    }
                }

                //지도화면 호출(현재위치)
                if("gocurmap".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        onWebActionListener.onMap(null, null , null);
                    }
                }

                //지도화면 호출(특정 위치)
                if("gospcmap".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        JSONObject actionDataJson = webActionInfo.getActionData();
                        String lat = String.valueOf(DaquvSDK.getInstance().getLocation().getLatitude());
                        String lon = String.valueOf(DaquvSDK.getInstance().getLocation().getLongitude());
                        String name = "내 위치";
                        if(actionDataJson.has("_data")) {
                            lat = actionDataJson.optString("_data");
                        }
                        if(actionDataJson.has("_data2")) {
                            lon = actionDataJson.optString("_data2");
                        }
                        if(actionDataJson.has("_data3")) {
                            name = actionDataJson.optString("_data3");
                        }
                        onWebActionListener.onMap(name, lat, lon);
                    }
                }

                //길찾기
                if("gonavi".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        JSONObject actionDataJson = webActionInfo.getActionData();
                        ArrayList<LocationItem> item = new ArrayList<>();
                        item.add(new LocationItem("내 위치",
                                DaquvSDK.getInstance().getLocation().getLatitude(),
                                DaquvSDK.getInstance().getLocation().getLongitude()));

                        item.add(new LocationItem(actionDataJson.optString("_data3"),
                                actionDataJson.optDouble("_data"),
                                actionDataJson.optDouble("_data2")));
                        onWebActionListener.onNavi(item);
                    }
                }

                //다중 길찾기
                if("gomultinavi".equals(actionCode)) {
                    JSONObject actionDataJson = webActionInfo.getActionData();
                    ArrayList<LocationItem> item = new ArrayList<>();
                    item.add(new LocationItem("내 위치",
                            DaquvSDK.getInstance().getLocation().getLatitude(),
                            DaquvSDK.getInstance().getLocation().getLongitude()));

                    String json = actionDataJson.optString("_data");
                    Gson gson = new Gson();
                    StopoverList stopoverList = gson.fromJson(json, StopoverList.class);
                    for(StopoverList.Stopover data : stopoverList.stopovers) {
                        item.add(new LocationItem(data.companyName, data.latitude, data.longitude));
                    }
                    onWebActionListener.onNavi(item);
                }

                //외부 브라우저 이동
                if("gobrowser".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        JSONObject actionDataJson = webActionInfo.getActionData();
                        onWebActionListener.onBrowser(actionDataJson.optString("_data"));
                    }
                }

                //답변화면으로 이동
                if("godatapage".equals(actionCode)) {
                    if(onWebActionListener != null) {
                        JSONObject actionDataJson = webActionInfo.getActionData();
                        onWebActionListener.onDataPage(actionDataJson.optString("_data"));
                    }
                }
            }
        }));
    }

    public void onBackPress() {
        if(DaquvConfig.service == DaquvConfig.SERVICE.POSCO ||
            DaquvConfig.service == DaquvConfig.SERVICE.POSCO_SYS) {
            evaluateJavascript("javascript:getPopupState()", new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String s) {
                    try {
                        int number = Integer.parseInt(s);
                        if(number == 2) {
                            loadUrl("javascript:closePopup2()");
                        } else if(number == 3) {
                            loadUrl("javascript:closePopup3()");
                        } else if(number == 4) {
                            loadUrl("javascript:closePartPopup2()");
                        } else if(number >= 5) {
                            loadUrl("javascript:closeOption()");
                        } else {
                            if(onWebActionListener != null) {
                                onWebActionListener.onClose();
                            }
                        }
                    } catch (Exception e) {
                        if(onWebActionListener != null) {
                            onWebActionListener.onClose();
                        }
                    }
                }
            });
        } else if(DaquvConfig.service == DaquvConfig.SERVICE.IBKCRM) {
            evaluateJavascript("javascript:targetClosePopupId()", new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String s) {
                    if(TextUtils.isEmpty(s) || "null".equals(s)) {
                        if(onWebActionListener != null) {
                            onWebActionListener.onClose();
                        }
                    } else {
                        loadUrl("javascript:closePopupCom("+ s+ ")");
                    }
                }
            });
        } else {
            evaluateJavascript("javascript:getDepthState()", new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String s) {
                    if(s.equals("1")) {
                        if(onWebActionListener != null) {
                            onWebActionListener.onClose();
                        }
                    } else if(s.equals("2")) {
                        loadUrl("javascript:close2Depth()");
                    } else if(s.equals("3")) {
                        loadUrl("javascript:close3Depth()");
                    } else {
                        if(onWebActionListener != null) {
                            onWebActionListener.onClose();
                        }
                    }
                }
            });
        }

        /* 뒤로가기 가능한지 체크
        if(canGoBack()) {
            loadUrl("javascript:history.back()");
        } else {
            activity.finish();
        }
        */
    }
}