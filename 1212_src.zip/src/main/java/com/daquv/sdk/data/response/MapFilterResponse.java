package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class MapFilterResponse implements Serializable {

    @SerializedName("category")
    private String category;

    @SerializedName("type")
    private String type;

    @SerializedName("search")
    private String search;

    @SerializedName("name")
    private String name;

    @SerializedName("allYn")
    private String allYn;

    @SerializedName("defaultValue")
    private String defaultValue;

    @SerializedName("value")
    private ArrayList<FilterValue> value;

    @SerializedName("selected")
    private ArrayList<FilterValue> selected;

    public MapFilterResponse() {
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<FilterValue> getValue() {
        return value;
    }

    public void setValue(ArrayList<FilterValue> value) {
        this.value = value;
    }

    public ArrayList<FilterValue> getSelected() {
        if(selected == null) {
            selected = new ArrayList<>();
        }
        return selected;
    }

    public void setSelected(ArrayList<FilterValue> selected) {
        this.selected = selected;
    }

    public String getAllYn() {
        return allYn;
    }

    public void setAllYn(String allYn) {
        this.allYn = allYn;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
}
