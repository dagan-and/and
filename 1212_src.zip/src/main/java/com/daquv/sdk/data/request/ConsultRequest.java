package com.daquv.sdk.data.request;

import com.daquv.sdk.utils.network.TranJson;

public class ConsultRequest extends TranJson {

    public ConsultRequest(String companyId,String entNm, String dscsnDe, String dscsnTime, String dscsnCn, String dscsnCd, String resTypeCd) {
        super();
        put("companyId",companyId);
        put("entNm", entNm);
        put("dscsnDe", dscsnDe);
        put("dscsnTime", dscsnTime);
        put("dscsnCn", dscsnCn);
        put("dscsnCd", dscsnCd);
        put("rgsTypeCd", resTypeCd);
    }
}