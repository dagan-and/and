package com.daquv.sdk.ui.adapter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.R;

public class FilterItemAdapterDecoration extends RecyclerView.ItemDecoration {
    private final Paint paint;

    public FilterItemAdapterDecoration(Context context) {
        this.paint = new Paint();
        this.paint.setColor(ContextCompat.getColor(context, R.color.dqv_line2));
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        super.getItemOffsets(outRect, view, parent, state);
        outRect.bottom = 1;
    }

    @Override
    public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
        int left = parent.getPaddingStart();
        int right = parent.getWidth() - parent.getPaddingEnd();

        for (int i = 0; i < parent.getChildCount() - 1; i++) {
            View child = parent.getChildAt(i);
            RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child.getLayoutParams();

            float top = child.getBottom() + params.bottomMargin;
            float bottom = top + 1;

            c.drawRect(left, top, right, bottom, paint);
        }
    }
}
