package com.daquv.sdk.ui;

import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED;
import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_HIDDEN;
import static com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_SETTLING;

import android.app.Activity;
import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;

import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.R;
import com.daquv.sdk.data.response.MapFilterResponse;
import com.daquv.sdk.data.response.FilterValue;
import com.daquv.sdk.ui.adapter.FilterItemAdapter;
import com.daquv.sdk.ui.adapter.FilterItemAdapterDecoration;
import com.daquv.sdk.ui.component.BasicButtonView;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.search.KoreanTextMatch;
import com.daquv.sdk.utils.search.KoreanTextMatcher;
import com.google.android.material.bottomsheet.BottomSheetBehavior;

import java.util.ArrayList;

public class FilterBottomSheetView {
    public interface OnStateListener {
        void onStateChanged(int newState);

        void onItemClick(String category, ArrayList<FilterValue> data);
    }

    private final Activity context;
    private final OnStateListener listener;
    private final BottomSheetBehavior<View> bottomSheetView;
    private final ImageView matchHeightView;
    private final RecyclerView recyclerView;
    private final LinearLayoutCompat naviView;
    private final ConstraintLayout titleSearch;
    private final AppCompatEditText editText;
    private final FilterItemAdapter adapter;
    private ArrayList<FilterValue> originalData;
    private final BasicButtonView btnConfirm;
    private TYPE type;

    public enum TYPE {
        NONE,
        SEARCH,
        NAVI
    }

    public FilterBottomSheetView(Activity context,
                                 ViewGroup view,
                                 ArrayList<FilterValue> listItem,
                                 OnStateListener listener) {
        this.context = context;
        this.listener = listener;


        bottomSheetView = BottomSheetBehavior.from(view);
        this.matchHeightView = view.findViewById(R.id.match_height_view);
        this.btnConfirm = view.findViewById(R.id.btn_confirm);
        this.recyclerView = view.findViewById(R.id.recycler_view);
        this.naviView = view.findViewById(R.id.navi_view);
        this.titleSearch = view.findViewById(R.id.title_search);
        this.editText = view.findViewById(R.id.edit_text);
        this.adapter = new FilterItemAdapter(listItem);
        init();
        initNaviView(view);
        view.findViewById(R.id.btn_close).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onStateChanged(STATE_HIDDEN);
                collapseView();
            }
        });
        view.setOnClickListener(new View.OnClickListener() {@Override public void onClick(View view) {/*NONE*/}});
    }

    private void init() {
        bottomSheetView.setState(BottomSheetBehavior.STATE_HIDDEN);
        bottomSheetView.setHideable(true);
        bottomSheetView.setSkipCollapsed(true);
        bottomSheetView.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(View bottomSheet, int newState) {
                if (newState == STATE_HIDDEN) {
                    context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_main_theme));
                    if(editText.hasFocus()) {
                        //소프트 키보드 내리기
                        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
                    }
                }
                if (newState == STATE_EXPANDED) {
                    context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_dark_dim));
                }
                if (listener != null) {
                    listener.onStateChanged(newState);
                }
                if (newState == STATE_SETTLING && naviView.getVisibility() == View.VISIBLE) {
                    ArrayList<FilterValue> data = new ArrayList<>();
                    data.add(new FilterValue("default", ""));
                    listener.onItemClick("navi", data);
                }
            }

            @Override
            public void onSlide(View bottomSheet, float slideOffset) {
                //onSlide
            }
        });
        this.matchHeightView.setMinimumHeight(context.getWindow().getDecorView().getHeight());
        this.recyclerView.addItemDecoration(new FilterItemAdapterDecoration(recyclerView.getContext()));

        this.editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //NONE
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (TextUtils.isEmpty(charSequence)) {
                    adapter.setFilters(originalData);
                } else {
                    ArrayList<FilterValue> filter = new ArrayList<>();
                    for (FilterValue data : originalData) {
                        if(data.getName().contains(charSequence.toString())) {
                            filter.add(data);
                        }
                    }
                    adapter.setFilters(filter);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //NONE
            }
        });

        adapter.setOnItemClickListener(new FilterItemAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(String category, ArrayList<FilterValue> data) {
                listener.onItemClick(category, data);
                if(type != TYPE.SEARCH) {
                    listener.onStateChanged(STATE_HIDDEN);
                    collapseView();
                }
            }
        });
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onStateChanged(STATE_HIDDEN);
                collapseView();
            }
        });
    }

    public void setType(TYPE type, MapFilterResponse data) {
        this.type = type;

        titleSearch.setVisibility(View.GONE);
        matchHeightView.setVisibility(View.GONE);
        btnConfirm.setVisibility(View.GONE);
        recyclerView.setVisibility(View.VISIBLE);
        recyclerView.setPadding(0,0,0, 0);
        naviView.setVisibility(View.GONE);
        if (type == TYPE.NAVI) {
            recyclerView.setVisibility(View.GONE);
            naviView.setVisibility(View.VISIBLE);
            matchHeightView.setVisibility(View.VISIBLE);
        } else if (type == TYPE.SEARCH) {
            titleSearch.setVisibility(View.VISIBLE);
            matchHeightView.setVisibility(View.VISIBLE);
            btnConfirm.setVisibility(View.VISIBLE);
            recyclerView.setPadding(0,0,0,
                    DaquvUtil.convertDPtoPX(context , 80));
        }
        originalData = data.getValue();
        adapter.setFilters(data.getValue());
        adapter.setSelected(data.getSelected());
        adapter.setCategory(data.getCategory());
        adapter.setType(data.getType().equals("multi") ? 1 : 0);
        this.recyclerView.setAdapter(adapter);
    }


    LinearLayoutCompat tamp;
    ImageView tampCheck;
    LinearLayoutCompat kakao;
    ImageView kakaoCheck;
    LinearLayoutCompat naver;
    ImageView naverCheck;

    LinearLayoutCompat multiTamp;
    ImageView multiTampCheck;
    LinearLayoutCompat multiNaver;
    ImageView multiNavderCheck;

    BasicButtonView btnNaviConfirm;

    public void initNaviView(ViewGroup view) {
        tamp = view.findViewById(R.id.navi_tmap);
        tampCheck = view.findViewById(R.id.navi_tmap_check);
        kakao = view.findViewById(R.id.navi_kakao);
        kakaoCheck = view.findViewById(R.id.navi_kakao_check);
        naver = view.findViewById(R.id.navi_naver);
        naverCheck = view.findViewById(R.id.navi_naver_check);

        multiTamp = view.findViewById(R.id.multi_navi_tmap);
        multiTampCheck = view.findViewById(R.id.multi_navi_tmap_check);
        multiNaver = view.findViewById(R.id.multi_navi_naver);
        multiNavderCheck = view.findViewById(R.id.multi_navi_naver_check);

        btnNaviConfirm = view.findViewById(R.id.btn_navi_confirm);

        checkInit();

        tamp.setOnClickListener(view1 -> {
            tampCheck.setVisibility(View.VISIBLE);
            kakaoCheck.setVisibility(View.INVISIBLE);
            naverCheck.setVisibility(View.INVISIBLE);
        });
        kakao.setOnClickListener(view1 -> {
            tampCheck.setVisibility(View.INVISIBLE);
            kakaoCheck.setVisibility(View.VISIBLE);
            naverCheck.setVisibility(View.INVISIBLE);
        });
        naver.setOnClickListener(view1 -> {
            tampCheck.setVisibility(View.INVISIBLE);
            kakaoCheck.setVisibility(View.INVISIBLE);
            naverCheck.setVisibility(View.VISIBLE);
        });
        multiTamp.setOnClickListener(view1 -> {
            multiTampCheck.setVisibility(View.VISIBLE);
            multiNavderCheck.setVisibility(View.INVISIBLE);
        });
        multiNaver.setOnClickListener(view1 -> {
            multiTampCheck.setVisibility(View.INVISIBLE);
            multiNavderCheck.setVisibility(View.VISIBLE);
        });

        btnNaviConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (tampCheck.getVisibility() == View.VISIBLE) {
                    SharedPref.getInstance().put(DaquvConfig.Preference.KEY_NAVI, context.getString(R.string.map_tmap));
                }
                if (kakaoCheck.getVisibility() == View.VISIBLE) {
                    SharedPref.getInstance().put(DaquvConfig.Preference.KEY_NAVI, context.getString(R.string.map_kakao));
                }
                if (naverCheck.getVisibility() == View.VISIBLE) {
                    SharedPref.getInstance().put(DaquvConfig.Preference.KEY_NAVI, context.getString(R.string.map_naver));
                }
                if (multiTampCheck.getVisibility() == View.VISIBLE) {
                    SharedPref.getInstance().put(DaquvConfig.Preference.KEY_MULTI_NAVI, context.getString(R.string.map_tmap));
                }
                if (multiNavderCheck.getVisibility() == View.VISIBLE) {
                    SharedPref.getInstance().put(DaquvConfig.Preference.KEY_MULTI_NAVI, context.getString(R.string.map_naver));
                }
                collapseView();
            }
        });
    }

    private void checkInit() {
        tampCheck.setVisibility(View.INVISIBLE);
        kakaoCheck.setVisibility(View.INVISIBLE);
        naverCheck.setVisibility(View.INVISIBLE);
        multiTampCheck.setVisibility(View.INVISIBLE);
        multiNavderCheck.setVisibility(View.INVISIBLE);

        if (SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(context.getString(R.string.map_tmap))) {
            tampCheck.setVisibility(View.VISIBLE);
        } else if (SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(context.getString(R.string.map_kakao))) {
            kakaoCheck.setVisibility(View.VISIBLE);
        } else if (SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI).equals(context.getString(R.string.map_naver))) {
            naverCheck.setVisibility(View.VISIBLE);
        }
        if (SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(context.getString(R.string.map_tmap))) {
            multiTampCheck.setVisibility(View.VISIBLE);
        } else if (SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI).equals(context.getString(R.string.map_naver))) {
            multiNavderCheck.setVisibility(View.VISIBLE);
        }
    }

    public boolean isStateExpanded() {
        return bottomSheetView.getState() == STATE_EXPANDED ||
                bottomSheetView.getState() == BottomSheetBehavior.STATE_HALF_EXPANDED;
    }

    public void expandView() {
        checkInit();
        editText.setText("");
        bottomSheetView.setState(STATE_EXPANDED);
        context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_dark_dim));
    }

    public void collapseView() {
        bottomSheetView.setState(BottomSheetBehavior.STATE_HIDDEN);
        context.getWindow().setStatusBarColor(ContextCompat.getColor(context, R.color.dqv_main_theme));
    }
}
