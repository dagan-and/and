package com.daquv.sdk.presentation;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.R;
import com.daquv.sdk.ui.AudioLevelView;
import com.daquv.sdk.utils.AudioFileRecorder2;

public class RecorderFragment extends Fragment  {

    private static final long AMPLITUDE_DELAY_MILLIS = 50L;
    private static final long TIMER_DELAY_MILLIS = 100L;

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    AudioFileRecorder2 audioFileRecorder;

    private Handler amplitudeHandler;
    private Runnable amplitudeRunnable;
    private AudioLevelView audioLevelView;
    private Handler timerHandler;
    private Runnable timerRunnable;
    private int totalSeconds = 0;
    private TextView timerView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_recorder , container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        timerHandler = new Handler();
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                totalSeconds++;
                updateTimerDisplay();
                timerHandler.postDelayed(this, TIMER_DELAY_MILLIS);
            }
        };
        amplitudeHandler = new Handler();
        amplitudeRunnable = new Runnable() {
            @Override
            public void run() {
                audioLevelView.addAmplitude(audioFileRecorder.getAmplitude());
                amplitudeHandler.postDelayed(this, AMPLITUDE_DELAY_MILLIS);
            }
        };

        audioFileRecorder = new AudioFileRecorder2(requireContext());

        audioLevelView = view.findViewById(R.id.audio_level);
        timerView = view.findViewById(R.id.timer);
        TextView startStop = view.findViewById(R.id.start_stop_button);
        startStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(audioFileRecorder.isRecording()) {
                    if(audioFileRecorder.isPause()) {
                        timerHandler.postDelayed(timerRunnable, TIMER_DELAY_MILLIS);
                        amplitudeHandler.postDelayed(amplitudeRunnable, AMPLITUDE_DELAY_MILLIS);
                        audioFileRecorder.resumeRecording();
                        startStop.setText("일시정지");
                    } else {
                        timerHandler.removeCallbacks(timerRunnable);
                        amplitudeHandler.removeCallbacks(amplitudeRunnable);
                        audioFileRecorder.pauseRecording();
                        startStop.setText("다시시작");
                    }
                } else {
                    timerHandler.postDelayed(timerRunnable, TIMER_DELAY_MILLIS);
                    amplitudeHandler.postDelayed(amplitudeRunnable, AMPLITUDE_DELAY_MILLIS);
                    audioFileRecorder.startRecording();
                    audioLevelView.startRecording(0);
                    startStop.setText("일시정지");
                }
            }
        });

        TextView endButton = view.findViewById(R.id.end_button);
        endButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timerHandler.removeCallbacks(timerRunnable);
                amplitudeHandler.removeCallbacks(amplitudeRunnable);
                audioFileRecorder.stopRecording();
                audioFileRecorder.uploadFile();
            }
        });
    }


    private void updateTimerDisplay() {
        if(totalSeconds % 10 == 0) {
            int second = totalSeconds / 10;
            int hours = second / 3600;
            int remainingSeconds = second % 3600;
            int minutes = remainingSeconds / 60;
            int seconds = remainingSeconds % 60;

            String formattedTime = String.format("%02d:%02d:%02d", hours, minutes, seconds);
            timerView.setText(formattedTime);
        }
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);
    }

    @Override
    public void onDetach() {
        super.onDetach();

        timerHandler.removeCallbacks(timerRunnable);
        amplitudeHandler.removeCallbacks(amplitudeRunnable);
        audioFileRecorder.stopRecording();

        onBackPressedCallback.remove();
    }
}
