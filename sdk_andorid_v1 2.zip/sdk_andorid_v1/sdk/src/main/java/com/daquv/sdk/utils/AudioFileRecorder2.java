package com.daquv.sdk.utils;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.widget.Toast;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class AudioFileRecorder2 {

    private final Context context;
    private File audioFile;
    private MediaRecorder mRecorder;
    private boolean isRecording = false;
    private boolean isPause = false;

    public AudioFileRecorder2(Context context) {
        this.context = context;
        File audioFile = new File(DaquvConfig.dirPath, "audio.mp4");
        if (audioFile.exists()) {
            audioFile.delete();
        }
    }

    public void startRecording() {
        try {
            mRecorder = new MediaRecorder();
            mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
            audioFile = new File(DaquvConfig.dirPath, "audio.mp4");

            mRecorder.setOutputFile(audioFile.getAbsolutePath());
            mRecorder.prepare();
            mRecorder.start();
            isRecording = true;
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(context, "녹음을 시작할 수 없습니다.",Toast.LENGTH_SHORT).show();
        }
    }

    public void pauseRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            isPause = true;
            mRecorder.pause();
        }
    }

    public void resumeRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            isPause = false;
            mRecorder.resume();
        }
    }

    public void stopRecording() {
        if(mRecorder != null) {
            mRecorder.stop();
            mRecorder.release();
        }
        isRecording = false;
    }

    public void uploadFile() {
        DaquvSDK.getInstance().getAPI().uploadAudioFile(audioFile.getAbsolutePath());
    }

    public boolean isRecording() {
        return isRecording;
    }

    public boolean isPause() {
        return isPause;
    }

    public int getAmplitude() {
        if(mRecorder == null) {
            return 0;
        }
        return mRecorder.getMaxAmplitude();
    }
}
