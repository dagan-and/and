package com.daquv.sdk.presentation;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.airbnb.lottie.LottieAnimationView;
import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.webview.ComWebView;

public class VoiceFragment extends Fragment {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    DaquvEngine.Callback engineCallback;

    private TextView sttText;

    public interface TurnListener{
        void onCount(String count );
    }

    TurnListener turnListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_daquv_voice , container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sttText = view.findViewById(R.id.title);
        listening();

        ImageView closeVIew = view.findViewById(R.id.close_view);
        closeVIew.setOnClickListener(view1 -> onClose());
    }

    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }
    public void setTurnListener(TurnListener listener) {
        this.turnListener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                onClose();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);

        engineCallback = new DaquvEngine.Callback() {
            @Override
            public void onResult(int code, Object result) {
                super.onResult(code, result);

                if(code == DaquvConfig.CODE.API_NLU_FAIL ) {
                    sttText.setText((String) result);
                    sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
                }

                if(code == DaquvConfig.CODE.API_NLU_REASK) {
                    sttText.setText((String) result);
                    sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
                }

                if(code == DaquvConfig.CODE.API_NLU_TURN) {
                    if(turnListener == null) {
                        DaquvSDK.getInstance().getAPI().getFailPage(new NLUResultResponse());
                    } else {
                        String value = (String) result;
                        String count = value.substring(0, value.indexOf("번"));
                        turnListener.onCount(count);
                    }
                }

                if(code == DaquvConfig.CODE.API_ERROR) {
                    if(result instanceof ErrorData) {
                        Toast.makeText(getContext(), ((ErrorData) result).getMsg(), Toast.LENGTH_SHORT).show();
                    }
                }

                if(code == DaquvConfig.CODE.ENGINE_RUNNING_DATA) {
                    sttText.setText((String) result);
                }

                if(code == DaquvConfig.CODE.ENGINE_FINAL_DATA) {
                    sttText.setText((String) result);
                    sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_iris));
                }

                if (code == DaquvConfig.CODE.ENGINE_START_VOICE) {
                    sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
                }

                if(code == DaquvConfig.CODE.ENGINE_ERROR_VOICE) {
                    onClose();
                }

                if(code == DaquvConfig.CODE.ENGINE_FINISH_TTS) {
                    if(result instanceof TTSResponse) {
                        if ((((TTSResponse) result).getCode() == DaquvConfig.CODE.API_NLU_FAIL)) {
                            listening();
                        }
                        if ((((TTSResponse) result).getCode() == DaquvConfig.CODE.API_NLU_REASK)) {
                            listening();
                        }
                    }
                }
            }
        };
        DaquvSDK.getInstance().addCallBack(engineCallback);
    }

    private void listening() {
        sttText.setText(getContext().getString(R.string.stt_listening));
        sttText.setTextColor(ContextCompat.getColor(requireContext() , R.color.dqv_text_base));
        DaquvSDK.getInstance().getEngine().startEngine();
    }

    private void onClose() {
        DaquvSDK.getInstance().getEngine().stopEngine();
        DaquvSDK.getInstance().stopTTS();
        listener.removeVoiceView();
    }

    @Override
    public void onStop() {
        super.onStop();
        onClose();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        onBackPressedCallback.remove();
        DaquvSDK.getInstance().removeCallBack(engineCallback);
    }
}
