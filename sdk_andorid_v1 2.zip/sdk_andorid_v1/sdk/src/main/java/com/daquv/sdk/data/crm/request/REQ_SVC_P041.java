package com.daquv.sdk.data.crm.request;

import android.content.Context;

import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.network.TranJson;


/**
 * 인증번호 요청 통신 데이터
 */
public class REQ_SVC_P041 extends TranJson {

    /** 통신 요청 구분 코드 */
    public static final String TRAN_ID = "APP_SVC_P041";

    /*
        휴대폰번호	C	11	●
        생년월일	C	9	●		9번째 자리(1,3 :남자, 2,4:여자)
        알뜰폰여부	C	1	●		Y: 알뜰폰, N: 일반
        이름	C	30	●
        통신사코드	C	2	●		01: SKT, 02: KT, 03: LG U+
        내외국인구분코드	C	1	●		1: 내국인, 2: 외국인
    */
    public static final String  CLPH_NO             = "CLPH_NO";
    public static final String  BRDT                = "BRDT";
    public static final String  ECNMC_TEL_CMM_YN    = "ECNMC_TEL_CMM_YN";
    public static final String  NAME                = "NAME";
    public static final String  TEL_CMM_CD          = "TEL_CMM_CD";
    public static final String  IN_FRNR_DV_CD       = "IN_FRNR_DV_CD";
    public static final String  APP_ID              = "APP_ID";


    /**
     * 생성자
     */
    public REQ_SVC_P041(String appId, String cellPhoneNo, String birthday, String ecnmc, String name, String cellPhoneVendor, String frnr) {
        super(TRAN_ID);
        put(CLPH_NO, cellPhoneNo);
        put(BRDT, birthday);
        put(ECNMC_TEL_CMM_YN, ecnmc);
        put(NAME, name);
        put(TEL_CMM_CD, cellPhoneVendor);
        put(IN_FRNR_DV_CD, frnr);
        put(APP_ID, appId);
    }
}
