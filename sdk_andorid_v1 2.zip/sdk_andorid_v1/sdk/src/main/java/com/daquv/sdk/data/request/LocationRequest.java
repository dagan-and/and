package com.daquv.sdk.data.request;

import com.daquv.sdk.utils.network.TranJson;

public class LocationRequest extends TranJson {

    public LocationRequest(String latitude, String longitude, String radius) {
        super();
        put("latitude", latitude);
        put("longitude", longitude);
        put("radius", radius);
    }
}