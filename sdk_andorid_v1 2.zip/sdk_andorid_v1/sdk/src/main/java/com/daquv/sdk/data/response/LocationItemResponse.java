package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;

public class LocationItemResponse implements Serializable {

    @SerializedName("cnt")
    private int count;

    @SerializedName("companies")
    private ArrayList<LocationItem> body;

    private double latitude;
    private double longitude;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public ArrayList<LocationItem> getBody() {
        return body;
    }

    public void setBody(ArrayList<LocationItem> body) {
        this.body = body;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
