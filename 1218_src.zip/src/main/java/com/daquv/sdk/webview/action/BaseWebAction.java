package com.daquv.sdk.webview.action;

import com.daquv.sdk.utils.Logger;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Hashtable;

/**
 * Base WebAction Class
 **/
public class BaseWebAction {

    /** WebView Bridge */
    protected WebActionBridge mBridge;

    /** Action Class 에 정의되어 있는 모든 Action Method 저장 Hashtable */
    private Hashtable<String, Method> mActionMethodTable = null;

    /**
     * 생성자
     * @param bridge WebView Bridge
     */
    protected BaseWebAction(WebActionBridge bridge) {
        mBridge = bridge;
        initAction();
    }

    /**
     * Action Class 에 정의되어 있는 Action Method 초기화
     */
    private void initAction () {
        mActionMethodTable = new Hashtable<>();

        // Action 클래스에 정의되어 있는 Method 리스트 가져오기
        for (Method method : getClass().getDeclaredMethods()) {
            Logger.dev("method Name :: " + method.getName());
            if (!method.getName().startsWith("_") || !method.getName().endsWith("_")) {
                continue;
            }

            String strId = method.getName();
            strId = strId.substring(1);
            strId = strId.substring(0, strId.length() - 1);
            // Action Method Hash Table 에 Method 저장
            mActionMethodTable.put(strId, method);
        }
    }

    /**
     * Action Class 에 정의되어 있는 Action (Action Method) 리스트 반환
     * @return Action Class 에 정의되어 있는 Action (Action Method) 리스트
     */
    public ArrayList<String> getActionList () {
        return new ArrayList<String>(mActionMethodTable.keySet());
    }

    /**
     * Action Class 의 Action (Action Method) 호출
     * @param webActionInfo 웹액션 정보
     */
    public void callAction (WebActionInfo webActionInfo)  {
        Method method = mActionMethodTable.get(webActionInfo.getActionCode());
        try {
            Logger.dev("method isNull :: " + (method == null));
            Logger.dev("method.getName() :: " + method.getName());
            method.invoke(this, webActionInfo);
        } catch (NullPointerException | IllegalAccessException | InvocationTargetException
        e) {
            Logger.error(e);
        }
    }
}
