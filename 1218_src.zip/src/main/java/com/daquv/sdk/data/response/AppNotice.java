package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class AppNotice {
    @SerializedName("app_notice_seq")
    public String appNoticeSeq;

    @SerializedName("contents")
    public String contents;

    @SerializedName("use_yn")
    public String useYN;

    @SerializedName("force_yn")
    public String forceYN;

    @SerializedName("app_notice_url")
    public String alertAction;

    @SerializedName("notice_type")
    public String noticeType;

    @SerializedName("btn_nm01")
    public String textConfirm;

    @SerializedName("btn_nm02")
    public String textCancel;

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public String getUseYN() {
        return useYN;
    }

    public void setUseYN(String useYN) {
        this.useYN = useYN;
    }

    public String getForceYN() {
        return forceYN;
    }

    public void setForceYN(String forceYN) {
        this.forceYN = forceYN;
    }

    public String getAlertAction() {
        return alertAction;
    }

    public void setAlertAction(String alertAction) {
        this.alertAction = alertAction;
    }

    public String getNoticeType() {
        return noticeType;
    }

    public void setNoticeType(String noticeType) {
        this.noticeType = noticeType;
    }

    public String getTextConfirm() {
        return textConfirm;
    }

    public void setTextConfirm(String textConfirm) {
        this.textConfirm = textConfirm;
    }

    public String getTextCancel() {
        return textCancel;
    }

    public void setTextCancel(String textCancel) {
        this.textCancel = textCancel;
    }

    public String getAppNoticeSeq() {
        return appNoticeSeq;
    }

    public void setAppNoticeSeq(String appNoticeSeq) {
        this.appNoticeSeq = appNoticeSeq;
    }
}