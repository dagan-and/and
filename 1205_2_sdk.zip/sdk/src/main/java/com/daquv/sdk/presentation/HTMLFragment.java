package com.daquv.sdk.presentation;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.core.DaquvEngine;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.ui.component.BasicButtonView;
import com.daquv.sdk.utils.secure.PreventRecordUtils;
import com.daquv.sdk.webview.ComWebView;

public class HTMLFragment extends Fragment {

    DaquvView.FragmentListener listener;
    OnBackPressedCallback onBackPressedCallback;
    ComWebView webView;
    String title;
    String url;

    public interface Listener{
        void onConfirm();
    }

    Listener htmlListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        PreventRecordUtils.getInstance().setSecureFlag(requireActivity());
        return inflater.inflate(R.layout.fragment_daquv_html , container , false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        webView = view.findViewById(R.id.html_view);
        webView.loadUrl(url);

        TextView titleView = view.findViewById(R.id.title);
        titleView.setText(title);

        ImageView btnPre = view.findViewById(R.id.btn_pre);
        btnPre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onBackPress(HTMLFragment.this);
            }
        });
        BasicButtonView confirm = view.findViewById(R.id.html_confirm);
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(htmlListener != null) {
                    htmlListener.onConfirm();
                }
                listener.onBackPress(HTMLFragment.this);
            }
        });
        if(htmlListener == null) {
            confirm.setText(getString(R.string.dqv_confirm));
        }
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    public void setListener(DaquvView.FragmentListener listener) {
        this.listener = listener;
    }
    public void setHtmlListener(Listener listener) {
        this.htmlListener = listener;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        onBackPressedCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                listener.onBackPress(HTMLFragment.this);
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, onBackPressedCallback);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        onBackPressedCallback.remove();
    }

}
