package com.daquv.sdk;

import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.data.response.STTReplaceResponse;

import java.security.PublicKey;
import java.util.ArrayList;

public class DaquvConfig {

    public static AppConfig appConfig;
    public static Boolean isDebug = true;

    public static final int RESOURCE_MAX_CACHE_SIZE = 5 * 1024 * 1024; // 5MB
    public static final int ETAG_MAX_CACHE_SIZE = 3 * 1024 * 1024; // 3MB

    public static ENGINE     engine = ENGINE.ITL;
    public static SERVICE    service = SERVICE.IBKCRM;

    public static String jwtToken = "";
    public static String ibkToken = "";
    public static String appCode = "";

    public static String hubUrl = "http://13.125.176.152:8081";  //Hub 개발 서버
    public static String crmUrl = "http://203.235.68.65:5102/ava"; //IBK CRM 내부망 서버
    public static String crmWASUrl = "http://13.125.176.152:8200"; //IBK CRM WAS 서버
    public static String sttUrl = "http://211.57.84.235"; //"nlu-00.intelloia.com"; //STT 서버
    public static int sttPort = 11601;

    public static Boolean useWebMemoryCache = true;
    public static Boolean useNLUFailCount = false;

    //Inside Key
    public static INSIDE insideKey = null;

    //지도기능
    public static int maxZoom = 16;
    public static int minZoom = 10;
    public static int defaultZoom = 14;

    //파일관리
    public static String dirPath = "";

    //문구 치환 데이터
    public static ArrayList<STTReplaceResponse.STTReplace> replaces = new ArrayList<>();

    //Audio Session
    public static int audioSession;

    //TTS Session
    public static int ttsSession;


    public enum SERVICE {
        HUB,
        IBKCRM,
        POSCO
    }

    public enum ENGINE {
        ITL,
        INSIDE
    }

    public enum INSIDE {
        HUB,
        POSCO,
        SALESFORCE
    }

    public static class CODE{
        public static final int API_LOGIN =             100;
        public static final int API_TTS =               101;
        public static final int API_REQUEST_CODE =      102;
        public static final int API_VERIFY_CODE =       103;
        public static final int API_MAIN_DATA =         104;
        public static final int API_NLU =               201;
        public static final int API_NLU_SUCCESS =       202;
        public static final int API_NLU_REASK =         203;
        public static final int API_NLU_FAIL =          204;
        public static final int API_NLU_FAIL_MAX =      205;
        public static final int API_NLU_TURN =          206;
        public static final int API_NLU_MAP =           207;
        public static final int API_NLU_CONSULT =       208;
        public static final int API_CONSULT_UPLOAD =    209;
        public static final int API_SEARCH_COPLIST =    210;
        public static final int API_ERROR =             999;

        public static final int ENGINE_INIT =           10000;
        public static final int ENGINE_START_VOICE =    10001;
        public static final int ENGINE_STOP_VOICE =     10002;
        public static final int ENGINE_ERROR_VOICE =    10003;
        public static final int ENGINE_NONE_DATA =      10004;
        public static final int ENGINE_RUNNING_DATA =   10005;
        public static final int ENGINE_FINAL_DATA =     10006;
        public static final int ENGINE_START_TTS =      10007;
        public static final int ENGINE_FINISH_TTS =     10009;
        public static final int ENGINE_CONTINUE_DATA =  10010;

        public static final int DIRECT_MOVE =           20001;
    }

    public static class API{
        public static final String AUTH_KEY_URL =       hubUrl + "/auth/issue";
        public static final String LOGIN_URL =          hubUrl + "/auth/istn/signin";
        public static final String NLU_URL =            hubUrl + "/api/nlu/utterance";
        public static final String TTS_URL =            hubUrl + "/exapi/clova/callTtsBinaryString";
        public static final String AUDIO_UPLOAD_URL =   hubUrl + "/api/stt/sel";
        public static final String STT_REPLACE_URL =    hubUrl + "/istn/jsonDownload/hint";

        public static final String CRM_BASE_URL =           crmUrl + "/GateWay";
        public static final String CRM_AUTH_KEY_URL =       crmUrl + "/exapi/ibkCrm/v1/auth/issue";
        public static final String CRM_LOGIN_URL =          crmUrl + "/exapi/ibkCrm/v1/auth/signinEnc";
        public static final String CRM_WAS_AUTH_KEY_URL =   crmWASUrl + "/exapi/ibkCrm/v1/auth/issue";
        public static final String CRM_WAS_LOGIN_URL =      crmWASUrl + "/exapi/ibkCrm/v1/auth/signinEnc";
        public static final String CRM_NLU_URL =            crmWASUrl + "/api/nlu/utterance";
        public static final String CRM_TTS_URL =            crmUrl + "/exapi/clova/callTtsBinaryStringToken";
        public static final String CRM_MAP_URL =            crmUrl + "/exapi/ibkCrm/v1/auth/distanceList";
        public static final String CRM_CONSULT_URL =        crmUrl + "/webview/ibkCrm/v1/rec/regRec";
        public static final String CRM_SEARCH_COP_LIST =    crmUrl + "/exapi/ibkCrm/v1/auth/searchCopList";
        public static final String CRM_STT_REPLACE_URL =    crmUrl + "/assets/hubNew/json/stt_replace.json";

    }

    public static class Preference{
        /** 이용약관, 개인정보 처리 동의 여부 */
        public static final String KEY_ARGUMENT_POLICY_AGREE = "KEY_ARGUMENT_POLICY_AGREE_V1";
        /** 로컬캐시 리소스 버전 정보  */
        public static final String WEB_RESOURCE_VERSION = "WEB_RESOURCE_VERSION";
        /** 음성 답변 외부 스피커/통화 스피커 여부  */
        public static final String KEY_PREF_VOICE_SPEAKER = "KEY_PREF_VOICE_SPEAKER";
        /** 음성 받기 on/off 여부  */
        public static final String KEY_PREF_USE_TTS = "KEY_PREF_USE_TTS";
        /** 길찾기  */
        public static final String KEY_NAVI = "KEY_NAVI";
        /** 경로 설정 길찾기  */
        public static final String KEY_MULTI_NAVI = "KEY_MULTI_NAVI";

    }

    public static class ERROR {
        public static final int NO_SPEAK_TIMEOUT =   10001;
    }
}
