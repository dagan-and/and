package com.daquv.sdk.core;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.R;
import com.daquv.sdk.data.crm.request.REQ_SVC_C028;
import com.daquv.sdk.data.crm.request.REQ_SVC_P041;
import com.daquv.sdk.data.crm.response.RES_SVC_C028;
import com.daquv.sdk.data.crm.response.RES_SVC_P041;
import com.daquv.sdk.data.request.ConsultRequest;
import com.daquv.sdk.data.request.LoginRequest;
import com.daquv.sdk.data.request.NLURequest;
import com.daquv.sdk.data.request.UttHistoryRequest;
import com.daquv.sdk.data.response.AppConfig;
import com.daquv.sdk.data.response.AppNoticeModel;
import com.daquv.sdk.data.response.BaseModel;
import com.daquv.sdk.data.response.BaseResponse;
import com.daquv.sdk.data.response.CommCodeModel;
import com.daquv.sdk.data.response.ConsultResponse;
import com.daquv.sdk.data.response.CusInfoModel;
import com.daquv.sdk.data.response.Entities;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.LocationItemModel;
import com.daquv.sdk.data.response.LocationItemResponse;
import com.daquv.sdk.data.response.LoginTokenModel;
import com.daquv.sdk.data.response.MapFilterModel;
import com.daquv.sdk.data.response.MapFilterResponse;
import com.daquv.sdk.data.response.FilterValue;
import com.daquv.sdk.data.response.NLUResultModel;
import com.daquv.sdk.data.response.RsaKeyModel;
import com.daquv.sdk.data.response.NLUResultResponse;
import com.daquv.sdk.data.response.STTReplaceResponse;
import com.daquv.sdk.data.response.TTSModel;
import com.daquv.sdk.data.response.TTSResponse;
import com.daquv.sdk.network.HttpClient;
import com.daquv.sdk.network.ETagCache;
import com.daquv.sdk.utils.DaquvUtil;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.utils.SharedPref;
import com.daquv.sdk.utils.network.TranJson;
import com.daquv.sdk.utils.secure.RSAUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonSyntaxException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.net.CookieHandler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.Callable;

import io.reactivex.Observable;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;
import io.reactivex.schedulers.Schedulers;
import okhttp3.CookieJar;
import okhttp3.FormBody;
import okhttp3.JavaNetCookieJar;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.Response;

public class DaquvAPI {
    //right click -> folding -> Collapse all

    private final Context mContext;
    private final CompositeDisposable commonDisposable;
    private final APICallback mAPICallBack;
    private final CookieHandler cookieHandler;
    private final ETagCache responseCache = new ETagCache();
    private String mainUrl;
    private String mainData;
    private String resultUrl;
    private String resultData;
    private NLUResultResponse resultResponse;

    private CookieJar getCookieJar() {
        return new JavaNetCookieJar(cookieHandler);
    }

    public DaquvAPI(Context context, APICallback callback) {
        mContext = context;
        mAPICallBack = callback;
        commonDisposable = new CompositeDisposable();
        cookieHandler = new java.net.CookieManager();
    }

    public static class APICallback {
        public void onAPIResult(int code, Object result) {
            /**
             * API 응답 CallBack
             */
        }
    }

    /**
     * 결과 페이지 데이터
     *
     * @return HTML
     */
    public String getResultData() {
        return resultData;
    }

    /**
     * 결과 페이지 URL
     *
     * @return URL
     */
    public String getResultUrl() {
        return resultUrl;
    }

    /**
     * 메인 페이지 데이터
     *
     * @return HTML
     */
    public String getMainData() {
        return mainData;
    }

    /**
     * 메인 페이지 URL
     *
     * @return URL
     */
    public String getMainUrl() {
        return mainUrl;
    }


    public void sendError(Exception e) {
        Logger.error(e);
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, DaquvUtil.getExceptionLog(e));
    }

    public void sendError(Throwable e) {
        Logger.error(e);
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, DaquvUtil.getExceptionLog(e));
    }


    private String[] encryptLoinRequest(String json, String... info) {
        RsaKeyModel bodyResponse = new Gson().fromJson(json, RsaKeyModel.class);
        if (bodyResponse.getBody() == null) {
            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                    new ErrorData(DaquvConfig.CODE.API_LOGIN, mContext.getString(R.string.err_msg_daquv_2)));
            return null;
        }

        String rsaExponent = bodyResponse.getBody().getRsaExponent();
        String rsaModulus = bodyResponse.getBody().getRsaModulus();

        String[] encData = new String[info.length];
        for (int i = 0; i < info.length; i++) {
            encData[i] = RSAUtils.getEncryptRSA(rsaModulus, rsaExponent, info[i]);
        }
        return encData;
    }

    /**
     * 로그인
     */
    public void login(String... info) {
        Callable<Response> callable = () -> {

            String url = "";
            switch (DaquvConfig.service) {
                case HUB:
                case POSCO:
                    url = DaquvConfig.API.AUTH_KEY_URL;
                    break;
                case IBKCRM:
                    url = DaquvConfig.API.CRM_AUTH_KEY_URL;
                    break;
                default:
                    url = DaquvConfig.API.AUTH_KEY_URL;
                    break;
            }

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addJWTToken(false)
                    .isPost(false)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        try {
                            if (response.isSuccessful() && response.body() != null) {

                                LoginRequest reqSvcLogin = new LoginRequest(DaquvConfig.service ,encryptLoinRequest(response.body().string() , info));

                                Callable<Response> callable = () -> {
                                    HttpClient client = new HttpClient.Builder()
                                            .setUrl(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service ?
                                                    DaquvConfig.API.CRM_LOGIN_URL : DaquvConfig.API.LOGIN_URL)
                                            .setCookie(getCookieJar())
                                            .setCache(responseCache)
                                            .setJsonData(reqSvcLogin.getJSON())
                                            .addJWTToken(false)
                                            .builder();
                                    return client.getCall().execute();
                                };

                                commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                                        .observeOn(Schedulers.io())
                                        .subscribe(new Consumer<Response>() {
                                            @Override
                                            public void accept(Response response) throws Exception {
                                                BaseResponse baseResponse = new BaseResponse(response, responseCache);
                                                if (baseResponse.isSuccess()) {
                                                    LoginTokenModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), LoginTokenModel.class);

                                                    if (bodyResponse.getBody() == null) {
                                                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                new ErrorData(DaquvConfig.CODE.API_LOGIN, "ERROR CODE:" + response.code()));
                                                        return;
                                                    }

                                                    DaquvConfig.jwtToken = bodyResponse.getBody().getToken();
                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_LOGIN, bodyResponse.getBody());
                                                } else {
                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                            new ErrorData(DaquvConfig.CODE.API_LOGIN, "ERROR CODE:" + response.code()));
                                                }
                                            }
                                        }, new Consumer<Throwable>() {
                                            @Override
                                            public void accept(Throwable throwable) throws Exception {
                                                sendError(throwable);
                                            }
                                        }));


                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_LOGIN, "REQ URL:\n" + response.request().url() + "\n\n"
                                        + "RES CODE:: " + response.code() +
                                                "\nRES MSG:: " + response.message()));
                            }
                        } catch (JsonSyntaxException e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    public void loginMultiple(Boolean agreeArgument , String... info) {
        try {
            Callable<Response> callable = () -> {

                HttpClient client = new HttpClient.Builder()
                        .setUrl(DaquvConfig.API.CRM_AUTH_KEY_URL)
                        .setCookie(getCookieJar())
                        .setCache(responseCache)
                        .addJWTToken(false)
                        .isPost(false)
                        .builder();
                return client.getCall().execute();
            };

            commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(new Consumer<Response>() {
                        @Override
                        public void accept(Response response) throws Exception {
                            try {
                                if (response.isSuccessful() && response.body() != null) {

                                    String agree = "";
                                    if(agreeArgument != null && agreeArgument) {
                                        agree = "Y";
                                    }
                                    String[] encryptLoinRequest = encryptLoinRequest(response.body().string() ,info[0],info[1],info[2]);
                                    LoginRequest reqSvcLogin = new LoginRequest(DaquvConfig.SERVICE.IBKCRM ,
                                            encryptLoinRequest[0],
                                            encryptLoinRequest[1],
                                            encryptLoinRequest[2],
                                            agree,
                                            DaquvConfig.authToken);

                                    Callable<Response> callable = () -> {
                                        HttpClient client = new HttpClient.Builder()
                                                .setUrl(DaquvConfig.API.CRM_LOGIN_URL)
                                                .setCookie(getCookieJar())
                                                .setCache(responseCache)
                                                .setJsonData(reqSvcLogin.getJSON())
                                                .addJWTToken(false)
                                                .isLogging(true)
                                                .builder();
                                        return client.getCall().execute();
                                    };

                                    commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                                            .observeOn(Schedulers.io())
                                            .subscribe(new Consumer<Response>() {
                                                @Override
                                                public void accept(Response response) throws Exception {
                                                    BaseResponse baseResponse = new BaseResponse(response, responseCache);
                                                    if (baseResponse.isSuccess()) {
                                                        LoginTokenModel crmResponse = new Gson().fromJson(baseResponse.getBody(), LoginTokenModel.class);

                                                        if (crmResponse.getBody() == null) {
                                                            if(!TextUtils.isEmpty(crmResponse.getMessage()) &&
                                                                    (crmResponse.getMessage().contains("ERROR001") || crmResponse.getMessage().contains("ERROR002"))) {
                                                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                        new ErrorData(DaquvConfig.CODE.API_LOGIN, "TOKEN"));
                                                            } else {
                                                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                        new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRM"));
                                                            }
                                                            return;
                                                        }

                                                        DaquvConfig.ibkToken = crmResponse.getBody().getToken();
                                                        //약관동의 여부 체크
                                                        if(!TextUtils.isEmpty(crmResponse.getBody().getAggrYn()) &&
                                                                crmResponse.getBody().getAggrYn().equalsIgnoreCase("Y")) {
                                                            SharedPref.getInstance().put(DaquvConfig.Preference.KEY_ARGUMENT_POLICY_AGREE, true);
                                                        } else if(!TextUtils.isEmpty(crmResponse.getBody().getAggrYn()) &&
                                                                crmResponse.getBody().getAggrYn().equalsIgnoreCase("N")) {
                                                            SharedPref.getInstance().put(DaquvConfig.Preference.KEY_ARGUMENT_POLICY_AGREE, false);
                                                        }

                                                        Callable<Response> callable = () -> {

                                                            HttpClient client = new HttpClient.Builder()
                                                                    .setUrl(DaquvConfig.API.CRM_WAS_AUTH_KEY_URL)
                                                                    .setCookie(getCookieJar())
                                                                    .setCache(responseCache)
                                                                    .addJWTToken(false)
                                                                    .isPost(false)
                                                                    .builder();
                                                            return client.getCall().execute();
                                                        };

                                                        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                                                                .observeOn(Schedulers.io())
                                                                .subscribe(new Consumer<Response>() {
                                                                    @Override
                                                                    public void accept(Response response) throws Exception {
                                                                        try {
                                                                            if (response.isSuccessful() && response.body() != null) {

                                                                                String[] encryptLoinRequest = encryptLoinRequest(response.body().string(), info[0], info[1], info[2]);
                                                                                LoginRequest reqSvcLogin = new LoginRequest(DaquvConfig.SERVICE.IBKCRM, encryptLoinRequest);


                                                                                Callable<Response> callable = () -> {
                                                                                    HttpClient client = new HttpClient.Builder()
                                                                                            .setUrl(DaquvConfig.API.CRM_WAS_LOGIN_URL)
                                                                                            .setCookie(getCookieJar())
                                                                                            .setCache(responseCache)
                                                                                            .setJsonData(reqSvcLogin.getJSON())
                                                                                            .addJWTToken(false)

                                                                                            .builder();
                                                                                    return client.getCall().execute();
                                                                                };

                                                                                commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                                                                                        .observeOn(Schedulers.io())
                                                                                        .subscribe(new Consumer<Response>() {
                                                                                            @Override
                                                                                            public void accept(Response response) throws Exception {
                                                                                                BaseResponse baseResponse = new BaseResponse(response, responseCache);
                                                                                                if (baseResponse.isSuccess()) {
                                                                                                    LoginTokenModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), LoginTokenModel.class);

                                                                                                    if (bodyResponse.getBody() == null) {
                                                                                                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                                                new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRMWAS"));
                                                                                                        return;
                                                                                                    }

                                                                                                    DaquvConfig.jwtToken = bodyResponse.getBody().getToken();

                                                                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_LOGIN, crmResponse.getBody());
                                                                                                } else {
                                                                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                                            new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRMWAS"));
                                                                                                }
                                                                                            }
                                                                                        }, new Consumer<Throwable>() {
                                                                                            @Override
                                                                                            public void accept(Throwable throwable) throws Exception {
                                                                                                sendError(throwable);
                                                                                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                                        new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRMWAS"));
                                                                                            }
                                                                                        }));
                                                                            } else {
                                                                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                        new ErrorData(DaquvConfig.CODE.API_LOGIN, "WASFAIL"));
                                                                            }
                                                                        } catch (JsonSyntaxException e) {
                                                                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                    new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRMWAS"));
                                                                        }
                                                                    }
                                                                }, new Consumer<Throwable>() {
                                                                    @Override
                                                                    public void accept(Throwable throwable) throws Exception {
                                                                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                                new ErrorData(DaquvConfig.CODE.API_LOGIN, "WASFAIL"));
                                                                    }
                                                                }));


                                                    } else {
                                                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                                new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRM"));
                                                    }
                                                }
                                            }, new Consumer<Throwable>() {
                                                @Override
                                                public void accept(Throwable throwable) throws Exception {
                                                    sendError(throwable);
                                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                            new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRM"));
                                                }
                                            }));


                                } else {
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                            new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRM"));
                                }
                            } catch (JsonSyntaxException e) {
                                sendError(e);
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRM"));
                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {
                            sendError(throwable);
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_LOGIN, "CRM"));
                        }
                    }));
        } catch (JsonSyntaxException e) {
            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                    new ErrorData(DaquvConfig.CODE.API_LOGIN, e.getMessage()));
        }
    }


    /**
     * NLU 데이터 요청
     *
     * @param utterance 발화문구
     */
    public void getNLUData(String utterance) {
        NLURequest reqSvcLogin = new NLURequest(utterance);

        Callable<Response> callable = () -> {

            String url = "";
            switch (DaquvConfig.service) {
                case HUB:
                case POSCO:
                    url = DaquvConfig.API.NLU_URL;
                    break;
                case IBKCRM:
                    url = DaquvConfig.API.CRM_NLU_URL;
                    break;
                default:
                    url = DaquvConfig.API.NLU_URL;
                    break;
            }

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(reqSvcLogin.getJSON())
                    .isLogging(true)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        String json = baseResponse.getBody();

                        if (baseResponse.isSuccess()) {
                            NLUResultModel bodyResponse = new Gson().fromJson(json, NLUResultModel.class);
                            if(bodyResponse.getBody() != null) {
                                bodyResponse.getBody().setUtterance(utterance);
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU, bodyResponse.getBody());

                                String inputType = "VCE";
                                if(DaquvConfig.inputType == DaquvConfig.INPUT_TYPE.KEYBOARD) {
                                    inputType = "TXT";
                                } else if(DaquvConfig.inputType == DaquvConfig.INPUT_TYPE.TOUCH) {
                                    inputType = "TCH";
                                }

                                //로그 쌓기
                                setUttHistory(utterance ,
                                        bodyResponse.getBody().getIntent() ,
                                        bodyResponse.getBody().getEntities(),
                                        DaquvConfig.emn ,
                                        inputType);

                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_NLU, json));
                                getFailPage(new NLUResultResponse());
                            }
                        } else {
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_NLU, json));
                            getFailPage(new NLUResultResponse());
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                new ErrorData(DaquvConfig.CODE.API_NLU, throwable.toString()));
                        getFailPage(new NLUResultResponse());
                    }
                }));

    }


    /**
     * 지도 데이터 요청
     *
     * @param latitude  위도 좌표
     * @param longitude 경도 좌표
     * @param radius    검색 반경
     */
    public void getMapData(String name , String latitude, String longitude, String radius , ArrayList<MapFilterResponse> filterData) {
        mAPICallBack.onAPIResult(DaquvConfig.CODE.LOAD_MAP, new LocationItemResponse(latitude, longitude));

        String mRadius = radius.replaceAll("M", "");
        if (radius.toUpperCase().contains("K")) {
            String value = radius.split("K")[0];
            int fValue = (int) (Float.parseFloat(value) * 1000);
            mRadius = String.valueOf(fValue);
        }
        JSONObject jsonObject = new JSONObject();

        try {
            jsonObject.put("latitude", latitude);
            jsonObject.put("longitude", longitude);
            if(filterData != null && filterData.size() > 0) {
                for (MapFilterResponse data : filterData) {
                    if(data.getSelected() != null && data.getSelected().size() > 0) {
                        if(data.getType().equalsIgnoreCase("multi")) {
                            JSONArray jsonArray = new JSONArray();
                            for(FilterValue value : data.getSelected()) {
                                jsonArray.put(value.getKey());
                            }
                            jsonObject.put(data.getCategory(), jsonArray);
                        } else {
                            jsonObject.put(data.getCategory(), data.getSelected().get(0).getKey());
                        }
                    }
                }
                jsonObject.remove("navi");
            } else {
                jsonObject.put("radius", mRadius);
            }
        } catch (JSONException e) {
            Logger.error(e);
        }

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_MAP_URL)
                    .setCookie(getCookieJar())
                    .setTimeout(60)
                    .setCache(responseCache)
                    .setJsonData(jsonObject.toString())
                    .addIBKToken(true)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        if (baseResponse.isSuccess()) {
                            LocationItemModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), LocationItemModel.class);
                            bodyResponse.getBody().setLatitude(Double.parseDouble(latitude));
                            bodyResponse.getBody().setLongitude(Double.parseDouble(longitude));
                            bodyResponse.getBody().setCompanyName(name);

                            if(bodyResponse.getBody().getBody() != null && !bodyResponse.getBody().getBody().isEmpty()) {
                                for (int i = 0; i < bodyResponse.getBody().getBody().size(); i++) {
                                    bodyResponse.getBody().getBody().get(i).setOriginPosition(i);
                                }
                            }
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_MAP, bodyResponse.getBody());
                        } else {
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_NLU_MAP, mContext.getString(R.string.err_msg_daquv_9)));
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));

    }

    /**
     * 결과 페이지 요청
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getResultPage(NLUResultResponse nluResultResponse) {
        Callable<Response> callable = () -> {

            //BODY
            FormBody.Builder formBody = new FormBody.Builder();
            formBody.add("intent_code", TextUtils.isEmpty(nluResultResponse.getIntent()) ? "null" : nluResultResponse.getIntent());
            formBody.add("utterance", TextUtils.isEmpty(nluResultResponse.getUtterance()) ? "null" : nluResultResponse.getUtterance());

            if(DaquvConfig.service == DaquvConfig.SERVICE.IBKCRM) {
                String inputType = "VCE";
                if(DaquvConfig.inputType == DaquvConfig.INPUT_TYPE.KEYBOARD) {
                    inputType = "TXT";
                } else if(DaquvConfig.inputType == DaquvConfig.INPUT_TYPE.TOUCH) {
                    inputType = "TCH";
                }
                formBody.add("ldinSe", inputType);
            }


            if (nluResultResponse.getEntities() != null && !nluResultResponse.getEntities().isEmpty()) {
                ArrayList<Entities> entities = nluResultResponse.getEntities();
                for (int i = 0; i < entities.size(); i++) {
                    Entities entity = entities.get(i);
                    formBody.add("entities[" + i + "].entity", TextUtils.isEmpty(entity.getEntity()) ? "null" : entity.getEntity());
                    formBody.add("entities[" + i + "].value", TextUtils.isEmpty(entity.getValue()) ? "null" : entity.getValue());
                }
            }

            if(nluResultResponse.getFormBuilder() != null) {
                formBody = nluResultResponse.getFormBuilder();
            }

            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvUtil.getUrl(nluResultResponse.getUrl()))
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setBody(formBody.build())
                    .addIBKToken(DaquvConfig.service == DaquvConfig.SERVICE.IBKCRM)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        if (baseResponse.isSuccess()) {
                            resultResponse = nluResultResponse;
                            resultUrl = DaquvUtil.getUrl(nluResultResponse.getUrl());
                            resultData = baseResponse.getBody();

                            if(nluResultResponse.isDepth()) {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_SUCCESS_DEPTH, DaquvUtil.getUrl(nluResultResponse.getUrl()));
                            } else if(nluResultResponse.isMapDepth()){
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_SUCCESS_MAP_DEPTH, DaquvUtil.getUrl(nluResultResponse.getUrl()));
                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_SUCCESS, DaquvUtil.getUrl(nluResultResponse.getUrl()));
                            }
                        } else {
                            getFailPage(nluResultResponse);
                            Logger.error(baseResponse.getBody());
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable e) throws Exception {
                        sendError(e);
                        getFailPage(nluResultResponse);
                    }
                }));

    }

    public void resultPageReload() {
        getResultPage(resultResponse);
    }


    /**
     * 특정 좌표 주변기업 리스트 요청
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getSearchCopList(NLUResultResponse nluResultResponse) {
        //BODY
        try {
            JSONObject jsonObject = new JSONObject();
            if(!TextUtils.isEmpty(nluResultResponse.getIntent())) {
                jsonObject.put("intent_code", nluResultResponse.getIntent());
            }

            if (nluResultResponse.getEntities() != null && !nluResultResponse.getEntities().isEmpty()) {
                ArrayList<Entities> entities = nluResultResponse.getEntities();
                for (int i = 0; i < entities.size(); i++) {
                    Entities entity = entities.get(i);
                    if(!TextUtils.isEmpty(entity.getEntity()) && !TextUtils.isEmpty(entity.getValue())) {
                        jsonObject.put(entity.getEntity(), entity.getValue());
                    }
                }
            }

            Callable<Response> callable = () -> {
                HttpClient client = new HttpClient.Builder()
                        .setUrl(DaquvConfig.API.CRM_SEARCH_COP_LIST)
                        .setCookie(getCookieJar())
                        .setCache(responseCache)
                        .setJsonData(jsonObject.toString())
                        .addIBKToken(true)

                        .builder();
                return client.getCall().execute();
            };

            commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(new Consumer<Response>() {
                        @Override
                        public void accept(Response response) throws Exception {
                            BaseResponse baseResponse = new BaseResponse(response, responseCache);
                            if (baseResponse.isSuccess()) {
                                LocationItemModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), LocationItemModel.class);
                                if(bodyResponse.isSuccess()) {

                                    String gubun = "0";
                                    if (nluResultResponse.getEntities() != null && !nluResultResponse.getEntities().isEmpty()) {
                                        ArrayList<Entities> entities = nluResultResponse.getEntities();
                                        for (int i = 0; i < entities.size(); i++) {
                                            Entities entity = entities.get(i);
                                            if(!TextUtils.isEmpty(entity.getEntity()) && !TextUtils.isEmpty(entity.getValue()) &&
                                                    entity.getEntity().equalsIgnoreCase("gubun")) {
                                                gubun = entity.getValue();
                                            }
                                        }
                                    }


                                    if(!TextUtils.isEmpty(bodyResponse.getBody().getUrl())) {
                                        NLUResultResponse listItemResponse = new NLUResultResponse();
                                        listItemResponse.setUrl(bodyResponse.getBody().getUrl());

                                        if(!TextUtils.isEmpty(bodyResponse.getBody().getBzn())) {
                                            ArrayList<Entities> entities = new ArrayList<>();
                                            entities.add(new Entities("gubun", bodyResponse.getBody().getGubun(),null,null));
                                            entities.add(new Entities("bzn", bodyResponse.getBody().getBzn(),null,null));
                                            entities.add(new Entities("krncsm", bodyResponse.getBody().getKrncsm(),null,null));
                                            listItemResponse.setEntities(entities);
                                            listItemResponse.setDepth(true);
                                        } else  {
                                            listItemResponse.setIntent("IB018");
                                            ArrayList<Entities> entities = new ArrayList<>();
                                            entities.add(new Entities("COUNTERPARTNAME", nluResultResponse.getEntities().get(0).getValue(),null,null));
                                            listItemResponse.setEntities(entities);
                                            listItemResponse.setDepth(true);
                                        }


                                        getResultPage(listItemResponse);
                                    } else if(bodyResponse.getBody().getLatitude() > 0L && bodyResponse.getBody().getLongitude() > 0L){
                                        String name = "기업명";
                                        if(gubun.equalsIgnoreCase("3")) {
                                            name = "주소";
                                        }
                                        getMapData(name , String.valueOf(bodyResponse.getBody().getLatitude()),
                                                String.valueOf(bodyResponse.getBody().getLongitude()),
                                                DaquvConfig.defaultRadius,
                                                DaquvConfig.mapFilterList.getFilter());
                                    } else {
                                        if(gubun.equalsIgnoreCase("3")) {
                                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                    new ErrorData(DaquvConfig.CODE.KEYPAD_ADDRESS, mContext.getString(R.string.err_msg_daquv_15)));
                                        } else {
                                            if(TextUtils.isEmpty(nluResultResponse.getIntent())) {
                                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                        new ErrorData(DaquvConfig.CODE.KEYPAD_COMPANY, mContext.getString(R.string.err_msg_daquv_15)));
                                            } else {
                                                getTTSBinary(mContext.getString(R.string.err_msg_daquv_15), null, DaquvConfig.CODE.API_NLU_REASK);
                                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_REASK, mContext.getString(R.string.err_msg_daquv_15));
                                            }
                                        }
                                    }
                                } else {
                                    if(TextUtils.isEmpty(nluResultResponse.getIntent())) {
                                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                                new ErrorData(DaquvConfig.CODE.KEYPAD_COMPANY, bodyResponse.getMessage()));
                                    } else {
                                        getTTSBinary(mContext.getString(R.string.map_search_fail_counterpartname), null, DaquvConfig.CODE.API_NLU_REASK);
                                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_REASK, mContext.getString(R.string.map_search_fail_counterpartname));
                                    }
                                }
                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_SEARCH_COPLIST, mContext.getString(R.string.err_msg_daquv_13)));
                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable e) throws Exception {
                            sendError(e);
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_SEARCH_COPLIST, mContext.getString(R.string.err_msg_daquv_13)));
                        }
                    }));

        } catch ( JSONException e) {
            Logger.error(e);
        }
    }

    /**
     * 메인 페이지 요청
     *
     * @param url 메인페이지 주소
     */
    public void getMainPage(String url) {
        mainUrl = url;
        mainData = ("JWT_TOKEN=" + DaquvConfig.ibkToken);
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_MAIN_DATA, url);
    }


    /**
     * 재질의 페이지 요청
     * TTS API 실행(재잘의 문구)
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getReAskPage(NLUResultResponse nluResultResponse) {
        if (!TextUtils.isEmpty(nluResultResponse.getTts())) {
            TTSResponse response = new TTSResponse(nluResultResponse.getTts(), DaquvConfig.CODE.API_NLU_REASK);
            DaquvConfig.ttsSession = nluResultResponse.getTts().hashCode();
            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_TTS, response);
        } else {
            getTTSBinary(nluResultResponse.getTtsText(), null, DaquvConfig.CODE.API_NLU_REASK);
        }
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_REASK, nluResultResponse.getTtsText());
    }

    /**
     * 실패 페이지 요청
     * TTS API 실행(실패 문구)
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getFailPage(NLUResultResponse nluResultResponse) {
        DaquvSDK.getInstance().getEngine().addFailCount();
        if (DaquvSDK.getInstance().getEngine().isMaxFailCount()) {
            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_FAIL_MAX, "API_NLU_FAIL_MAX");
            return;
        }
        String message;
        if (TextUtils.isEmpty(nluResultResponse.getTts())) {
            message = mContext.getString(R.string.err_fail_title);
            getTTSBinary(message, null, DaquvConfig.CODE.API_NLU_FAIL);
        } else {
            message = nluResultResponse.getTtsText();
            getTTSBinary(message, null, DaquvConfig.CODE.API_NLU_FAIL);
        }
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_FAIL, message);
    }

    /**
     * 중복기업 확인 요청
     *
     * @param countpartname NLU 데이터
     */
    public void getCusInfo(String countpartname) {
        //BODY
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("entNm", countpartname);

            Callable<Response> callable = () -> {
                HttpClient client = new HttpClient.Builder()
                        .setUrl(DaquvConfig.API.CRM_GET_CUSINFO)
                        .setCookie(getCookieJar())
                        .setCache(responseCache)
                        .setJsonData(jsonObject.toString())
                        .addIBKToken(true)

                        .builder();
                return client.getCall().execute();
            };

            commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                    .observeOn(Schedulers.io())
                    .subscribe(new Consumer<Response>() {
                        @Override
                        public void accept(Response response) throws Exception {
                            BaseResponse baseResponse = new BaseResponse(response, responseCache);
                            String body = baseResponse.getBody();
                            Logger.dev(body);
                            if (baseResponse.isSuccess()) {
                                CusInfoModel bodyResponse = new Gson().fromJson(body, CusInfoModel.class);
                                if(!TextUtils.isEmpty(bodyResponse.getBody().getUrl())) {
                                    NLUResultResponse listItemResponse = new NLUResultResponse();
                                    listItemResponse.setUrl(bodyResponse.getBody().getUrl());
                                    listItemResponse.setIntent("IB017");

                                    ArrayList<Entities> entities = new ArrayList<>();
                                    entities.add(new Entities("COUNTERPARTNAME", countpartname,null,null));
                                    listItemResponse.setEntities(entities);

                                    getResultPage(listItemResponse);
                                } else if(!TextUtils.isEmpty(bodyResponse.getBody().getCompanyId())){
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_GET_CUSINFO, bodyResponse.getBody());
                                } else {
                                    getTTSBinary(mContext.getString(R.string.map_search_fail_counterpartname), null, DaquvConfig.CODE.API_NLU_REASK);
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_REASK, mContext.getString(R.string.map_search_fail_counterpartname));
                                }
                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_GET_CUSINFO, mContext.getString(R.string.err_msg_daquv_13)));
                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable e) throws Exception {
                            sendError(e);
                        }
                    }));

        } catch ( JSONException e) {
            Logger.error(e);
        }
    }

    /**
     * 상담내용 등록 페이지 요청
     * TTS API 실행(재잘의 문구)
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getConsultPage(NLUResultResponse nluResultResponse) {
        String countpartname = "";
        if(nluResultResponse.getEntities() != null && nluResultResponse.getEntities().size() > 0) {
            for(Entities entities : nluResultResponse.getEntities()) {
                if(!TextUtils.isEmpty(entities.getEntity()) &&
                        entities.getEntity().equalsIgnoreCase("COUNTERPARTNAME")) {
                    countpartname = entities.getValue();
                }
            }
        }
        getCusInfo(countpartname);
    }

    public void uploadConsultData(String companyId, String entNm , String dscsnDe, String dscsnTime , String dscsnCn, String dscsnCd, String resTypeCd) {

        ConsultRequest request = new ConsultRequest(companyId, entNm, dscsnDe, dscsnTime, dscsnCn, dscsnCd, resTypeCd);

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_CONSULT_URL)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(request.getJSON())
                    .addIBKToken(true)

                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        if (baseResponse.isSuccess()) {
                            BaseResponse bodyResponse = new Gson().fromJson(baseResponse.getBody(), BaseResponse.class);
                            if(bodyResponse.success()) {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_CONSULT_UPLOAD, bodyResponse);
                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_CONSULT_UPLOAD, mContext.getString(R.string.err_msg_daquv_11)));
                            }
                        } else {
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_CONSULT_UPLOAD, mContext.getString(R.string.err_msg_daquv_11)));
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Log.d("DDDDD", throwable.getMessage());
                        sendError(throwable);
                    }
                }));

    }

    public void setUttHistory(String utterance, String intentCode, ArrayList<Entities> entities, String emn, String ldinSe) {

        UttHistoryRequest request = new UttHistoryRequest(utterance, intentCode, entities , emn , ldinSe);

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_SET_UTT_HISTORY)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(request.getJSON())
                    .addIBKToken(true)
                    .isLogging(true)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        Logger.dev(response.body().string());
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        Logger.dev(throwable.getMessage());
                    }
                }));

    }


    /**
     * TTS Binary 요청
     *
     * @param tts 변환할 TTS 문구
     */
    public void getTTSBinary(String tts, String callback, int code) {
        //TTS 를 사용하지 않는다면 API 실행하지 않고 리턴
        if(!SharedPref.getInstance().getBoolean(DaquvConfig.Preference.KEY_PREF_USE_TTS, true)) {
            TTSResponse ttsResponse = new TTSResponse(DaquvUtil.loadTTSBinary(mContext , "tts_fail"), code);
            if (!TextUtils.isEmpty(callback)) {
                ttsResponse.setCallBack(callback);
            }
            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_TTS, ttsResponse);
            return;
        }
        DaquvConfig.ttsSession = tts.hashCode();
        Callable<Response> callable = () -> {

            HashMap<String, String> parameter = new HashMap<>();
            parameter.put("text", tts);

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("text", tts);

            String url = "";
            switch (DaquvConfig.service) {
                case HUB:
                case POSCO:
                    url = DaquvConfig.API.TTS_URL;
                    break;
                case IBKCRM:
                    url = DaquvConfig.API.CRM_TTS_URL;
                    break;
                default:
                    url = DaquvConfig.API.TTS_URL;
                    break;
            }

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addJWTToken(false)
                    .addIBKToken(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service)
                    .isPost(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service)
                    .setParameter(parameter)
                    .setJsonData(jsonObject.toString())
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        try {
                            if (baseResponse.isSuccess()) {
                                TTSModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), TTSModel.class);
                                if (!TextUtils.isEmpty(callback)) {
                                    bodyResponse.getItems().setCallBack(callback);
                                }
                                if (code > 0) {
                                    bodyResponse.getItems().setCode(code);
                                }
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_TTS, bodyResponse.getItems());
                            } else {
                                Logger.error(mContext.getString(R.string.err_msg_daquv_7) + "::" + response.body().string());
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_TTS, mContext.getString(R.string.err_msg_daquv_7)));
                            }
                        } catch (JsonSyntaxException e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    public void getTTSBinary(String tts) {
        getTTSBinary(tts, null, 0);
    }


    /**
     * 음성파일 업로드
     * @param url 음성파일 URL
     * @param filePath 음성파일 주소
     */
    public void uploadAudioFile(String beforeStt, String afterStt ,String filePath, String type, String channel) {
        File file = new File(filePath);
        Callable<Response> callable = () -> {

            MultipartBody.Builder bodyBuilder = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart(
                            "sttFile",
                            file.getName(),
                            RequestBody.create(MediaType.parse("application/octet-stream"), file)
                    )
                    .addFormDataPart("beforeStt", beforeStt)
                    .addFormDataPart("afterStt", afterStt)
                    .addFormDataPart("type", type)
                    .addFormDataPart("channel", channel);

            String mUrl = "https://admin.daquv.com/api/stt";

            HttpClient client = new HttpClient.Builder()
                    .setUrl(mUrl)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setBody(bodyBuilder.build())
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse httpResponse = new BaseResponse(response, responseCache);
                        if (httpResponse.isSuccess()) {
                            String json = httpResponse.getBody();

                            BaseModel bodyResponse = new Gson().fromJson(json, BaseModel.class);
                            if(bodyResponse.isSuccess()) {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_FILE_UPLOAD,  bodyResponse);
                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_FILE_UPLOAD, bodyResponse.getMessage()));
                            }
                        } else {
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_FILE_UPLOAD, response.message()));
                        }
                        try {
                            if(file.exists()) {
                                file.delete();
                            }
                        } catch (Exception e) {
                            e.getMessage();
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                new ErrorData(DaquvConfig.CODE.API_FILE_UPLOAD, throwable.getMessage()));
                    }
                }));
    }

    /**
     * 지도 필터 데이터 요청
     */
    public void getMapFilter() {
        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_GET_MAP_FILTER)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addIBKToken(true)
                    .isPost(false)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .onErrorReturn(new Function<Throwable, Response>() {
                    @Override
                    public Response apply(Throwable throwable) throws Exception {
                        sendError(throwable);
                        return null;
                    }
                })
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        try {
                            if (baseResponse.isSuccess()) {
                                MapFilterModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), MapFilterModel.class);
                                DaquvConfig.mapFilterList = bodyResponse;
                                for(MapFilterResponse data : DaquvConfig.mapFilterList.getFilter()) {
                                    if(data.getCategory().equalsIgnoreCase("radius")) {
                                        DaquvConfig.defaultRadius = data.getValue().get(0).getName();
                                    }
                                    if(!TextUtils.isEmpty(data.getAllYn()) && data.getAllYn().equalsIgnoreCase("Y")) {
                                        boolean isContain = false;
                                        for(FilterValue value : data.getValue()) {
                                            if (value.getName().equalsIgnoreCase("전체")) {
                                                isContain = true;
                                                break;
                                            }
                                        }
                                        if(!isContain) {
                                            data.getValue().add(0 , new FilterValue("","전체"));
                                        }
                                        if(data.getType().equalsIgnoreCase("switch")) {
                                            data.setType("three");
                                        }
                                    }
                                    DaquvUtil.initFilterValue(data);
                                }

                                MapFilterResponse navi = new MapFilterResponse();
                                navi.setCategory("navi");
                                navi.setSearch("N");
                                navi.setType("select");
                                navi.setName("길찾기/경로 설정");
                                if (TextUtils.isEmpty(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_NAVI))) {
                                    SharedPref.getInstance().put(DaquvConfig.Preference.KEY_NAVI, DaquvConfig.appConfig.mapInfo.navi);
                                }
                                if (TextUtils.isEmpty(SharedPref.getInstance().getString(DaquvConfig.Preference.KEY_MULTI_NAVI))) {
                                    SharedPref.getInstance().put(DaquvConfig.Preference.KEY_MULTI_NAVI, DaquvConfig.appConfig.mapInfo.multiNavi);
                                }
                                ArrayList<FilterValue> naviValue = new ArrayList<>();
                                naviValue.add(new FilterValue("default",""));
                                navi.setValue(naviValue);
                                DaquvConfig.mapFilterList.getFilter().add(0, navi);
                            }
                        } catch (JsonSyntaxException e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    /**
     * 상담 필터 데이터 요청
     */
    public void getCommCode(String cmmnCd) {
        Callable<Response> callable = () -> {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("cmmn_cd", cmmnCd);
            jsonObject.put("order_by", "desc");

            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_GET_COMM_CODE)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addIBKToken(true)
                    .setJsonData(jsonObject.toString())
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .onErrorReturn(new Function<Throwable, Response>() {
                    @Override
                    public Response apply(Throwable throwable) throws Exception {
                        sendError(throwable);
                        return null;
                    }
                })
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        try {
                            if (baseResponse.isSuccess()) {
                                CommCodeModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), CommCodeModel.class);
                                if("CNSL".equalsIgnoreCase(cmmnCd)) {
                                    DaquvConfig.commCodeModel = bodyResponse;
                                } else if("RGST".equalsIgnoreCase(cmmnCd)) {
                                    DaquvConfig.regCodeModel = bodyResponse;
                                }
                            }
                        } catch (JsonSyntaxException e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    /**
     * TTS Binary 요청
     */
    public void getSttReplaceData() {


        Callable<Response> callable = () -> {

            String url = "";
            switch (DaquvConfig.service) {
                case HUB:
                case POSCO:
                    url = DaquvConfig.API.STT_REPLACE_URL;
                    break;
                case IBKCRM:
                    url = DaquvConfig.API.CRM_STT_REPLACE_URL;
                    break;
                default:
                    url = DaquvConfig.API.STT_REPLACE_URL;
                    break;
            }

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addIBKToken(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service)
                    .isPost(false)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        try {
                            if (baseResponse.isSuccess()) {
                                STTReplaceResponse bodyResponse = new Gson().fromJson(baseResponse.getBody(), STTReplaceResponse.class);
                                DaquvConfig.replaces = bodyResponse.getReplaces();
                            }
                        } catch (JsonSyntaxException e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    /**
     * AppNotice 요청
     */
    public void getAppNotice() {
        Callable<Response> callable = () -> {
            String url = DaquvConfig.API.CRM_GET_APP_NOTICE;
            DaquvConfig.jwtToken = "";

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .isPost(false)

                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        try {
                            if (baseResponse.isSuccess()) {
                                AppNoticeModel bodyResponse = new Gson().fromJson(baseResponse.getBody(), AppNoticeModel.class);
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_GET_APPNOTICE, bodyResponse.getBody());
                            } else {
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                        new ErrorData(DaquvConfig.CODE.API_GET_APPNOTICE, mContext.getString(R.string.network_error)));
                            }
                        } catch (JsonSyntaxException e) {
                            sendError(e);
                            mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                    new ErrorData(DaquvConfig.CODE.API_GET_APPNOTICE, mContext.getString(R.string.network_error)));                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR,
                                new ErrorData(DaquvConfig.CODE.API_GET_APPNOTICE, mContext.getString(R.string.network_error)));
                    }
                }));
    }

    /**
     * AppConfig 요청
     */
    public void getAppConfig() {
        Callable<Response> callable = () -> {
            String url = DaquvConfig.API.CRM_APPCONFIG_INFO;

            HttpClient client = new HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .addIBKToken(DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service)
                    .isPost(false)
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        BaseResponse baseResponse = new BaseResponse(response, responseCache);
                        try {
                            if (baseResponse.isSuccess()) {
                                AppConfig bodyResponse = new Gson().fromJson(baseResponse.getBody(), AppConfig.class);
                                DaquvConfig.appConfig = bodyResponse;
                                DaquvSDK.getInstance().initAppConfig(mContext);
                            }
                        } catch (JsonSyntaxException e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }


    /**
     * 인증번호 요청
     */
    public void crmGetRequestCode(String appId,
                                  String cellPhoneNo,
                                  String birthday,
                                  String ecnmc,
                                  String name,
                                  String cellPhoneVendor,
                                  String frnr) {
        REQ_SVC_P041 reqJsonObject = new REQ_SVC_P041(appId, cellPhoneNo, birthday, ecnmc, name, cellPhoneVendor, frnr);

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_BASE_URL)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(new TranJson().makeTranData(reqJsonObject).toString())
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        try {
                            if (response.isSuccessful()) {
                                RES_SVC_P041 bodyResponse = new Gson().fromJson(response.body().string(), RES_SVC_P041.class);
                                if (bodyResponse.getBody() == null) {
                                    Logger.error(mContext.getString(R.string.err_msg_daquv_5) + "::" + bodyResponse.getRsltMsg());
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, mContext.getString(R.string.err_msg_daquv_5));
                                    return;
                                }
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_REQUEST_CODE, bodyResponse);
                            } else {
                                Logger.error(mContext.getString(R.string.err_msg_daquv_5) + "::" + response.body().string());
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, mContext.getString(R.string.err_msg_daquv_5));
                            }
                        } catch (JsonSyntaxException e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }

    /**
     * 인증번호 검증
     */
    public void crmGetVerifyCode(String appId,
                                 String clphNo,
                                 String trscUnqNo,
                                 String smsCertNo) {
        REQ_SVC_C028 reqJsonObject = new REQ_SVC_C028(appId, clphNo, trscUnqNo, smsCertNo);

        Callable<Response> callable = () -> {
            HttpClient client = new HttpClient.Builder()
                    .setUrl(DaquvConfig.API.CRM_BASE_URL)
                    .setCookie(getCookieJar())
                    .setCache(responseCache)
                    .setJsonData(new TranJson().makeTranData(reqJsonObject).toString())
                    .builder();
            return client.getCall().execute();
        };

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new Consumer<Response>() {
                    @Override
                    public void accept(Response response) throws Exception {
                        try {
                            if (response.isSuccessful()) {
                                RES_SVC_C028 bodyResponse = new Gson().fromJson(response.body().string(), RES_SVC_C028.class);
                                if (bodyResponse.getBody() == null) {
                                    Logger.error(mContext.getString(R.string.err_msg_daquv_6) + "::" + bodyResponse.getRsltMsg());
                                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, mContext.getString(R.string.err_msg_daquv_6));
                                    return;
                                }
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_VERIFY_CODE, bodyResponse);
                            } else {
                                Logger.error(mContext.getString(R.string.err_msg_daquv_6) + "::" + response.body().string());
                                mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, mContext.getString(R.string.err_msg_daquv_6));
                            }
                        } catch (JsonSyntaxException e) {
                            sendError(e);
                        }
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        sendError(throwable);
                    }
                }));
    }


    //============== NLU CONVERSION ================//

    /**
     * 순번 데이터 반환
     *
     * @param nluResultResponse NLU 데이터
     */
    public void getTURNData(NLUResultResponse nluResultResponse) {
        if (!TextUtils.isEmpty(nluResultResponse.getIntent()) && nluResultResponse.getIntent().equals(DaquvConfig.appConfig.intentCodes.turn)) {
            for (Entities entities : nluResultResponse.getEntities()) {
                if (entities.getEntity().equals("TURN")) {
                    mAPICallBack.onAPIResult(DaquvConfig.CODE.API_NLU_TURN, entities.getValue());
                    return;
                }
            }
        }
        mAPICallBack.onAPIResult(DaquvConfig.CODE.API_ERROR, new ErrorData(DaquvConfig.CODE.API_NLU_TURN, mContext.getString(R.string.err_fail_turn)));
    }

    /**
     * 기업명 데이터 반환
     *
     */
    public void getCompanyData(String company) {
        mAPICallBack.onAPIResult(DaquvConfig.CODE.KEYPAD_COMPANY, company);
    }

    public void getAddressData(String address) {
        mAPICallBack.onAPIResult(DaquvConfig.CODE.KEYPAD_ADDRESS, address);
    }
}