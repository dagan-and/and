package com.daquv.sdk.core;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.STTReplaceResponse;
import com.daquv.sdk.stt.itl.ITLModel;
import com.daquv.sdk.stt.itl.api.ItlController;
import com.daquv.sdk.stt.itl.api.ItlSocketIoClient;
import com.daquv.sdk.utils.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;


public class DaquvEngine {
    private ArrayList<Callback> mCallback;
    private final Context mContext;
    private boolean isRunning = false;
    private boolean isContinue = false;
    private boolean isTurn = false;
    private final ArrayList<String> mHistory = new ArrayList<>();   //음성인식 단계별 데이터
    private String finalString = null;                              //음성인식 완료 데이터

    public static class Callback {
        public void onResult(int code, Object result) {
            /**
             * 엔진 응답 CallBack
             * - API 동작
             * - STT 동작
             */
        }
    }


    public DaquvEngine(Context context) {
        this.mContext = context;
    }

    public boolean isRunning() {
        return isRunning;
    }
    public boolean isTurn() {return isTurn;}

    public void initEngine() {
        if (DaquvConfig.engine == DaquvConfig.ENGINE.ITL) {
            ITLModel.getInstance().launchITLEngine(mContext, new ItlController.OnResultListener() {
                @Override
                public void onResult(Message message) {
                    switch (message.what) {
                        case ItlSocketIoClient.ALERT:
                            if(!isContinue) {
                                onAPIResult(DaquvConfig.CODE.ENGINE_ERROR_VOICE, new ErrorData(ItlSocketIoClient.ALERT, (String) message.obj));
                                stopEngine();
                            }
                            break;
                        case ItlSocketIoClient.TIMEOUT:
                            if(!isContinue) {
                                onAPIResult(DaquvConfig.CODE.ENGINE_ERROR_VOICE, new ErrorData(ItlSocketIoClient.TIMEOUT, (String) message.obj));
                                stopEngine();
                            }
                            break;
                        case ItlSocketIoClient.READY:
                            onAPIResult(DaquvConfig.CODE.ENGINE_INIT, null);
                            break;
                        case ItlSocketIoClient.JSON_RESULT:
                            String json = (String) message.obj;
                            String result = null;
                            String status = null;
                            try {
                                JSONObject jObj = new JSONObject(json);
                                result = jObj.getString("sentence");
                                status = jObj.getString("status");
                            } catch (JSONException e) {
                                Logger.error(e);
                            }
                            if(isContinue) {
                                if (ITLModel.STATUS.PARTIAL.name().equals(status)) {
                                    onAPIResult(DaquvConfig.CODE.ENGINE_RUNNING_DATA, result);
                                } else if (ITLModel.STATUS.FINAL.name().equals(status)) {
                                    //문구 치환
                                    try {
                                        if(DaquvConfig.replaces.size() > 0) {
                                            for(STTReplaceResponse.STTReplace replace : DaquvConfig.replaces) {
                                                result = result.replace(replace.getBefore(), replace.getAfter());
                                            }
                                        }
                                    } catch (NullPointerException e) {
                                        Logger.error(e);
                                    }
                                    onAPIResult(DaquvConfig.CODE.ENGINE_CONTINUE_DATA, result);
                                }
                            } else {
                                if (TextUtils.isEmpty(result) || TextUtils.isEmpty(status)) {
                                    onAPIResult(DaquvConfig.CODE.ENGINE_NONE_DATA, null);
                                    stopEngine();
                                } else if (ITLModel.STATUS.PARTIAL.name().equals(status)) {
                                    mHistory.add(result);
                                    onAPIResult(DaquvConfig.CODE.ENGINE_RUNNING_DATA, result);
                                } else if (ITLModel.STATUS.FINAL.name().equals(status)) {
                                    finalString = result;
                                    //문구 치환
                                    try {
                                        if(DaquvConfig.replaces.size() > 0) {
                                            for(STTReplaceResponse.STTReplace replace : DaquvConfig.replaces) {
                                                result = result.replace(replace.getBefore(), replace.getAfter());
                                            }
                                        }
                                    } catch (NullPointerException e) {
                                        Logger.error(e);
                                    }
                                    onAPIResult(DaquvConfig.CODE.ENGINE_FINAL_DATA, result);
                                    stopEngine();
                                }
                            }
                            break;
                        case  ItlSocketIoClient.SAVE_PCM:
                            try {
                                //아무말도 안한 경우는 PCM 파일 삭제하고 API 보내지 않음
                                if(mHistory.isEmpty() &&  message.obj instanceof String) {
                                    File file = new File((String) message.obj);
                                    if(file.exists()) {
                                        file.delete();
                                    }
                                    return;
                                }
                                StringBuilder beforeStt = new StringBuilder();
                                String afterStt = "";
                                String sttResult = "F";
                                if(!mHistory.isEmpty()) {
                                    for(String data : mHistory) {
                                        beforeStt.append(data).append(",");
                                    }
                                    beforeStt.deleteCharAt(beforeStt.length() - 1);
                                }
                                if(!TextUtils.isEmpty(finalString)) {
                                    afterStt = finalString;
                                    sttResult = "S";
                                }
                                Logger.dev("========================");
                                Logger.dev("beforeStt:" + beforeStt);
                                Logger.dev("afterStt:" + afterStt);
                                Logger.dev("type:" + sttResult);
                                Logger.dev("channel:" + DaquvConfig.sttLogChannel);
                                Logger.dev("========================");
                                if(message.obj instanceof String) {
                                    Logger.dev("PCM:" + message.obj);
                                    DaquvSDK.getInstance().getAPI().uploadAudioFile(
                                            beforeStt.toString(),
                                            afterStt,
                                            (String) message.obj,
                                            sttResult,
                                            DaquvConfig.sttLogChannel);
                                }
                            } catch (Exception e) {
                                Logger.error(e);
                            }
                            break;
                        default:
                            Logger.dev(String.valueOf(message.obj));
                            break;
                    }
                }
            });
        }
    }

    public void stopEngine() {
        isRunning = false;
        onAPIResult(DaquvConfig.CODE.ENGINE_STOP_VOICE, null);

        if (DaquvConfig.engine == DaquvConfig.ENGINE.ITL) {
            ITLModel.getInstance().stopController();
        }
    }

    public void startEngine() {
        if(isRunning) {
            return;
        }
        DaquvSDK.getInstance().stopTTS();
        onAPIResult(DaquvConfig.CODE.ENGINE_START_VOICE, null);
        isRunning = true;
        isContinue = false;
        isTurn = false;
        mHistory.clear();
        finalString = null;
        if (DaquvConfig.engine == DaquvConfig.ENGINE.ITL) {
            ITLModel.getInstance().startController();
        }
    }

    public void startEngineContinue() {
        startEngine();
        isRunning = true;
        isContinue = true;
    }

    public void startEngineTURN() {
        startEngine();
        isRunning = true;
        isTurn = true;
    }

    public void cleanState() {
        isRunning = false;
        isContinue = false;
        isTurn = false;
    }

    public void addCallBack(Callback callback) {
        if (mCallback == null || mCallback.isEmpty()) {
            mCallback = new ArrayList<>();
        }
        mCallback.add(callback);
    }

    public void removeCallBack(Callback callback) {
        if (mCallback == null || mCallback.isEmpty()) {
            return;
        }
        mCallback.remove(callback);
    }

    public void clearCallBack() {
        if (mCallback == null || mCallback.isEmpty()) {
            return;
        }
        mCallback.clear();
    }

    public void onAPIResult(int code, Object result) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                if(mCallback != null && mCallback.size() > 0) {
                    for (Callback callback : mCallback) {
                        callback.onResult(code, result);
                    }
                }
            }
        });
    }


    /**
     * isContinue 발화 실패 가능 여부
     * resetFailCount 실패 카운트 초기화
     * addFailCount 실패 카운트 증가
     * <p>
     * 음성인식 -> 실패 -> 음성인식 을 한 사이클로 봐서 반복할 수 있는 횟수
     */
    private final static int MAX_FAIL_COUNT = 3;
    private int failCount = 0;

    public boolean isMaxFailCount() {
        if(DaquvConfig.useNLUFailCount) {
            return failCount >= MAX_FAIL_COUNT;
        } else {
            return false;
        }
    }

    public void resetFailCount() {
        failCount = 0;
    }

    public void addFailCount() {
        failCount++;
    }


}