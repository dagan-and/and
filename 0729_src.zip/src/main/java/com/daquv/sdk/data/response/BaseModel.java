package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;

public class BaseModel {

    @SerializedName("status")
    private int status;

    @SerializedName("retCd")
    private String retCd;

    @SerializedName("success")
    private boolean success;

    @SerializedName("message")
    private String message;

    public int getStatus() {
        return status;
    }

    public String getRetCd() {
        return retCd;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}
