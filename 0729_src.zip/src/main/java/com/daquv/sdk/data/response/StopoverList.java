package com.daquv.sdk.data.response;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;

public class StopoverList {
    @SerializedName("stopoverlist")
    public ArrayList<Stopover> stopovers;

    public class Stopover {
        @SerializedName("lat")
        public double latitude;

        @SerializedName("lng")
        public double longitude;

        @SerializedName("cpynm")
        public String companyName;

        public Stopover(double latitude, double longitude, String companyName) {
            this.latitude = latitude;
            this.longitude = longitude;
            this.companyName = companyName;
        }

        // Add getters and setters if needed
    }
}
