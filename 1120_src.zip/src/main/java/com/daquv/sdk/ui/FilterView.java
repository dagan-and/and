package com.daquv.sdk.ui;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.R;
import com.daquv.sdk.data.response.MapFilterModel;
import com.daquv.sdk.data.response.MapFilterResponse;
import com.daquv.sdk.data.response.FilterValue;
import com.daquv.sdk.ui.adapter.FilterAdapter;
import com.daquv.sdk.ui.component.BasicButtonView;
import com.daquv.sdk.utils.SharedPref;
import com.google.gson.Gson;

import java.util.ArrayList;

public class FilterView extends FrameLayout {

    private final ImageView filterLine;
    private final RecyclerView recyclerView;
    private final ImageView btnPre;
    private final BasicButtonView btnClear;
    private final BasicButtonView btnSearch;
    private FilterAdapter adapter;
    private String tempFilterJson;
    private boolean isSearch = false;

    public FilterView(@NonNull Context context) {
        super(context);
        View view = LayoutInflater.from(context).inflate(R.layout.view_filter, null);
        this.recyclerView = view.findViewById(R.id.filter_recyclerview);
        this.btnPre = view.findViewById(R.id.btn_pre);
        this.btnClear = view.findViewById(R.id.btn_clear);
        this.btnSearch = view.findViewById(R.id.btn_search);
        this.filterLine = view.findViewById(R.id.filter_line);
        addView(view);
    }

    public void init(ArrayList<MapFilterResponse> listItem, OnStateListener listener) {
        btnPre.setOnClickListener(view -> {
            if (listener != null) {
                listener.onBackPress();
            }
        });
        btnClear.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                reset(adapter.getFilters());
            }
        });
        btnSearch.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    isSearch = true;
                    tempFilterJson = new Gson().toJson(DaquvConfig.mapFilterList);
                    listener.onSearch(adapter.getFilters());
                    listener.onBackPress();
                }
            }
        });
        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstVisibleItemPosition() == 0
                        && ((LinearLayoutManager) recyclerView.getLayoutManager()).findFirstCompletelyVisibleItemPosition() == 0) {
                    filterLine.setVisibility(View.INVISIBLE);
                } else {
                    filterLine.setVisibility(View.VISIBLE);
                }
            }
        });

        for (MapFilterResponse data : listItem) {
            if(!TextUtils.isEmpty(data.getAllYn()) && data.getAllYn().equalsIgnoreCase("Y")) {
                boolean isContain = false;
                for(FilterValue value : data.getValue()) {
                    if(value.getName().equalsIgnoreCase("전체")) {
                        isContain = true;
                    }
                }
                if(!isContain) {
                    data.getValue().add(0 , new FilterValue("","전체"));
                }
                if(data.getType().equalsIgnoreCase("switch")) {
                    data.setType("three");
                }
            }
            data.getSelected().add(data.getValue().get(0));
        }

        adapter = new FilterAdapter(listItem);
        adapter.setOnItemClickListener((v, data) -> {
            if (listener != null) {
                listener.onItemClick(v.getTag().toString(), data);
            }
        });
        recyclerView.setAdapter(adapter);
        tempFilterJson = new Gson().toJson(DaquvConfig.mapFilterList);
    }

    public void update(String category, ArrayList<FilterValue> data) {
        ArrayList<MapFilterResponse> filters = adapter.getFilters();

        for (MapFilterResponse items : filters) {
            if (items.getCategory().equals(category)) {
                items.setSelected(data);
            }
        }
        adapter.setFilters(filters);
    }

    private void reset(ArrayList<MapFilterResponse> listItem) {
        for (MapFilterResponse data : listItem) {
            data.getSelected().clear();
            data.getSelected().add(data.getValue().get(0));
        }
        adapter.setFilters(listItem);
    }

    public void initFlag() {
        isSearch = false;
    }

    public void undoClear() {
        if(!isSearch) {
            DaquvConfig.mapFilterList = new Gson().fromJson(tempFilterJson , MapFilterModel.class);
            adapter.setFilters(DaquvConfig.mapFilterList.getFilter());
        }
    }


    public interface OnStateListener {
        void onItemClick(String tag, MapFilterResponse data);
        void onSearch(ArrayList<MapFilterResponse> filters);
        void onBackPress();
    }
}
