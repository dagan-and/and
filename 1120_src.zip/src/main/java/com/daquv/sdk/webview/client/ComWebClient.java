package com.daquv.sdk.webview.client;

import android.annotation.TargetApi;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.text.TextUtils;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.DaquvSDK;
import com.daquv.sdk.utils.Logger;
import com.daquv.sdk.webview.ComWebView;
import com.daquv.sdk.webview.cache.WebviewResourceMappingHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;


/**
 * WebViewClient
 **/
public class ComWebClient extends WebViewClient {

    /** 클래스 구분 태그 */
    protected final String TAG = getClass().getSimpleName();

    protected ComWebView mWebView;

    /**
     * 생성자
     * @param webView JexWebView
     */
    public ComWebClient(ComWebView webView) {
        mWebView = webView;
    }


    @SuppressWarnings("Deprecation")
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        Logger.info("shouldOverrideUrlLoading :: " + url);

        return true;
    }

    @RequiresApi(Build.VERSION_CODES.N)
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        String url = request.getUrl().toString();
        Logger.info("WebResourceRequest.url :: " + request.getUrl().toString());

        if(request.getUrl().toString().contains("hubapp://stt")) {
            Uri uri = Uri.parse(request.getUrl().toString());
            DaquvSDK.getInstance().getEngine().onAPIResult(DaquvConfig.CODE.DIRECT_MOVE , uri.getQueryParameter("stttext"));
            return true;
        }

        return true;
    }

    /**
     * 로컬 케시 사용
     * @param view
     * @param request
     * @return
     */
    @Nullable
    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        if(DaquvConfig.useWebMemoryCache) {
            String resourceUrl = request.getUrl().toString();
            String fileExtension = WebviewResourceMappingHelper.getInstance().getFileExt(resourceUrl);
            if(WebviewResourceMappingHelper.getInstance().getOverridableNonExtensions().containsKey(resourceUrl)) {
                String encoding = "UTF-8";
                String fileForm = WebviewResourceMappingHelper.getInstance().getOverridableNonExtensions().get(resourceUrl);
                String localFilePath = WebviewResourceMappingHelper.getInstance().getLocalFilePathFromKey(fileForm);
                if (!TextUtils.isEmpty(localFilePath)) {
                    try {
                        Logger.info(localFilePath);
                        String mimeType = WebviewResourceMappingHelper.getInstance().getMimeType(fileExtension);
                        return WebviewResourceMappingHelper.getInstance().getWebResourceResponseFromFile(localFilePath, mimeType, encoding);
                    } catch (FileNotFoundException e) {
                        return super.shouldInterceptRequest(view,request);
                    }
                }
            }
        }

        Logger.info("resourceUrl :: " + request.getUrl().toString());
        return super.shouldInterceptRequest(view,request);
    }

    @Override
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        Logger.info("onPageStarted :: " + url);
        super.onPageStarted(view, url, favicon);
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        Logger.info("onPageFinished :: " + url);
        mWebView.onPageFinished();
    }

    @Override
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        Logger.error("failingUrl :: " + failingUrl);
        Logger.error("errorCode :: " + errorCode);
        Logger.error("errorDescription :: " + description);

        // Page Finish
        onPageFinished (view, failingUrl);
        // 에러 정보 Callback
        webViewErrorCallback(failingUrl, errorCode, description);

        super.onReceivedError(view, errorCode, description, failingUrl);
    }

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
        String url = "";
        int errorCode = 0;
        String errorMessage = "";

//        Logger.error("Method :: " + request.get());

        Logger.error("WebView isNull :: " + (view == null));
        if (view != null) {
            url = view.getUrl();
            Logger.error(" url :: " + url);
        }

        Logger.error("isNull :: " + (error == null));
        if (error != null) {
            errorCode = error.getErrorCode();
            errorMessage = error.getDescription().toString();
            Logger.error("errorCode :: " + error.getErrorCode());
            Logger.error("errorDescription :: " + error.getDescription());
        }

        // Page Finish
        onPageFinished (view, url);
        // 에러 정보 Callback
        webViewErrorCallback(url, errorCode, errorMessage);

        super.onReceivedError(view, request, error);
    }

    /**
     * WebView 에러 발생 시 화면단으로 Callback
     * @param failingUrl 실패 URL
     * @param errorCode 에러코드
     * @param errorMessage 에러메시지
     */
    private void webViewErrorCallback (String failingUrl, int errorCode, String errorMessage) {
        Logger.error("failingUrl :: " + failingUrl);
        Logger.error("errorCode :: " + errorCode);
        Logger.error("errorMessage :: " + errorMessage);
    }

    @Override
    public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
        handler.proceed();
    }
}
