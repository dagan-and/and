package com.daquv.sdk.utils;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.widget.Toast;

import com.daquv.sdk.DaquvConfig;
import com.daquv.sdk.R;
import com.daquv.sdk.data.request.LoginRequest;
import com.daquv.sdk.data.response.ErrorData;
import com.daquv.sdk.data.response.LocationItem;
import com.daquv.sdk.data.response.RsaKeyModel;
import com.daquv.sdk.utils.secure.RSAUtils;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.UUID;

public class DaquvUtil {

    /**
     * 고유 키값 생성
     * 디바이스고유값(UUID) + 페키지명 => MD5로 변환
     */
    @SuppressLint({"SimpleDateFormat", "HardwareIds"})
    public static String getUserKey(Context context) {
        String deviceId = "";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                deviceId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (TextUtils.isEmpty(deviceId)) {
            SharedPreferences sharedPrefs = context.getSharedPreferences("PREF_UNIQUE_ID", Context.MODE_PRIVATE);
            String uniqueID = sharedPrefs.getString("PREF_UNIQUE_ID", null);
            if (uniqueID == null) {
                uniqueID = UUID.randomUUID().toString().replace("-", "");
                SharedPreferences.Editor editor = sharedPrefs.edit();
                editor.putString("PREF_UNIQUE_ID", uniqueID);
                editor.apply();
            }
            deviceId = uniqueID;
        }
        return deviceId + context.getPackageName();
    }


    /**
     * 디바이스 정보 가져오기
     */
    @SuppressLint("HardwareIds")
    public static JSONObject getDeviceInfo(Context context) throws JSONException {
        JSONObject resultJson = new JSONObject();
        resultJson.put("OS", "ADR");
        resultJson.put("OS_VER", Build.VERSION.SDK_INT);
        resultJson.put("DEVICE_ID", Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID));
        resultJson.put("DEVICE_MODEL", Build.MODEL);

        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            String appVersion = packageInfo.versionName != null ? packageInfo.versionName.trim() : "";
            resultJson.put("APP_VER", appVersion);
        } catch (PackageManager.NameNotFoundException e) {
            resultJson.put("APP_VER", "");
        }

        resultJson.put("APP_ID", context.getPackageName());
        return resultJson;
    }

    /**
     * URL 주소 완성하기
     *
     * @param responseUrl URL주소
     */
    public static String getUrl(String responseUrl) {
        String url = responseUrl;
        String domainUrl = DaquvConfig.SERVICE.IBKCRM == DaquvConfig.service ?
                DaquvConfig.crmUrl : DaquvConfig.hubUrl;
        if (domainUrl.endsWith("/")) {
            domainUrl = domainUrl.substring(0, domainUrl.length() - 1);
        }
        if (url.startsWith("/")) {
            url = domainUrl + url;
        } else {
            url = domainUrl + "/" + url;
        }
        return url;
    }


    /**
     * TTS 바이너리 파일 불러오기
     *
     * @param context  Context
     * @param fileName 파일명
     * @return 바이너리 데이터
     */
    public static String loadTTSBinary(Context context, String fileName) {
        try {
            InputStream inputStream = context.getAssets().open(fileName);
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();

            return new String(buffer, StandardCharsets.UTF_8);
        } catch (IOException e) {
            Logger.error(e);
        }
        return "";
    }

    /**
     * 현재 앱의 현재 버전을 반환
     *
     * @param ctx Context
     * @return 앱버전
     */
    public static String getCurrentAppVer(Context ctx) {
        try {
            return getCurrentAppVer(ctx, ctx.getPackageName());
        } catch (PackageManager.NameNotFoundException e) {
            Logger.error(e);
            return "null";
        }
    }

    /**
     * 특정 앱의 현재 버전을 반환
     *
     * @param ctx         Context
     * @param packageName 앱 패키지 이름
     * @return 앱버전
     */
    public static String getCurrentAppVer(Context ctx, String packageName) throws PackageManager.NameNotFoundException {
        return ctx.getPackageManager().getPackageInfo(packageName, 0).versionName.trim();
    }

    /**
     * Android ID 반환
     * <br><br>
     * -
     *
     * @param context context
     * @return Android ID
     */
    public static String getAndroidID(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }


    /**
     * WebView Cookie Clear
     *
     * @param context Context
     * @param domain  도메인 URL
     */
    public static void clearCookie(Context context, String domain) {
        Logger.info("context isNull :: " + (context == null));
        Logger.info("context domain :: " + domain);

        if (context == null || TextUtils.isEmpty(domain))
            return;


        Logger.dev("SDK_INT :: " + Build.VERSION.SDK_INT);
        String strCookie = getCookie(domain);
        Logger.dev("Cookie String :: " + strCookie);

        if (!TextUtils.isEmpty(strCookie)) {
            String[] cookies = strCookie.split(";");
            for (String cookie : cookies) {
                Logger.dev("Cookie :: " + cookie);
                String[] cookieParts = cookie.split("=");

                if (cookieParts.length > 0) {
                    String cookieKey = "";
                    String cookieValue = "";
                    if (cookieParts.length == 1) {
                        cookieKey = cookieParts[0];
                    } else if (cookieParts.length == 2) {
                        cookieKey = cookieParts[0];
                        cookieValue = cookieParts[1];
                    }
                    Logger.dev("Cookie Key :: " + cookieKey);
                    Logger.dev("Cookie Value :: " + cookieValue);
                }
            }

            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.setCookie(domain, "");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cookieManager.removeSessionCookies(null);
                cookieManager.flush();
            } else {
                cookieManager.removeSessionCookie();
                CookieSyncManager cookieSyncManager;
                try {
                    cookieSyncManager = CookieSyncManager.getInstance();
                } catch (Exception e) {
                    cookieSyncManager = CookieSyncManager.createInstance(context);
                }
                cookieSyncManager.stopSync();
                cookieSyncManager.sync();
            }

            // TODO :: TEST
            strCookie = getCookie(domain);
            Logger.dev("After Cookie String :: " + strCookie);
        }
    }

    /**
     * 웹뷰 쿠키 반환
     *
     * @param domain 도메인
     * @return 웹뷰 쿠키
     */
    public static String getCookie(String domain) {
        Logger.info("domain :: " + domain);

        String cookie = null;
        Logger.dev("CookieManager.getInstance() isNull :: " +
                (CookieManager.getInstance() == null));
        if (!TextUtils.isEmpty(domain) && CookieManager.getInstance() != null)
            cookie = CookieManager.getInstance().getCookie(domain);

        Logger.dev("cookie :: " + cookie);

        return cookie;
    }

    /**
     * Exception 로그 가져오기
     */
    public static String getExceptionLog(Exception e) {
        String msg = e.getClass() + "[ " + e.getMessage() + " ]" + " >>> ";
        StackTraceElement[] traceElements = e.getStackTrace();
        for (StackTraceElement traceElement : traceElements) {
            msg += traceElement.toString() + "\n";
        }
        return msg;
    }

    /**
     * Exception 로그 가져오기
     */
    public static String getExceptionLog(Throwable e) {
        String msg = e.getClass() + "[ " + e.getMessage() + " ]" + " >>> ";
        StackTraceElement[] traceElements = e.getStackTrace();
        for (StackTraceElement traceElement : traceElements) {
            msg += traceElement.toString() + "\n";
        }
        return msg;
    }

    /**
     * Convert DP value to pixels
     */
    public static int convertDPtoPX(Context context, int dp) {
        float density = context.getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    /**
     * 바로가기 만들기
     */
    public static void addShortCut(Context context, Intent intent, String name, int iconResourceId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ShortcutInfo shortcut = new ShortcutInfo.Builder(context, name)
                    .setShortLabel(name)
                    .setLongLabel(name)
                    .setDisabledMessage(name)
                    .setIcon(Icon.createWithResource(context, iconResourceId))
                    .setIntent(intent)
                    .build();

            ShortcutManager shortcutManager = context.getSystemService(ShortcutManager.class);
            if (shortcutManager.isRequestPinShortcutSupported()) {
                Intent pinnedShortcutCallbackIntent = shortcutManager.createShortcutResultIntent(shortcut);
                PendingIntent successCallback;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    successCallback = PendingIntent.getBroadcast(context, /* request code */ 0,
                            pinnedShortcutCallbackIntent, /* flags */ PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                } else {
                    successCallback = PendingIntent.getBroadcast(context, /* request code */ 0,
                            pinnedShortcutCallbackIntent, /* flags */ PendingIntent.FLAG_UPDATE_CURRENT);
                }
                shortcutManager.requestPinShortcut(shortcut, successCallback.getIntentSender());
            }
        } else {
            Intent addIntent = new Intent();
            addIntent.putExtra(Intent.EXTRA_SHORTCUT_INTENT, intent);
            addIntent.putExtra(Intent.EXTRA_SHORTCUT_NAME, name);
            addIntent.putExtra(
                    Intent.EXTRA_SHORTCUT_ICON_RESOURCE,
                    Intent.ShortcutIconResource.fromContext(context, iconResourceId)
            );
            addIntent.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
            context.sendBroadcast(addIntent);
        }
    }


    /**
     * 카카오 길찾기
     */
    public static boolean runKakaoMap(Context context, ArrayList<LocationItem> data) {
        try {
            String scheme = "kakaomap://route?" +
                    "sp=" + data.get(0).getLatitude() + "," + data.get(0).getLongitude() +
                    "&ep=" + data.get(1).getLatitude() + "," + data.get(1).getLongitude() +
                    "&by=CAR";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, context.getString(R.string.map_kakao_error), Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    /**
     * 티맵 길찾기
     */
    public static boolean runTMap(Context context, ArrayList<LocationItem> data) {
        try {

            //        String scheme = "tmap://route?startx=127.1053971&starty=37.3595953&startname=그린팩토리" +
            //                "&goalx=127.1267772&goaly=37.4200267&goalname=성남시청" +
            //                "&vialist=[{\"poiName\":\"서울대학교\",\"navX\":\"126.9522394\",\"navY\":\"37.464007\"}," +
            //                "{\"poiName\":\"성남종합운동장\",\"navX\":\"127.137682\",\"navY\":\"37.433074\"}," +
            //                "{\"poiName\":\"성남시의료원\",\"navX\":\"127.139009\",\"navY\":\"37.445158\"}," +
            //                "{\"poiName\":\"한국전자기술연구원\",\"navX\":\"127.159736\",\"navY\":\"37.403898\"}," +
            //                "{\"poiName\":\"분당제생병원\",\"navX\":\"127.121663\",\"navY\":\"37.388305\"}]";
            //

            String scheme;
            if (data.size() > 2) {
                int lastIndex = data.size() - 1;

                JSONArray jsonArray = new JSONArray();

                for (int i = 1; i < data.size() - 1; i++) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("poiName", data.get(i).getCompanyNm());
                    jsonObject.put("navX", data.get(i).getLongitude());
                    jsonObject.put("navY", data.get(i).getLatitude());
                    jsonArray.put(jsonObject);
                }
                String vialist = jsonArray.toString();


                scheme = "tmap://route?" +
                        "startx=" + data.get(0).getLongitude() +
                        "&starty=" + data.get(0).getLatitude() +
                        "&startname=" + data.get(0).getCompanyNm() +
                        "&goalx=" + data.get(lastIndex).getLongitude() +
                        "&goaly=" + data.get(lastIndex).getLatitude() +
                        "&goalname=" + data.get(lastIndex).getCompanyNm() +
                        "&vialist=" + vialist;
            } else {
                scheme = "tmap://route?" +
                        "startx=" + data.get(0).getLongitude() +
                        "&starty=" + data.get(0).getLatitude() +
                        "&startname=" + data.get(0).getCompanyNm() +
                        "&goalx=" + data.get(1).getLongitude() +
                        "&goaly=" + data.get(1).getLatitude() +
                        "&goalname=" + data.get(1).getCompanyNm();
            }
            Logger.info(scheme);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, context.getString(R.string.map_tamp_error), Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    /**
     * 네이버맵 길찾기
     */
    public static boolean runNaverMap(Context context, ArrayList<LocationItem> data) {
        try {

            //            String scheme = "nmap://route/car?slat=37.3595953&slng=127.1053971&sname=%EA%B7%B8%EB%A6%B0%ED%8C%A9%ED%86%A0%EB%A6%AC" +
//                "&dlng=127.1267772&dlat=37.4200267&dname=%EC%84%B1%EB%82%A8%EC%8B%9C%EC%B2%AD" +
//                "&v1lng=126.9522394&v1lat=37.464007&v1name=%20%EC%84%9C%EC%9A%B8%EB%8C%80%ED%95%99%EA%B5%90" +
//                "&v2lng=127.137682&v2lat=37.433074&v2name=%EC%84%B1%EB%82%A8%EC%A2%85%ED%95%A9%EC%9A%B4%EB%8F%99%EC%9E%A5" +
//                "&v3lng=127.139009&v3lat=37.445158&v3name=%EC%84%B1%EB%82%A8%EC%8B%9C%EC%9D%98%EB%A3%8C%EC%9B%90" +
//                "&v4lng=127.159736&v4lat=37.403898&v4name=%ED%95%9C%EA%B5%AD%EC%A0%84%EC%9E%90%EA%B8%B0%EC%88%A0%EC%97%B0%EA%B5%AC%EC%9B%90" +
//                "&v5lng=127.121663&v5lat=37.388305&v5name=%EB%B6%84%EB%8B%B9%EC%A0%9C%EC%83%9D%EB%B3%91%EC%9B%90" +
//                "&appname=com.example.myapp";


            String scheme;
            if (data.size() > 2) {
                int lastIndex = data.size() - 1;
                int index = 0;
                StringBuilder vialist = new StringBuilder();
                for (int i = 1; i < data.size() - 1; i++) {
                    index++;
                    vialist.append("&v");
                    vialist.append(index);
                    vialist.append("lng=");
                    vialist.append(data.get(i).getLongitude());
                    vialist.append("&v");
                    vialist.append(index);
                    vialist.append("lat=");
                    vialist.append(data.get(i).getLatitude());
                    vialist.append("&v");
                    vialist.append(index);
                    vialist.append("name=");
                    vialist.append(URLEncoder.encode(data.get(i).getCompanyNm(), "UTF-8"));
                }
                scheme = "nmap://route/car?" +
                        "slng=" + data.get(0).getLongitude() +
                        "&slat=" + data.get(0).getLatitude() +
                        "&sname=" + URLEncoder.encode(data.get(0).getCompanyNm(), "UTF-8") +
                        "&dlng=" + data.get(lastIndex).getLongitude() +
                        "&dlat=" + data.get(lastIndex).getLatitude() +
                        "&dname=" + URLEncoder.encode(data.get(lastIndex).getCompanyNm(), "UTF-8") +
                         vialist +
                        "&appname=" + context.getPackageName();
            } else {
                scheme = "nmap://route/car?" +
                        "slng=" + data.get(0).getLongitude() +
                        "&slat=" + data.get(0).getLatitude() +
                        "&sname=" + URLEncoder.encode(data.get(0).getCompanyNm(), "UTF-8") +
                        "&dlng=" + data.get(1).getLongitude() +
                        "&dlat=" + data.get(1).getLatitude() +
                        "&dname=" + URLEncoder.encode(data.get(1).getCompanyNm(), "UTF-8") +
                        "&appname=" + context.getPackageName();
            }
            Logger.info(scheme);

            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(scheme));
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, context.getString(R.string.map_naver_error), Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
