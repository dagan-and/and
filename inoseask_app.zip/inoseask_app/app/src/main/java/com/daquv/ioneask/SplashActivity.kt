package com.daquv.ioneask

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.widget.ProgressBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.FileProvider
import androidx.core.splashscreen.SplashScreen
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.splashscreen.SplashScreenViewProvider
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import okhttp3.JavaNetCookieJar
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.Response
import okio.buffer
import okio.sink
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.CookieManager
import java.util.concurrent.Callable
import java.util.concurrent.Executors

class SplashActivity : AppCompatActivity() {

    val urlScheme = "ibkmportal://ibk?p=ava"
    val mportalPage = "http://ibk.kr/mp"
    val launcherPage = "https://nsemp.ibk.co.kr/ava/ask/appdown"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val splash =  installSplashScreen()
        setContentView(R.layout.activity_main)

        splash.setOnExitAnimationListener(object : SplashScreen.OnExitAnimationListener{
            override fun onSplashScreenExit(splashScreenViewProvider: SplashScreenViewProvider) {

            }
        })

        val commonDisposable = CompositeDisposable()
        val callable = Callable<Response> {
            //val url = "https://nsemp.ibk.co.kr/ava/exapi/ibkCrm/v1/auth/getAppInfo"
            val url = "http://203.235.68.48:5102/ava/exapi/ibkCrm/v1/auth/getAppInfo"

            val jsonData = "{ \"os_type\":\"AOS\" }"
            val client: HttpClient = HttpClient.Builder()
                    .setUrl(url)
                    .setCookie(JavaNetCookieJar(CookieManager()))
                    .setJsonData(jsonData)
                    .isPost(true)
                    .builder()
            client.call.execute()
        }

        commonDisposable.add(Observable.fromCallable(callable).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ response -> //Response
                    if (response.isSuccessful) {
                        val result = response.body!!.string()
                        Log.d("DAQUV_INFO", result)

                        val jsonObject = JSONObject(result)
                        if(!jsonObject.has("body")) {
                            init()
                            return@subscribe
                        }
                        val bodyObjects = jsonObject.getJSONObject("body")
                        if (!bodyObjects.has("version") || !bodyObjects.has("show_yn")) {
                            init()
                            return@subscribe
                        }

                        val current = BuildConfig.VERSION_NAME.replace(".","")
                        val version = bodyObjects.optString("version").replace(".","")
                        val use = bodyObjects.optString("show_yn")
                        if (use.equals("Y",true) &&
                                version.toFloat() > current.toFloat()) {
                            //엠포탈 다운로드 페이지 URL 로 이동
                            val builder = AlertDialog.Builder(this)
                            builder.setMessage("새로운 버전이 출시되었습니다.\n업데이트 후 이용해 주시기 바랍니다.")
                            builder.setPositiveButton("확인", null)
                            builder.setOnDismissListener {
                                val intent = Intent(this@SplashActivity, InstallActivity::class.java)
                                startActivity(intent)
                                overridePendingTransition(0,0)
                            }
                            builder.show()
                        } else {
                            init()
                        }
                    }
                }) { throwable ->
                    init()
                    Log.e("DAQUV_ERR", throwable.message!!)
                })
    }

    private fun init() {
        try {
            val intent = Intent()
            intent.action = Intent.ACTION_VIEW
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.data = Uri.parse(urlScheme)
            startActivity(intent)
            finishAffinity()
        } catch (e: RuntimeException) {
            //엠포탈 다운로드 페이지 URL 로 이동
            val builder = AlertDialog.Builder(this)
            builder.setCancelable(false)
            builder.setMessage("M포탈 앱이 설치되어있지 않습니다.\nM포탈 다운로드 사이트로 이동됩니다.")
            builder.setPositiveButton("확인", null)
            builder.setOnDismissListener {
                val intent = Intent()
                intent.action = Intent.ACTION_VIEW
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.data = Uri.parse(mportalPage)
                startActivity(intent)
                finishAffinity()
            }
            builder.show()
        }
    }
}