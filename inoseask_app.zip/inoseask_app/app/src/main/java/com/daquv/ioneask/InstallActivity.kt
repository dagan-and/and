package com.daquv.ioneask

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.widget.ProgressBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.FileProvider
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.buffer
import okio.sink
import java.io.File
import java.io.IOException
import java.util.concurrent.Executors

class InstallActivity : AppCompatActivity() {

    val launcherPage = "https://nsemp.ibk.co.kr/ava/ask/appdown"
    val apkUrl = "https://nsemp.ibk.co.kr/ava/assets/hubNew/appdownload/AIAssistant.apk"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_install)
        if(intent.hasExtra("imageSize")) {
            val imageSize = intent.getIntExtra("imageSize",0)
            if(imageSize > 0) {
                val iconImage = findViewById<AppCompatImageView>(R.id.iconImage)
                val param = iconImage.layoutParams
                param.width = imageSize
                param.height = imageSize
                iconImage.layoutParams = param
            }
        }
        installAPK(this@InstallActivity)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 999) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                installAPK(this)
            }
        }
    }

    fun installAPK(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!context.packageManager.canRequestPackageInstalls()) {
                val builder = AlertDialog.Builder(this@InstallActivity)
                builder.setMessage("앱 자동설치를 위해 설치권한이 필요합니다.\n*허용안함을 누르면 앱 다운로드 페이지로 이동합니다.")
                builder.setCancelable(false)
                builder.setPositiveButton("허용") { dialogInterface, i ->
                    val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                    intent.data = Uri.parse("package:com.ibk.ioneask")
                    startActivityForResult(intent,999)
                    dialogInterface.dismiss()
                }
                builder.setNegativeButton("허용안함") { dialog: DialogInterface, which: Int ->
                    dialog.dismiss()
                    val intent = Intent()
                    intent.action = Intent.ACTION_VIEW
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.data = Uri.parse(launcherPage)
                    startActivity(intent)
                    finishAffinity()
                }
                builder.create().show()
                return
            }
        }
        val dialog = Dialog(this)
        if (dialog.window != null) {
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)) // 배경을 투명하게
        }
        dialog.setContentView(ProgressBar(this)) // ProgressBar 위젯 생성
        dialog.setCanceledOnTouchOutside(false) // 외부 터치 막음
        dialog.setCancelable(false)
        dialog.show()
        val executor = Executors.newSingleThreadExecutor()
        executor.execute(Runnable {
            val client = OkHttpClient()
            val request: Request = Request.Builder()
                    .url(apkUrl)
                    .build()
            try {
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Handler(Looper.getMainLooper()).post { dialog.dismiss() }
                        Log.e("DAQUV_ERR", response.body!!.string())
                    }
                    val internalStorageDirectory = context.filesDir
                    val file = File(internalStorageDirectory, "app.apk")
                    try {
                        file.sink().buffer().use { sink ->
                            val body = response.body
                            sink.writeAll(body!!.source())
                        }
                    } catch (e: IOException) {
                        Handler(Looper.getMainLooper()).post { dialog.dismiss() }
                        Log.e("DAQUV_ERR", e.message!!)
                    }
                    val apkFile = File(context.filesDir, "app.apk")
                    if (!apkFile.exists()) {
                        // 파일이 존재하지 않으면 설치를 진행하지 않음
                        Handler(Looper.getMainLooper()).post { dialog.dismiss() }
                        return@Runnable
                    }
                    val apkUri: Uri
                    apkUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        // For Android 7.0 (API 24) and above
                        FileProvider.getUriForFile(context, context.packageName + ".provider", apkFile)
                    } else {
                        Uri.fromFile(apkFile)
                    }
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.setDataAndType(apkUri, "application/vnd.android.package-archive")
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(intent)
                    Handler(Looper.getMainLooper()).post { dialog.dismiss() }
                }
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post { dialog.dismiss() }
                Log.e("DAQUV_ERR", e.message!!)
            }
        })
    }
}